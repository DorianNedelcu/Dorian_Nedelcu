import sqlite3
import streamlit as st
from pathlib import Path
import pandas as pd

st.set_page_config(
	page_title="Database Streamlit script",
	page_icon="🧊",  # layout="wide",
	initial_sidebar_state="expanded" )

dark = '''
	<style>
		.stApp {  
		primaryColor="Red"
		backgroundColor="Black"
		secondaryBackgroundColor="Black"
		textColor="Gray"
		font="sans serif"
		}
	</style>
'''
st.markdown(dark, unsafe_allow_html=True)
st.header(":book: Database Streamlit script")
st.markdown (""":green[This application has been developed in 
    Streamlit & Python to manage SQlite database.]""")
st.divider()

current_dir = Path(__file__).parent if "__file__" in locals() else Path.cwd()
DATABASE="DB_orders.db"
TABLE="Orders"
DB_NAME=str(current_dir)+"/"+DATABASE
FIELDS ="OrderID,EmployeeID,OrderDate,Freight,ShipAddress,ShipCity,ShipCountry"

def COUNT(OrderID):
    connection = sqlite3.connect(DB_NAME)
    CURSOR = connection.cursor()
    CURSOR.execute("SELECT COUNT(*) FROM "+TABLE+" WHERE OrderID= " + str(int(OrderID)))
    RECCOUNT=CURSOR.fetchone()[0]
    return RECCOUNT

def Browse_Records():
    st.header(":green[:arrow_down_small: Browse Records]")
    connection = sqlite3.connect(DB_NAME)
    CURSOR = connection.cursor()
    CURSOR.execute( "SELECT count(*) FROM "+TABLE)
    RECCOUNT=CURSOR.fetchone()[0]
    CRS = CURSOR.execute('select * from '+TABLE)
    COLUMNS = [column[0] for column in CURSOR.description]
    col1, col2, col3= st.columns([0.7,0.3,0.4])
    col1.write(":green[Database: ] "+DB_NAME)
    col2.write(":green[Table: ] "+TABLE)
    col3.write(":green[No. of records: ] "+str(RECCOUNT))
    # col1, col2, col3= st.columns([0.9,0.3,0.4])
    # col1.write(":green[Table fields:]")  ;  col2.write(FIELDS) 
    df = pd.DataFrame(CRS, columns=COLUMNS)
    st.dataframe(df)
    CURSOR.close()  ;  connection.close()
    st.divider()

def Add_Record(OrderID, EmployeeID, OrderDate, Freight, ShipAddress, ShipCity, ShipCountry):
    connection = sqlite3.connect(DB_NAME)
    CURSOR = connection.cursor()
    if COUNT(OrderID)>0:
        connection.close()
        MSJ="This is an error. Value of Primary Key 'OrderID="
        MSJ=MSJ+str(int(OrderID))+"' exist in table."
        st.error(MSJ, icon="🚨")
        return
    str_Fields=''
    str_Fields=str_Fields+"'"+str(int(OrderID))+"',"
    str_Fields=str_Fields+"'"+str(int(EmployeeID))+"',"
    str_Fields=str_Fields+"'"+str(OrderDate)+"',"
    str_Fields=str_Fields+"'"+str(Freight)+"',"
    str_Fields=str_Fields+"'"+ShipAddress+"',"
    str_Fields=str_Fields+"'"+ShipCity+"',"
    str_Fields=str_Fields+"'"+ShipCountry+"'"
    SELECT="INSERT INTO "+TABLE+" ("+FIELDS+") VALUES ( "+str_Fields+")"
    CURSOR.execute( SELECT)  
    connection.commit() ; connection.close()
    st.success("Record added to database: '"+DATABASE+"'    Table: '"+TABLE+"'")

def Modify_Record(OrderID, EmployeeID, OrderDate, Freight, ShipAddress, ShipCity, ShipCountry):
    connection = sqlite3.connect(DB_NAME)
    CURSOR = connection.cursor()
    SELECT="UPDATE "+TABLE+" SET "+ \
        "EmployeeID="+"'"+str(int(EmployeeID))+"',"+ \
        "OrderDate="+"'"+str(OrderDate)+"',"+ \
        "Freight="+"'"+str(Freight)+"',"+ \
        "ShipAddress="+"'"+str(ShipAddress)+"',"+ \
        "ShipCity="+"'"+str(ShipCity)+"',"+ \
        "ShipCountry="+"'"+str(ShipCountry)+"'"+ \
        " where (OrderID= " + str(int(OrderID)) +")"   
    CURSOR.execute(SELECT)
    connection.commit() ; connection.close()
    st.success("Record modified in database: '"+DATABASE+"'    Table: '"+TABLE+"'")

def Delete_Record(OrderID):
    connection = sqlite3.connect(DB_NAME)
    CURSOR = connection.cursor()
    if COUNT(OrderID)==0:
        connection.close()
        MSJ="This is an error. Value of Primary Key 'OrderID="
        MSJ=MSJ+str(int(OrderID))+"' not exist in table."
        st.error(MSJ, icon="🚨")
        return
    CURSOR.execute("DELETE FROM "+TABLE+" WHERE OrderID= " + str(int(OrderID)))
    connection.commit() ; connection.close()
    MSJ="The record with value of Primary Key 'OrderID='"
    MSJ=MSJ+str(int(OrderID))+" erased from table."
    st.success(MSJ, icon="🚨")
    
def OnExcel():
    connection = sqlite3.connect(DB_NAME)
    CURSOR = connection.cursor()	
    SELECT="SELECT * FROM "+TABLE
    df = pd.read_sql(SELECT,connection)
    file_name=DB_NAME+"__"+TABLE+".csv"
    df.to_csv(file_name)
    st.success("File saved to:\n\n"+file_name)

st.header(":green[:arrow_down_small: Input Data Section]")
col1, col2, col3, col4 = st.columns(4)
OrderID = col1.number_input(":sparkles: Order ID :one:")
EmployeeID = col2.number_input(":hash: Employee ID :one:")
OrderDate = col3.date_input(":calendar: Order Date :date:")
Freight = col4.number_input(":scales: Quantity :one:", format="%2.4f")
col1, col2 = st.columns(2)
ShipAddress = col1.text_input(":ship: Ship Address :abc:")
ShipCity = col2.text_input(":arrow_forward: Ship City :abc:")
col1, col2 = st.columns(2)
ShipCountry = col1.text_input(":rainbow-flag: Ship Country :abc:")
col2.write(":red[:information_source: Fields marked with :one: are numerical.]")
col2.write(":red[:information_source: Fields marked with :abc: are text.]")
st.divider()

if st.sidebar.header(":red[:classical_building: Menu]"):
    st.sidebar.write(":one: Fill all fields and select :heavy_plus_sign: 'Add Record' :red[or]")
    st.sidebar.write(":two: fill in ':sparkles: Order ID' and select other options like ':m: Modify' or ':no_entry: Delete'.")
    st.sidebar.write(":three: The option ':m: Modify' or':no_entry: Delete' require to fill only ' \
            :sparkles: Order ID' field with one existing from table.")
    st.sidebar.write(":four: The ':eye: View Records' or ':spiral_note_pad: Export Excel' option does not require to fill fields.")
if st.sidebar.button(":eye: View Records", use_container_width=True):    
    Browse_Records()
if st.sidebar.button(":heavy_plus_sign: Add Record", use_container_width=True):
    Add_Record(OrderID, EmployeeID, OrderDate, Freight, ShipAddress, ShipCity, ShipCountry)
if st.sidebar.button(":m: Modify Record", use_container_width=True):
    Modify_Record(OrderID, EmployeeID, OrderDate, Freight, ShipAddress, ShipCity, ShipCountry)
if st.sidebar.button(":no_entry: Delete Record", use_container_width=True):
    Delete_Record(OrderID)
if st.sidebar.button(":spiral_note_pad: Export Excel", use_container_width=True):
    OnExcel()