#! /usr/bin/env python
#coding=utf-8

# Implementation of matplotlib function 
import matplotlib.pyplot as plt 
sir="Abstract. The paper describes application designed \nto unfold the sheet metal parts (the unfolding of the following types of surfaces: cylinder intersected by two planes - 2 variants, intersection of two/ three cylinders of equal diameter and cylindrical elbow) designed with two programming languages: Streamlit [1] and B4A [2]. The Streamlit version of application use Python & Matplotlib to generate the unfolded geometry and to plot the numerical & graphical results; the application is publicly available on the Internet [3], does not contain any viruses and not store data to any external server. The B4A version of application is available to download for smartphones as ”Unfold Sheets Parts.apk” in the ”Programming” section of reference [4]; this application does not share data over the internet, the code runs entirely on the user's smartphone, does not contain any viruses and not store data to any external server. Specific elements of the two languages are presented in comparison, as well as the conceptual differences resulting from their use in the creation of the application."    
sir=sir+sir
fig, ax = plt.subplots() 
ax.text(0, 99, str(sir), fontsize=10, style='oblique', ha='left', 
         va='top', wrap=True

) 

ax.set(xlim =(0, 100), ylim =(0, 100)) 
ax.set_title('matplotlib.axes.Axes.text() Example', 
             fontsize = 14, fontweight ='bold') 
  
plt.show() 
