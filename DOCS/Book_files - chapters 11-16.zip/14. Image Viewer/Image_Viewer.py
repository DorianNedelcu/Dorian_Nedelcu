import streamlit as st 
from PIL import Image
from PIL.ImageFilter import *
import numpy as np 
from pathlib import Path 
import cv2 
# Install OpenCV with command:  pip install opencv-python

st.set_page_config(page_title="Image Viewer")
css='''
<style>
    section.main > div {max-width:70rem}  # 1rem = 16px ; 70rem = 1120 px
</style>
'''
st.markdown(css, unsafe_allow_html=True)
current_dir = Path(__file__).parent if "__file__" in locals() else Path.cwd()

st.subheader(":green[Image Viewer]")
MSJ=":frame_with_picture: Choose an image file from the script folder ! :arrow_down_small:"
uploaded_file = st.file_uploader(MSJ, type="jpg")
if uploaded_file:
    NAME=uploaded_file.name
    col1, col2 = st.columns(2)  
    col1.image(Image.open(NAME), width=500, caption="Uploaded file: "+NAME)
    Place_Image = col2.empty()
    Place_Image.image(Image.open(NAME), width=500, caption='Original Image ')
    
    with st.form(key='columns_in_form'):
            lst_Select=["Grayscale","Vertical Mirror","Horizontal Mirror", "Edge detection", "Invert"]
            selected=st.radio('Select an option to modify image :',lst_Select,horizontal=True)
            submit_button = st.form_submit_button('Submit')
    if submit_button:
        # cv_version=cv2.version 
        IMAGE_NAME = str(current_dir)+"/"+NAME
        MODIFIED_NAME = str(current_dir)+"/"+selected+"_"+NAME
        IMAGE = cv2.imread(IMAGE_NAME)

        if selected=="Grayscale":
            image2 = cv2.imread(IMAGE_NAME, cv2.IMREAD_GRAYSCALE)
        if selected=="Vertical Mirror":
            image2 = cv2.flip(IMAGE, 0)
        if selected=="Horizontal Mirror":
            image2 = cv2.flip(IMAGE, 1)
        if selected=="Edge detection":
            gray_img = cv2.cvtColor(IMAGE,cv2.COLOR_BGR2GRAY)  # convert to grayscale 
            image2 = cv2.Canny(gray_img, 50, 240)
        if selected=="Invert":
            image2 = cv2.bitwise_not(IMAGE)
        cv2.imwrite(MODIFIED_NAME, image2)
        Place_Image.empty()
        Place_Image.image(Image.open(MODIFIED_NAME), width=500, caption='Modified Image:')
        st.success('Modified Image:'+MODIFIED_NAME)