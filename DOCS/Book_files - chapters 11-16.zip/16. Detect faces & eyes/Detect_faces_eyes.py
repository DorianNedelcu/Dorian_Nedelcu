import streamlit as st 
from PIL import Image
import numpy as np 
from pathlib import Path 
import cv2 

st.set_page_config(page_title="Detect faces & eyes")
css='''
<style>
    section.main > div {max-width:70rem}  # 1rem = 16px ; 70rem = 1120 px
</style>
'''
st.markdown(css, unsafe_allow_html=True)
current_dir = Path(__file__).parent if "__file__" in locals() else Path.cwd()

def Detect_FACES(NAME):
    img = cv2.imread(NAME)
    H,W,x = img.shape
    ImageWidth = W ; Imageheight = H
    if W>1000: 
        ImageWidth=1000
        Imageheight = int(H*ImageWidth/W)
    gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face_classifier = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    faces = face_classifier.detectMultiScale(
        gray_image, scaleFactor=1.05, minNeighbors=5, minSize=(50, 50) )
    for (x, y, w, h) in faces:
        cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 3)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    FileName = NAME[:-4]+"_Faces" + NAME[-4:] 
    cv2.imwrite(FileName, img_rgb)
    return [FileName, ImageWidth, Imageheight]

def Detect_EYES(NAME):
    img = cv2.imread(NAME)
    gray_image = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face_classifier = cv2.CascadeClassifier(
        cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    eye_cascade = cv2.CascadeClassifier(
		    cv2.data.haarcascades + "haarcascade_eye_tree_eyeglasses.xml")
    faces = face_classifier.detectMultiScale(
        gray_image, scaleFactor=1.5, minNeighbors=5, minSize=(50, 50) )
    for (x, y, w, h) in faces:        
        face_roi = gray_image[y:y+h, x:x+w] # Get the face ROI        
        eyes = eye_cascade.detectMultiScale(face_roi)  #  Detect eyes in the face ROI        
        for (ex, ey, ew, eh) in eyes:  # Loop over the eyes
            # Draw a rectangle around the eyes
            cv2.rectangle(img, (x+ex, y+ey), (x+ex+ew, y+ey+eh), (0, 255, 0), 2)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    FileName = NAME[:-4]+"_Eyes" + NAME[-4:] 
    cv2.imwrite(FileName, img_rgb)
    return FileName

st.subheader(":green[Detect faces / eyes]")
MSJ=":frame_with_picture: Choose an image file ! :arrow_down_small:"
uploaded_file = st.file_uploader(MSJ, type="jpg")
if uploaded_file:
    NAME=uploaded_file.name
    FileName1, ImageWidth, ImageHeigth = Detect_FACES(NAME)
    FileName2 = Detect_EYES(NAME)
    PlaceImage1= st.empty()
    PlaceImage1.image(Image.open(NAME), width=ImageWidth, caption="Uploaded file: "+
            NAME+" Width/Heigth = "+str(ImageWidth)+"/"+str(ImageHeigth))
    with st.form(key='form'):
        lst_Select=["Faces","Eyes","Both"]
        selected=st.radio('Select an option :',lst_Select,horizontal=True)
        submit_button = st.form_submit_button('Submit')
    if submit_button:
        if submit_button:
            if selected=="Faces" or selected=="Both":
                PlaceImage2= st.empty()
                PlaceImage2.image(Image.open(FileName1), width=ImageWidth, caption='Detected faces on: '+FileName1)
            if selected=="Eyes" or selected=="Both":
                PlaceImage3= st.empty()
                PlaceImage3.image(Image.open(FileName2), width=ImageWidth, caption='Detected eyes on: '+FileName2)