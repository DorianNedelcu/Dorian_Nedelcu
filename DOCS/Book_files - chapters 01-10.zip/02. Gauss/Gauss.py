import streamlit as st 
from PIL import Image  
import matplotlib.pyplot as plt
import math
from pathlib import Path 

def funct1a(x): 
	y=x*x
	return y  
def funct1b(x): 
	y=x*x
	return y 
def funct2(x): 
	y=x*x*math.sqrt(1-x*x)
	return y 
def funct3(x): 
	y=1/(1+x*x)
	return y    
def funct4(x): 
	y=math.sin(x)
	return y  
def funct5(x): 
	y=x*math.sin(x)
	return y 
def funct6(x): 
	y=math.sqrt(1-x*x)
	return y 
def funct7(x): 
	y=math.log(1-8*math.cos(x)+16)
	return y  

def  Gauss(a, b):
	ag = [None] * 17  ;  xg = [None] * 17
	ag[9] =0.18945061 ; ag[10]=0.18260341 ; ag[11]=0.16915651 ; ag[12]=0.14959598 
	ag[13]=0.12462897 ; ag[14]=0.09515851 ; ag[15]=0.06225352 ; ag[16]=0.02715245
	
	xg[9] =0.09501250 ; xg[10]=0.28160355 ; xg[11]=0.45801677 ; xg[12]=0.61787624 
	xg[13]=0.75540440 ; xg[14]=0.86563120 ; xg[15]=0.94457502 ; xg[16]=0.98940093
	for i in range(1, 9):
		ag[i]=ag[17-i]
		xg[i]=-xg[17-i];
	h1=(b-a)/2; h2=(b+a)/2; suma_Gauss=0	
	x=[]  ;  y=[]
	for i in range(1, 17):
		xi=h1*xg[i]+h2
		suma_Gauss=suma_Gauss+ag[i]*FUNCT(xi)
		x.append(xi)  ;  y.append(FUNCT(xi))
	suma_Gauss=suma_Gauss*h1
	lst_return=[suma_Gauss, x, y]
	return lst_return

st.subheader(":green[Integration by Gauss method]")  
current_dir = Path(__file__).parent if "__file__" in locals() else Path.cwd()

col1, col2, col3, col4 = st.columns(4)  
col1.image(Image.open(str(current_dir)+"/"+"Functia1a.jpg"), width=140, caption='1a')
col2.image(Image.open(str(current_dir)+"/"+"Functia1b.jpg"), width=140, caption='1b')
col3.image(Image.open(str(current_dir)+"/"+"Functia2.jpg"), width=140, caption='2')
col4.image(Image.open(str(current_dir)+"/"+"Functia3.jpg"), width=140, caption='3')

col1, col2, col3, col4 = st.columns(4)
col1.image(Image.open(str(current_dir)+"/"+"Functia4.jpg"), width=140, caption='4')
col2.image(Image.open(str(current_dir)+"/"+"Functia5.jpg"), width=140, caption='5')
col3.image(Image.open(str(current_dir)+"/"+"Functia6.jpg"), width=140, caption='6')
col4.image(Image.open(str(current_dir)+"/"+"Functia7.jpg"), width=140, caption='7')

lst_Functions=["Select function","1a","1b","2","3","4","5","6","7"]
st.subheader(':green[Input Data]')

selectia=st.selectbox("Select function ",options=lst_Functions)

if selectia != "Select function":  
    if selectia=="1a" :
        FUNCT=funct1a  ;  AA=1.  ;  BB=3.
    elif selectia=="1b" :
        FUNCT=funct1b  ;  AA=1.  ;  BB=50.
    elif selectia=="2" :
        FUNCT=funct2  ;  AA=0.  ;  BB=0.9999
    elif selectia=="3" :
        FUNCT=funct3  ;	AA=0.  ;  BB=1.
    elif selectia=="4" :
        FUNCT=funct4  ;  AA=0.  ;  BB=math.pi/2
    elif selectia=="5" :
        FUNCT=funct5  ;  AA=0.  ;  BB=2*math.pi
    elif selectia=="6" :
        FUNCT=funct6  ; AA=-0.9999  ;  BB=0.9999
    else:
        FUNCT=funct7  ; AA=0.  ;  BB=math.pi
    with st.form('Input Data'):  
        col1, col2 = st.columns(2)  
        a = col1.number_input(label='Limit A ',value=AA,format="%.6f")
        b = col2.number_input(label='Limit B ',value=BB,format="%.6f")
        submit_button = st.form_submit_button('Calculate') 
    if submit_button:
        NrPct=100
        pas=(b-a)/NrPct
        xi=a ; X=[a] ; Y=[FUNCT(a)]
        for i in range(1, NrPct+1):
            xi=xi+pas
            X.append(xi)
            Y.append(FUNCT(xi))
        
        LST_RETURN= Gauss(a,b) 
        Int_Gauss=LST_RETURN[0]
        st.write("Value of the Gauss integral = "+str(Int_Gauss))

        # Chart drawing
        fig=plt.figure() 
        plt.grid(True) 
        plt.title("Integration by rectangles method", fontsize=14, 
            fontweight='bold',color='Black') 
        lx=len(X)-1
        for i in range(lx-1):
            plt.plot((X[i],X[i+1]),(Y[i],Y[i+1]), '-', color="Blue",linewidth=1.0)
            print (i, X[lx-1])
        plt.plot((X[lx-1],X[lx]),(FUNCT(X[lx-1]),FUNCT(X[lx])), '-', color="Blue",linewidth=1.0)	

        xgauss=LST_RETURN[1]  ;  ygauss=LST_RETURN[2]
        for i, ( xplot, yplot) in enumerate(zip(xgauss, ygauss)):
            plt.plot(xplot,yplot, 'o', color="Red", markersize=4)
        st.empty().write(fig)
        st.write("Continuous blue line display the function plot")
        st.write("Red points display Gauss integration points")