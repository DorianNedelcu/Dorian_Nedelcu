import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path # This module provides classes to represent abstract/concrete paths
from openpyxl import load_workbook # Import Python library to read/write Excel files
from openpyxl.drawing.image import Image

current_dir = Path(__file__).parent if "__file__" in locals() else Path.cwd()
st.subheader(":green[NACA profile]")
# Require to install openpyxl library with command 'pip install openpyxl'
uploaded_file = st.file_uploader("Choose a XLSX file with profile coordinates", type="xlsx")
if uploaded_file:
    df = pd.read_excel(uploaded_file)
    st.dataframe(df) # Display the table with profile coordinates
    X = df['X'].tolist() # Convert columns X from dataframe to list
    Y = df['Y'].tolist() # Convert columns Y from dataframe to list

    # Chart drawing
    Place_Chart = st.empty() 
    fig=plt.figure() # Create chart figure
    plt.grid(True) # Show the chart grid
    plt.xlabel('X', fontsize=20, fontweight='bold')
    plt.ylabel('Y', fontsize=20, fontweight='bold')
    plt.axis('equal') # Set and adjust plots with equal axis aspect ratios
    plt.title("NACA profile", fontsize=14, fontweight='bold',color='Black') # Define chart title
    for i, ( xplot, yplot) in enumerate(zip(X, Y)):
        plt.plot(xplot,yplot, 'o', color="Red", markersize=3)
        if i != len(X)-1:
            plt.plot((X[i],X[i+1]),(Y[i],Y[i+1]), '-', color="Blue",linewidth=1.0)
    img_file = str(current_dir)+'/Profile.jpg'
    
    # Save image to an image file
    plt.savefig(img_file) 
    st.write("Image saved in "+img_file)
    
    # Export image to Excel file
    wb = load_workbook(f"{uploaded_file.name}")
    ws = wb.active
    ws['D1'] = 'Profile image exported from NACA.py script'
    img=Image(img_file)
    ws.add_image(img,'D2')
    wb.save(f"{uploaded_file.name}")
    Place_Chart.write(fig)
    st.write("Image exported in Excel file "+f"{uploaded_file.name}")