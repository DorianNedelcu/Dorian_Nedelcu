import streamlit as st
import pandas as pd
import numpy as np
import random  # imports random module

def Calc_DataFrame(DFrame, N1, Col_Start): 
    for lin in range(1, N1):
        counter = int((N1-1) / 2) +1 
        for col in range(0, N1):
            V = DFrame.iat[lin-1,counter]
            DFrame.at[lin,col+1] = V
            counter=counter+1
            if counter >= N1:  counter  = 0

st.subheader(":green[Magic square degree N = ]")

lst_Choice=["Select N", "5", "7", "11", "13", "17"]
N=st.selectbox("Select N",options=lst_Choice)
if N != "Select N":
    N1=int(N)
    col_list = []
    for i in range(1,N1+1):
        col_list.append(i)
    df1 = pd.DataFrame(0, index=np.arange(N1), columns=col_list)
    df2 = pd.DataFrame(0, index=np.arange(N1), columns=col_list) 
    col_list.append(N1+1)
    df3 = pd.DataFrame(0, index=np.arange(N1+1), columns=col_list) 
    for col in range(1,N1+1): 
        r1 = random.randint(1, N1) 
        df1.at[0,col] = r1
        r2 = N1 * random.randint(1, N1) 
        df2.at[0,col] = r2
    
    Col_Start = int((N1-1) / 2) +1 
    Calc_DataFrame(df1, N1, Col_Start)
    Calc_DataFrame(df2, N1, Col_Start-1)
    
    st.write("First square")
    df1
    st.write("Second square")
    df2
 
    st.write("Magic square")
    for lin in range(0, N1):
        sum=0
        for col in range(0, N1):
            df3.iat[lin,col] = df1.iat[lin,col]+df2.iat[lin,col]
            sum=sum+df3.iat[lin,col]
        df3.at[lin,N1+1]=sum

    for col in range(0, N1):
        sum=0
        for lin in range(0, N1):
            sum=sum+df3.iat[lin,col]
        df3.at[N1,col+1]=sum

    sum_DP=0  ;  sum_DS=0 
    for lin in range(0, N1):
            sum_DP=sum_DP+df3.iat[lin,lin]
            sum_DS=sum_DS+df3.iat[lin,N1-lin-1]
    df3
    st.write("Sum of the elements on the main diagonal = ", sum_DP)
    st.write("Sum of the elements on the secondary diagonal = ", sum_DS)