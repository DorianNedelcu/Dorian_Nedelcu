import streamlit as st # Import streamlit library
from PIL import Image  # PIL is the Python Imaging Library 
import matplotlib.pyplot as plt
from pathlib import Path # This module provides classes to represent abstract/concrete paths 
import numpy

def funct(x): # Define public function 'funct'
    y=x*x     # Calculate the 'y' value as power of 'x' variable (parabolic function)
    return y  # The function return 'y' value

# Define the application path
current_dir = Path(__file__).parent if "__file__" in locals() else Path.cwd()
st.subheader(":green[Integration by rectangles method]")  # Application subtitle 
# Place the integrate method image
st.empty().image(Image.open(str(current_dir)+"/"+"Integrate.jpg"), width=700, caption='')

with st.form('Input Data'):  # Create input data form
    st.subheader(':green[Input Data]')   # Form subtitle 
    col1, col2, col3 = st.columns(3)  # Insert containers laid out as side-by-side columns
    a = col1.number_input('Limit A ', value=1.0) # Control to input 'a' value
    b = col2.number_input('Limit B ', value=3.0) # Control to input 'b' value
    N = col3.number_input('N ', value=10) # Control to input 'N' value
    submit_button = st.form_submit_button('Calculate')  # Display a form submit button.
if submit_button:
    l=(b-a)/N # The interval length
    aria=0  ;  X=[]  ;  Y=[] # Initialize one variable 'aria' and two lists 'X', 'Y'
    for i in range(1,N+1):
        xi = a+(i-1)*l+l/2  ;  X.append(xi) # Calculate x-coordinate and append to list 'X'
        yi = funct(xi)  ;  Y.append(yi) # Calculate y-coordinate and add to list 'Y'
        adi = l * yi # Calculate area of 'i' rectangle
        aria = aria+adi # Sum area of 'i' rectangle to total 'aria'
    
    # Chart drawing
    Place_Chart = st.empty() # Inserts a container into app that can be used to hold a single element
    fig=plt.figure() # Create chart figure
    plt.grid(True) # Show the chart grid
    plt.title("Integration by rectangles method", fontsize=14, 
        fontweight='bold',color='Black') # Define chart title
    lx=len(X) ; lx1=len(X)-1
    for i in range(0, N):
        plt.plot([X[i], X[i]],[Y[i], Y[i]], 'x', color='Red', linewidth=2) # Mark median curve points
        plt.plot([X[i], X[i]],[0, funct(X[i])], '--', color='Red',linewidth=1) # Median vertical lines
        x1=X[i]-l/2  ; y1= funct(x1)
        plt.plot(x1,y1, '.', color="Black", markersize=10) # Mark curve points
        plt.plot((x1,x1),(0, funct(x1)), '-', color="Black",linewidth=2.0) # Vertical lines
        plt.plot(b,funct(b), '.', color="Black", markersize=10) # Right vertical point
        plt.plot((b,b),(0,funct(b)), '-', color="Black",linewidth=2.0) # Right vertical line
        plt.plot((X[0]-l/2,X[0]+l/2),(funct(a),funct(X[0]+l/2)), '--', color="Blue",linewidth=1.0) # Left semicurve line
    for i in range(lx-1):
        plt.plot((X[i],X[i+1]),(Y[i],Y[i+1]), '--', color="Blue",linewidth=1.0)   # Curve lines
    plt.plot((X[lx1],X[lx1]+l/2),(funct(X[lx1]),funct(b)), '--', color="Blue",linewidth=1.0) # Right semicurve line	
    for i in range(lx):  # Draw rectangle horizontal lines
        plt.plot((X[i]-l/2,X[i]+l/2),(funct(X[i]),funct(X[i])), '--', color="Red",linewidth=1.0)
    for i in range(lx): # Close red rectangles with left vertical lines
        plt.plot((X[i]-l/2,X[i]-l/2),(funct(X[i]),funct(X[i]-l/2)), '--', color="Red",linewidth=1.0)	
    Place_Chart.write(fig)

    # Chart dimensions & coordinates
    col1, col2 = st.columns([0.4,0.6]) # Insert containers laid out as side-by-side columns
    Exact_val = (b**3-a**3)/3 # Calculate exact area by mathematical formula
    col1.write("Exact area = "+'%0.6f' % Exact_val+" [mm2]") # Print exact area
    col2.write("Integrated value (approximate) = "+'%0.6f' % aria +" [mm2]") # Print integrated area