import streamlit as st 
import numpy as np
from numpy import array
import matplotlib.pyplot as plt 
import pandas as pd
from pathlib import Path
import scipy
from scipy import interpolate   # pip install scipy
from scipy.interpolate import interp1d

st.set_page_config(page_title="Spline interpolation")
css='''
<style>
    section.main > div {max-width:70rem}  # 1rem = 16px ; 70rem = 1120 px
</style>
'''
st.markdown(css, unsafe_allow_html=True)
current_dir = Path(__file__).parent if "__file__" in locals() else Path.cwd()

def splprep(x,y):	  # scipy.interpolate.splprep
    data = np.array((x,y))  
    tck,u = interpolate.splprep(data, s=0) 
    # s=0  forcing the spline fit to pass through all the input points
    unew = np.arange(0, 1.02, 0.02)
    out = interpolate.splev(unew, tck)
    lst_return=[out[0],  out[1]]
    return lst_return

st.subheader(":green[Spline interpolation]")
MSJ=":frame_with_picture: Open Excel file to read curve coordinates ! :arrow_down_small:"
uploaded_file = st.file_uploader(MSJ, type="xlsx")
if uploaded_file:
    df = pd.read_excel(uploaded_file)
    st.dataframe(df) # Display the table with profile coordinates
    X = df['X'].tolist() # Convert columns X from dataframe to list
    Y = df['Y'].tolist() # Convert columns Y from dataframe to list
    with st.form('Input Data'):  
        col1, col2, col3 = st.columns(3)  
        col1.write('Min X = '+str(min(X)))
        col2.write('Max X = '+str(max(X)))
        Vmed=(max(X)-min(X))/2 + min(X)
        XXX = col3.number_input(label='Input X value proposed for interpolation !' \
                ,value=Vmed,format="%0.6f")
        submit_button = st.form_submit_button('Interpolate') 
    if submit_button:
        # Charts drawing
        col1, col2 = st.columns(2)  
        # cm = 1/2.54  # centimeters in inches 
        # fig1=plt.figure(figsize=(6*cm, 6*cm))
        fig1=plt.figure() 
        plt.grid(True) 
        plt.title("Interpolation", fontsize=14, 
            fontweight='bold',color='Black') # Define chart title
        # Initial points imposed
        plt.scatter(X, Y, color='Red', label="Initial points imposed")
        # Curve interpolation - splprep
        LST_RETURN=splprep(X, Y)
        xspline = LST_RETURN[0]  ;  yspline = LST_RETURN[1]
        plt.plot(xspline, yspline, '-b', linewidth=1, label="scipy.interpolate.splprep")
        # Point interpolation - splprep & splev
        splines = interpolate.splrep(X, Y)
        YP_splev=interpolate.splev(XXX,splines)
        LBL1="splprep point="+'%0.3f' % XXX+", "+'%0.4f' % YP_splev
        plt.scatter(XXX, YP_splev, color='Black', label=LBL1)
        plt.legend(fontsize=6)  ; plt.legend(loc='best')
        col1.write(fig1)

        # Curve interpolation scipy.interpolate: CubicSpline & akima & pchip
        data = {"x": X, "y": Y}
        interpolated = {"x": np.linspace(min(X), max(X), 50)}
        # interpolated["linear"] = np.interp(interpolated["x"], data["x"], data["y"])
        interpolated["spline"] = scipy.interpolate.CubicSpline(data["x"], data["y"])(
            interpolated["x"] )
        interpolated["akima"] = scipy.interpolate.Akima1DInterpolator(data["x"], data["y"])(
            interpolated["x"] )
        interpolated["pchip"] = scipy.interpolate.PchipInterpolator(data["x"], data["y"])(
            interpolated["x"] )
        
        # Extract list values from the three interpolation: CubicSpline & akima & pchip
        X_Interp = interpolated["x"]
        Y_spline = interpolated["spline"]
        Y_akima = interpolated["akima"]
        Y_pchip = interpolated["pchip"]

        # Point interpolation scipy.interpolate: CubicSpline & akima & pchip
        inter_Point = {"x": XXX}
        interpolated["spline"] = scipy.interpolate.CubicSpline \
            (data["x"], data["y"])(inter_Point["x"] )
        Point_spline = interpolated["spline"]
        LBL2="splprep point="+'%0.3f' % XXX+", "+'%0.4f' % Point_spline

        interpolated["akima"] = scipy.interpolate.Akima1DInterpolator \
            (data["x"], data["y"])(inter_Point["x"] )
        Point_akima = interpolated["akima"]
        LBL3="akima point="+'%0.3f' % XXX+", "+'%0.4f' % Point_akima

        interpolated["pchip"] = scipy.interpolate.Akima1DInterpolator \
            (data["x"], data["y"])(inter_Point["x"] )
        Point_pchip = interpolated["pchip"]
        LBL4="pchip point="+'%0.3f' % XXX+", "+'%0.4f' % Point_pchip

        fig2=plt.figure() # Create chart figure
        plt.grid(True) # Show the chart grid
        plt.title("Interpolation", fontsize=14, 
        fontweight='bold',color='Black') # Define chart title
        plt.scatter(X, Y, color='Red', marker="o", label="Initial points imposed")
        plt.plot(X_Interp, Y_spline, color='Blue', label="scipy.interpolate.CubicSpline")
        plt.scatter(XXX, Point_spline, color='Black', label=LBL2)
        plt.legend(fontsize=6)  ; plt.legend(loc='best') 
        col2.write(fig2)

        col1, col2 = st.columns(2)  

        fig3=plt.figure() # Create chart figure
        plt.grid(True) # Show the chart grid
        plt.title("Interpolation", fontsize=14, 
        fontweight='bold',color='Black') # Define chart title
        plt.scatter(X, Y, color='Red', marker="o", label="Initial points imposed")
        plt.plot(X_Interp, Y_akima, color='Blue', label="scipy.interpolate.Akima1DInterpolator")
        plt.scatter(XXX, Point_akima, color='Black', label=LBL3)
        plt.legend(fontsize=6)  ; plt.legend(loc='best') 
        col1.write(fig3)

        fig4=plt.figure() # Create chart figure
        plt.grid(True) # Show the chart grid
        plt.title("Interpolation", fontsize=14, 
        fontweight='bold',color='Black') # Define chart title
        plt.scatter(X, Y, color='Red', marker="o", label="Initial points imposed")
        plt.plot(X_Interp, Y_pchip, color='Blue', label="scipy.interpolate.PchipInterpolator")
        plt.scatter(XXX, Point_pchip, color='Black', label=LBL4)
        plt.legend(fontsize=6)  ; plt.legend(loc='best') 
        col2.write(fig4)

        # Show interpolated list values
        col1, col2, col3, col4 = st.columns(4)  
        col1.write("X_Interp")  ;  col1.write(X_Interp)
        col2.write("Y_spline")  ;  col2.write(Y_spline)
        col3.write("Y_akima")  ;  col3.write(Y_akima)
        col4.write("Y_pchip")  ;  col4.write(Y_pchip)

        # Show interpolated point values
        col1, col2, col3, col4 = st.columns(4)  
        col1.write("Point X="+ '%0.4f' % XXX)
        col2.write(LBL2)
        col3.write(LBL3)
        col4.write(LBL4) 