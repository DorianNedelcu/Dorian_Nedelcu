import streamlit as st 
import numpy as np
import matplotlib.pyplot as plt 
import pandas as pd
from pathlib import Path
from scipy import interpolate   # pip install scipy
import openpyxl
import math

st.set_page_config(page_title="Surface flatten")
css='''
<style>
    section.main > div {max-width:70rem}  # 1rem = 16px ; 70rem = 1120 px
</style>
'''
st.markdown(css, unsafe_allow_html=True)
current_dir = Path(__file__).parent if "__file__" in locals() else Path.cwd()

def ALFA(xdsf1, xdsf2, ydsf1, ydsf2):
    if (xdsf2-xdsf1)==0:
        alfaperp=0        
    else:
        mcom=(ydsf2-ydsf1)/(xdsf2-xdsf1) ; mperp=-1/mcom ; alfaperp=math.atan(mperp)
    if alfaperp<0:  alfaperp=math.pi-abs(alfaperp)
    coefi=1
    if alfaperp*180/math.pi>90: alfaperp=math.pi-alfaperp ; coefi=-1
    return [coefi, alfaperp]	

st.subheader(":green[Surface flatten]")
MSJ=":frame_with_picture: Open Excel file to read curves coordinates ! :arrow_down_small:"
uploaded_file = st.file_uploader(MSJ, type="xlsx")
if uploaded_file:
    X1=[] ; Y1=[] ; Z1=[] ; X2=[] ; Y2=[] ; Z2=[] 
    xad=[] ; yad=[] ; xbd=[] ; ybd=[]
    wb = openpyxl.load_workbook(uploaded_file)
    sheet  = wb.worksheets[0]
    # Count number of Excel rows filled with coordinates
    count_lex = 0
    for row in sheet:
        if not all([cell.value == None for cell in row]):
            count_lex += 1
    lex=3
    # Read curve coordinates from Excel file
    while True:
        if lex > count_lex:
            break
        else:
            X1.append( sheet.cell(lex,2).value )
            Y1.append( sheet.cell(lex,3).value )
            Z1.append( sheet.cell(lex,4).value )
            X2.append( sheet.cell(lex,7).value )
            Y2.append( sheet.cell(lex,8).value )
            Z2.append( sheet.cell(lex,9).value )      
            lex+=1   
    df = pd.DataFrame( {'X1': X1, 'Y1': Y1,'Z1': Z1, 'X2': X2, 'Y2': Y2,'Z2': Z2} )
    st.dataframe(df)

    with st.form('Input Data'):  # Create input data form
        st.subheader(':green[Input Data]') 
        col1, col2, col3 = st.columns(3)   
        Ninterp = col1.number_input('Input number of spline interpolation points Ninterp = ', value=50) 
        submit_button = st.form_submit_button('Calculate')  
    if submit_button:
        placeholder = st.empty()
        fig = plt.figure(figsize=(8, 8))  ;  ax = plt.axes(projection="3d")
        ax.set_xlabel("X") ; ax.set_ylabel("Y") ; ax.set_ylabel("Z")
        # Draw section 1 curve, points & text
        ax.plot(X2, Y2, Z2, 'b--',  label='Curve 2')
        ax.scatter(X2, Y2, Z2, s=50, marker="8", color="Red", label='Curve 2 points')
        sir= '%0.1f' % X1[0] +", "+ '%0.1f' % Y1[0] + '%0.1f' % Z1[0] 
        ax.text(X1[0], Y1[0], Z1[0], sir, (1,0,0), size=8, zorder=1, color='k') 
        # Draw section 1 curve, points & text
        ax.plot(X1, Y1, Z1, 'b-',  label='Curve 1')
        ax.scatter(X1, Y1, Z1, s=50, marker="D", color="Red", label='Curve 1 points')
        sir= '%0.1f' % X2[0] +", "+ '%0.1f' % Y2[0] + '%0.1f' % Z2[0] 
        ax.text(X2[0], Y2[0], Z2[0], sir, (1,0,0), size=8, zorder=1, color='k') 
        # Spline interpolate curve 2 
        pnts = np.linspace(0,1,Ninterp)       
        tck2, u2 = interpolate.splprep([X2, Y2, Z2], s=2)    
        Xs2, Ys2, Zs2 = interpolate.splev(pnts, tck2)
        ax.scatter(Xs2, Ys2, Zs2, 'o', c="Black", s=10,label="Interpolation Curve 2")
        # Spline interpolate curve 1       
        tck1, u1 = interpolate.splprep([X1, Y1, Z1], s=2)    
        Xs1, Ys1, Zs1 = interpolate.splev(pnts, tck1)
        ax.scatter(Xs1, Ys1, Zs1, 'o', c="Black", s=10,label="Interpolation Curve 1")
        # Stright bending lines
        for i, (x1, y1, z1, x2, y2, z2) in enumerate(zip(Xs1,Ys1,Zs1,Xs2,Ys2,Zs2)):
            ax.plot([x1,x2],[y1,y2],[z1,z2], color="Gray")
        # Diagonal bending lines    
        for i, (x1a, y1a, z1a) in enumerate(zip(Xs1,Ys1,Zs1)):
            if i< len(Xs2) - 1:
                x2b, y2b, z2b = Xs2[i+1],Ys2[i+1],Zs2[i+1]
                ax.plot([x1a,x2b],[y1a,y2b],[z1a,z2b], color="Gray")
        ax.figure.canvas.draw() ; ax.legend(fontsize=10)  ; ax.legend(loc='best')
        placeholder.pyplot(fig)
        # Compute flatten surface coordinates
        ARIA=0
        for i, (x1, y1, z1, x2, y2, z2) in enumerate(zip(Xs1,Ys1,Zs1,Xs2,Ys2,Zs2)):
            if i==0:                
                lcom=math.sqrt((x1-x2)**2+(y1-y2)**2+(z1-z2)**2)
                xdsf1=0 ; ydsf1=0 ; xdsf2=0 ; ydsf2=lcom ; yaxa=lcom
                xad.append(0) ; yad.append(0) ; xbd.append(0) ; ybd.append(lcom)
            else: #--------------------------------
                xdsf1=xad[i-1] ; ydsf1=yad[i-1] ; xdsf2=xbd[i-1] ; ydsf2=ybd[i-1]
                lcom=math.sqrt((xdsf1-xdsf2)**2+(ydsf1-ydsf2)**2)
                l22=math.sqrt((x1-Xs1[i-1])**2+(y1-Ys1[i-1])**2+(z1-Zs1[i-1])**2)
                l21=math.sqrt((Xs2[i-1]-x1)**2+(Ys2[i-1]-y1)**2+(Zs2[i-1]-z1)**2) 
                sp=(lcom+l22+l21)/2 ; aria=math.sqrt(abs(sp*(sp-lcom)*(sp-l22)*(sp-l21)))
                h=2*aria/lcom ; lh2=math.sqrt(abs(l22**2-h**2)) ; lh1=math.sqrt(abs(l21**2-h**2))
                kpunct=lh1/lh2  ; 	ARIA=ARIA+aria
                if (lh1+lh2)-lcom>0.0001: kpunct=-kpunct
                xk=(xdsf1+kpunct*xdsf2)/(1+kpunct) ; yk=(ydsf1+kpunct*ydsf2)/(1+kpunct)
                coefi, alfaperp = ALFA(xdsf1, xdsf2, ydsf1, ydsf2)				
                xalt=xk-h*math.cos(alfaperp) ; yalt=yk-coefi*h*math.sin(alfaperp)
                xbd.append( round(xk+h*math.cos(alfaperp),2) )
                ybd.append( round(yk+coefi*h*math.sin(alfaperp),2) )
                if i>2: Val_com = math.sqrt(abs((xad[i-2]-xbd[i])**2+(yad[i-2]-ybd[i])**2))
                if i>2 and Val_com < math.sqrt((xad[i-2]-xalt)**2+(yad[i-2]-yalt)**2):
                    ele1 = xbd.pop() ; ele2 = ybd() ; 
                    xbd.append( round(xalt,2) ); ybd.append( round(yalt,2) )
                #--------------------------------
                xdsf1=xad[i-1] ; ydsf1=yad[i-1] ; xdsf2=xbd[i] ; ydsf2=ybd[i]
                lcom=l21
                l22=math.sqrt((Xs2[i]-Xs2[i-1])**2+(Ys2[i]-Ys2[i-1])**2+
                        (Zs2[i]-Zs2[i-1])**2)
                l21=math.sqrt((Xs2[i]-Xs1[i])**2+(Ys2[i]-Ys1[i])**2+(Zs2[i]-Zs1[i])**2)
                sp=(lcom+l22+l21)/2 ; aria=math.sqrt(abs(sp*(sp-lcom)*(sp-l22)*(sp-l21)))
                ARIA=ARIA+aria
                h=2*aria/lcom ; lh2=math.sqrt(l22**2-h**2) ; lh1=math.sqrt(l21**2-h**2) ; kpunct=lh1/lh2
                if (lh1+lh2)-lcom>0.0001: kpunct=-kpunct
                xk=(xdsf2+kpunct*xdsf1)/(1+kpunct) ; yk=(ydsf2+kpunct*ydsf1)/(1+kpunct)
                coefi, alfaperp = ALFA(xdsf1, xdsf2, ydsf1, ydsf2)					
                xalt=xk-h*math.cos(alfaperp) ; yalt=yk-coefi*h*math.sin(alfaperp)
                xad.append( round(xk+h*math.cos(alfaperp),2) )
                yad.append( round(yk+coefi*h*math.sin(alfaperp),2) )
                if i>2: Val_com = math.sqrt((xbd[i-1]-xad[i])**2+(ybd[i-1]-yad[i])**2)
                if i>2 and Val_com < math.sqrt((xbd[i-1]-xalt)**2+(ybd[i-1]-yalt)**2):
                    ele1 = xad.pop() ; ele2 = yad() ; 
                    xad.append( round(xalt,2) ) ; yad.append( round(yalt,2) )
        LengthA=0 ; LengthB=0
        for i, (xa, ya, xb, yb) in enumerate(zip(xad,yad, xbd, ybd)):						
            if i>0:
                LengthA = LengthA+math.sqrt((xbd[i-1] - xb) ** 2 + (ybd[i-1] - yb) ** 2) 
                LengthB = LengthB+math.sqrt((xad[i-1] - xa) ** 2 + (yad[i-1] - ya) ** 2)				
        # Draw FLATTEN SURFACE
        placeholder1 = st.empty()
        fig1 = plt.figure(figsize=(8, 8))
        ax1 = plt.axes()
        ax1.set_xlabel("X") ; ax1.set_ylabel("Y") 
        # Draw section 1, 2 flaten curve, points
        ax1.plot(xad, yad)  ;  ax1.plot(xbd, ybd)
        ax1.scatter(xbd, ybd, marker="8", s=20, color="Blue", label="Curve 1")
        ax1.scatter(xad, yad, marker="D", s=20, color="Red", label="Curve 2")			
        # Stright bending lines
        for i, (xi1, yi1, xi2, yi2) in enumerate(zip(xad, yad,xbd, ybd)):
            ax1.plot([xi1,xi2],[yi1,yi2], color="Gray")
        # Diagonal bending lines    
        for i, (xbla, ybla) in enumerate(zip(xad, yad)):
            if i< len(xad) - 1:
                xblb, yblb = xbd[i+1],ybd[i+1]
                ax1.plot([xbla,xblb],[ybla,yblb], color="Gray")
        ax1.legend(fontsize=10)  ; ax1.legend(loc='best') ; ax1.figure.canvas.draw()
        ax1.grid(True) ;  placeholder1.pyplot(fig1)
        col1, col2, col3, col4 = st.columns(4)
        col1.write("Length curve 2 = "+str(round(LengthA,2)))
        col1.write("Length curve 1 = "+str(round(LengthB,2)))
        col1.write("Arie = "+str(round(ARIA,2)))
        col1.write("No. of spline interpolation points = "+str(Ninterp))
        # Flatten surface coordonates 
        df1 = pd.DataFrame( {'Xad': xad, 'Yad': yad,'Xbd': xbd, 'Ybd': ybd} )
        col2.dataframe(df1)