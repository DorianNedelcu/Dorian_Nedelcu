import streamlit as st 
import numpy as np
import matplotlib.pyplot as plt 
from pathlib import Path

def NonRecursiv(N):   # Nonrecursiv variant
    Lst=[N]
    while N != 4:
        x=str(N)     # Convert N to string
        if x[-1]=='0' or x[-1]=='4':
            x=x[:-1] # Remove the last string char
            N=int(x) # Convert string to N
        else:
            N=2*N    # Doubling N
        Lst.append(N)
    return Lst

def Recursiv(X): # Recursive variant
    x=str(X)
    if X==4:
        return    # Exit from recursive calls
    elif x[-1]=='0' or x[-1]=='4':
        x=x[:-1] # Remove the last string char
        N=int(x) # Convert string to N
    else:
        N=2*X    # Doubling N
    Lst2.append(N) 
    Recursiv(N)  # Self function call 

st.subheader(":green[Sequence generated using an imposed algorithm]")
with st.form('Input Data'):  # Create input data form
        st.subheader(':green[Input Data]') 
        col1, col2, col3 = st.columns(3)   
        N= col1.number_input('Input number  = ', value=55) 
        submit_button = st.form_submit_button('Generate')  
if submit_button:
     # Main program =======================================
    N=55
    Lst1 = NonRecursiv(N) # Call nonrecursiv function
    Lst2 =[N]
    Recursiv(N)           # First recursive function call

    placeholder1 = st.empty()
    fig = plt.figure(figsize=(8, 8)) ; ax = plt.axes()
    plt.xlabel("Iteration", fontsize=16, fontweight='bold', color="Brown")
    plt.ylabel("Generated numbers", fontsize=16, fontweight='bold', color="Brown")
    plt.xticks(fontsize=16, fontweight='bold', color="Black")
    plt.yticks(fontsize=16, fontweight='bold', color="Blue")

    X_axis = np.arange(len(Lst1))
    Lst1_string =",".join(str(element) for element in Lst1)
    Lst2_string = ",".join(str(element) for element in Lst2)
    ax.bar(X_axis - 0.2, Lst1, width=0.4, label = "Nonrecursiv: "+Lst1_string, color="Red")
    ax.bar(X_axis + 0.2, Lst2, width=0.4, label = "Recursiv   : "+Lst2_string, color="Blue")

    plt.title("Sequence generated using an imposed algorithm", fontsize=10, fontweight='bold', color="Black") 
    plt.legend() ; plt.grid(True) ; plt.show()  ;  placeholder1.pyplot(fig)