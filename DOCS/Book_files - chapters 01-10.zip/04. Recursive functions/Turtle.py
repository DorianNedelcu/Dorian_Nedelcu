import turtle # Import the graphics library 
turtle.pencolor("Yellow") # Set pen color
turtle.bgcolor('Blue') # Set background screen color
turtle.penup() # Set not drawing state
turtle.goto(-200, 100) # Move the turtle to an absolute position
turtle.pendown() # Set drawing state
def star(turtle, size): # Define recursive function "star"
    if size <= 10: 
        return # Exit from recursive function if "size <= 10"
    else:
        for i in range(5): # Create a loop with values i=0, 1, 2, 3, 4
            # Move the turtle forward by the argument value
            turtle.forward(size) 
            star(turtle, size/3) # Call "star" recursive function
            # Move the turtle left by the argument value
            turtle.left(216)
star(turtle, 360) # Call "star" recursive function
# Starts event loop (last statement in a turtle graphics program)
turtle.done() 