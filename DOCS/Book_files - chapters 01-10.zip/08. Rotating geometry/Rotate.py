import plotly.graph_objects as go
import pandas as pd
import os

df = pd.read_excel(os.getcwd()+"/Coordonate.xlsx")
X = df['X'].tolist() # Convert columns X from dataframe to list
Y = df['Y'].tolist() # Convert columns Y from dataframe to list
Z = df['Z'].tolist() # Convert columns Y from dataframe to list
ID_Pct=df['ID_Point'].tolist() # Convert columns ID_Face from dataframe to list of float numbers
ID_Point = [str(x) for x in ID_Pct] # Convert list of float numbers to list of strings

fig = go.Figure(data=go.Scatter3d(
    x=X, y=Y,z=Z, 
    mode='lines+markers+text', 
    text=ID_Point, 
    textposition="top center",
    marker=dict(
        size=8,
        opacity=0.5)
    ))

# Default parameters which are used when `layout.scene.camera` is not provided
camera = dict(
    up=dict(x=0, y=0, z=1),
    center=dict(x=0, y=0, z=0),
    eye=dict(x=1.25, y=1.25, z=1.25))

fig.update_layout(scene_camera=camera, title='Rotate 3D home geometry')
fig.show()