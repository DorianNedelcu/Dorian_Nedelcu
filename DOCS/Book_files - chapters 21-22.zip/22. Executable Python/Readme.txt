Magic_Square software ; Vers. 1.0 - @ 2024
@ 2024 - Dorian Nedelcu*  & Tihomir Latinovic** 
   
*  Former Prof. Dorian Nedelcu
   Member of Bosnia and Herzegovina American Academy od Arts and Science (BHAAAS)
   Babes-Bolyai University of Cluj-Napoca, Romania 
   Faculty of Engineering, 
   Department of Engineering Sciences, 
   Traian Vuia square, no.1-4, 320085, Resita.
   dorian.nedelcu@ubbcluj.ro
   ne_dor@yahoo.com
   ORCID ID: orcid.org/ 0000-0002-4927-1042 
 
** Prof. Doctor Tihomir Latinovic
   Member of Bosnia and Herzegovina American Academy od Arts and Science (BHAAAS)
   Member of Western Balkan Alumni Association (WBAA)
   University of Vitez
   Middle-Bosnian canton, Bosnia and Herzegovina
   Faculty of Information Technology
   e-mail: tihomirlatinovic@live.com 
   University web:  https://unvi.edu.ba/
   Personal web: https://tihomirlatinovic.wordpress.com/cv-english/ 
   ORCID ID: orcid.org/0000-0003-3682-6464 

Magic_Square - A Python module to create a Magic Square.
A magic square is a matrix for which the sum of the elements on the rows, 
columns and the two diagonals (main and secondary) are equal. 

Magic_Square - License CC0 1.0
----------------------------------
You can copy, modify, distribute and perform the work, even for commercial purposes, 
all without asking permission.

The software packages
---------------------
The Magic_Square software is created with the following free and Open Source resources:

= Python 2.7 - a high-level programming language. Python runs on Windows, Linux/Unix, 
	Mac OS X, and has been ported to the Java and .NET virtual machines. Python is 
	free to use, even for commercial products, because of its OSI-approved open source 
	license. Python is an interpreted, interactive, object-oriented programming language. 
= wxPython - a graphical user interface toolkit for the Python programming language. 
	It allows Python programmers to create programs with a robust, highly functional 
	graphical user interface, simply and easily.
= comtypes - a lightweight Python COM package, based on the ctypes FFI library.
	comtypes allows to define, call, and implement custom and dispatch-based 
	COM interfaces in pure Python. It works on Windows and 64-bit Windows. 

If the user allready have installed these modules on the computer, the application can 
be run by launching the compiled file 'Magic_Square.pyc', whithout use of the installer 
Magic_Square_Setup.exe. In this case, the file Magic_Square.pyc file and all application files,
except 'Magic_Square.exe' file, must exist in the same folder.

Application files
-----------------
Magic_Square.exe   The application installation kit
Magic_Square.pyc   The application compiler file (can be used only if the 
                   software packages are installed on the computer).
Readme.txt         This file.
License.txt        The license file.


THE APPLICATION DOES NOT SHARE DATA OVER THE INTERNET, THE CODE 
RUNS ENTIRELY ON THE USER'S COMPUTER, DOES NOT CONTAIN ANY VIRUSES AND NOT 
STORE DATA TO ANY EXTERNAL SERVER.

Magic_Square Installation through the installation kit 'Magic_Square_Setup.exe'
-----------------------------------------------------------------------------

The application was generated and tested through Python 2.7 version installed by 
"Python(x,y)" package (https://python-xy.github.io/. ) on WINDOWS 10 operating 
system, comtypes-0.6.2.

The cx_Freeze application was used to produces a folder containing an executable 
file for the program, along with the shared libraries (DLLs or others files) needed 
to run it. The installation kit is created through the Inno Setup application and 
delivered as a single file "Magic_Square_Setup.exe".

1. The application will be installed via the "Magic_Square_Setup.exe" file.
   All application files will be installed by the application installation kit.
   The application files will be installed on 'Program Files (x86)' folder.
2. An icon will be placed on the desktop to open the application.
3. Launching the application is done by double clicking on the main file 
   "Magic_Square.exe" from the install folder 'Program Files (x86)'  or on the 
    desktop icon created by installer.