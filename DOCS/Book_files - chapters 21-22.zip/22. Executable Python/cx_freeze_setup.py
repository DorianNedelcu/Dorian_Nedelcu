# https://python101.pythonlibrary.org/chapter42_cx_freeze.html

#       CREATING APPLICATION FILES WITH cx_freeze
# 1.  Run as administrator:             cmd
# 2.  Write in cmd:                     E:
# 3.  Write in cmd:                     cd E:\Book_files\Executable Python
# 4.  Write in cmd:                     C:\Python27\python.exe cx_freeze_setup.py build
#     INFO: The 'Magic_Square.pyw' file and 'cx_freeze_setup.py' file must be in the same folder.
# 5.  Application files will be created in the following folder:   build

#        CREATION OF THE INSTALATION KIT WITH Inno Setup
# 1. Launch Inno Setup application 
# 2. Load InnoSetupFile.iss file
# 3. Compile from the application by: menu Build => Compile sau Ctrl+F9
# 4. This will result in the file 'Magic_Square_Setup.exe' in the folder 'Magic_Square_Setup'

from cx_Freeze import setup, Executable

exe = Executable(
    script="Magic_Square.pyw",
    base="Win32GUI",
    )

setup(
    name="Magic_Square",
    version="1.0",
    description="cx_Freeze script for Magic_Square application",
    executables=[exe]
)
print "The Magic_Square files are created in folder:  'build' !"
