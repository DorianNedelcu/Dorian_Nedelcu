package b4a.example.Unfold_Sheets_Parts;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class b4xmainpage extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.Unfold_Sheets_Parts.b4xmainpage");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.Unfold_Sheets_Parts.b4xmainpage.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.Unfold_Sheets_Parts.pag1 _pagina1 = null;
public b4a.example.Unfold_Sheets_Parts.pag2 _pagina2 = null;
public b4a.example.Unfold_Sheets_Parts.pag3 _pagina3 = null;
public b4a.example.Unfold_Sheets_Parts.pag4 _pagina4 = null;
public b4a.example.Unfold_Sheets_Parts.about _pagabout = null;
public b4a.example.Unfold_Sheets_Parts.webpage _pagweb = null;
public String[] _main_menu = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btn_exit = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblresolution = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _main_imgview1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _main_imgview2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _main_imgview3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _main_imgview4 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblabout = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.Unfold_Sheets_Parts.main _main = null;
public b4a.example.Unfold_Sheets_Parts.starter _starter = null;
public b4a.example.Unfold_Sheets_Parts.b4xpages _b4xpages = null;
public b4a.example.Unfold_Sheets_Parts.b4xcollections _b4xcollections = null;
public b4a.example.Unfold_Sheets_Parts.xuiviewsutils _xuiviewsutils = null;
public static class _point{
public boolean IsInitialized;
public float X;
public float Y;
public void Initialize() {
IsInitialized = true;
X = 0f;
Y = 0f;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
String _sname = "";
 //BA.debugLineNum = 33;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 34;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 35;BA.debugLine="Root.LoadLayout(\"MainPage\")";
_root.LoadLayout("MainPage",ba);
 //BA.debugLineNum = 37;BA.debugLine="B4XPages.SetTitle(Me, \"Unfold sheet metal parts\")";
_b4xpages._settitle /*String*/ (ba,this,(Object)("Unfold sheet metal parts"));
 //BA.debugLineNum = 38;BA.debugLine="Root.Color = xui.Color_Blue 'Background pagina pr";
_root.setColor(_xui.Color_Blue);
 //BA.debugLineNum = 40;BA.debugLine="Main_Menu = Array As String(\"Cylinder intersected";
_main_menu = new String[]{"Cylinder intersected by 2 planes","Two cylinders intersection","Three cylinders intersection","Cylindrical elbow","About"};
 //BA.debugLineNum = 43;BA.debugLine="For Each sName As String In Main_Menu";
{
final String[] group6 = _main_menu;
final int groupLen6 = group6.length
;int index6 = 0;
;
for (; index6 < groupLen6;index6++){
_sname = group6[index6];
 //BA.debugLineNum = 44;BA.debugLine="B4XPages.AddMenuItem(Me, sName)";
_b4xpages._addmenuitem /*b4a.example.Unfold_Sheets_Parts.b4xpagesmanager._b4amenuitem*/ (ba,this,(Object)(_sname));
 }
};
 //BA.debugLineNum = 47;BA.debugLine="Pagina1.Initialize";
_pagina1._initialize /*Object*/ (ba);
 //BA.debugLineNum = 48;BA.debugLine="Pagina2.Initialize";
_pagina2._initialize /*Object*/ (ba);
 //BA.debugLineNum = 49;BA.debugLine="Pagina3.Initialize";
_pagina3._initialize /*Object*/ (ba);
 //BA.debugLineNum = 50;BA.debugLine="Pagina4.Initialize";
_pagina4._initialize /*Object*/ (ba);
 //BA.debugLineNum = 51;BA.debugLine="PagAbout.Initialize";
_pagabout._initialize /*Object*/ (ba);
 //BA.debugLineNum = 52;BA.debugLine="PagWeb.Initialize";
_pagweb._initialize /*Object*/ (ba);
 //BA.debugLineNum = 54;BA.debugLine="B4XPages.AddPage(\"idPagina1\", Pagina1)";
_b4xpages._addpage /*String*/ (ba,"idPagina1",(Object)(_pagina1));
 //BA.debugLineNum = 55;BA.debugLine="B4XPages.AddPage(\"idPagina2\", Pagina2)";
_b4xpages._addpage /*String*/ (ba,"idPagina2",(Object)(_pagina2));
 //BA.debugLineNum = 56;BA.debugLine="B4XPages.AddPage(\"idPagina3\", Pagina3)";
_b4xpages._addpage /*String*/ (ba,"idPagina3",(Object)(_pagina3));
 //BA.debugLineNum = 57;BA.debugLine="B4XPages.AddPage(\"idPagina4\", Pagina4)";
_b4xpages._addpage /*String*/ (ba,"idPagina4",(Object)(_pagina4));
 //BA.debugLineNum = 58;BA.debugLine="B4XPages.AddPage(\"idPagAbout\", PagAbout)";
_b4xpages._addpage /*String*/ (ba,"idPagAbout",(Object)(_pagabout));
 //BA.debugLineNum = 59;BA.debugLine="B4XPages.AddPage(\"idPagWeb\", PagWeb)";
_b4xpages._addpage /*String*/ (ba,"idPagWeb",(Object)(_pagweb));
 //BA.debugLineNum = 60;BA.debugLine="lblResolution.Text=(\"Resolution: \"  & Root.Width";
_lblresolution.setText(BA.ObjectToCharSequence(("Resolution: "+BA.NumberToString(_root.getWidth())+"/"+BA.NumberToString(_root.getHeight())+" pixels")));
 //BA.debugLineNum = 61;BA.debugLine="btn_Exit.Color = Colors.Black ' Button background";
_btn_exit.setColor(__c.Colors.Black);
 //BA.debugLineNum = 62;BA.debugLine="btn_Exit.TextColor = Colors.Red  ' Button text co";
_btn_exit.setTextColor(__c.Colors.Red);
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public String  _b4xpage_menuclick(String _tag) throws Exception{
int _iindex = 0;
 //BA.debugLineNum = 65;BA.debugLine="Sub B4XPage_MenuClick (Tag As String)";
 //BA.debugLineNum = 66;BA.debugLine="Dim iIndex As Int = GetIndexInArray(Main_Menu, Ta";
_iindex = _getindexinarray(_main_menu,_tag);
 //BA.debugLineNum = 67;BA.debugLine="Select iIndex";
switch (_iindex) {
case 0: {
 //BA.debugLineNum = 69;BA.debugLine="B4XPages.ShowPage(\"idPagina1\")";
_b4xpages._showpage /*String*/ (ba,"idPagina1");
 break; }
case 1: {
 //BA.debugLineNum = 71;BA.debugLine="B4XPages.ShowPage(\"idPagina2\")";
_b4xpages._showpage /*String*/ (ba,"idPagina2");
 break; }
case 2: {
 //BA.debugLineNum = 73;BA.debugLine="B4XPages.ShowPage(\"idPagina3\")";
_b4xpages._showpage /*String*/ (ba,"idPagina3");
 break; }
case 3: {
 //BA.debugLineNum = 75;BA.debugLine="B4XPages.ShowPage(\"idPagina4\")";
_b4xpages._showpage /*String*/ (ba,"idPagina4");
 break; }
case 4: {
 //BA.debugLineNum = 77;BA.debugLine="B4XPages.ShowPage(\"idPagAbout\")";
_b4xpages._showpage /*String*/ (ba,"idPagAbout");
 break; }
}
;
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return "";
}
public void  _btn_exit_click() throws Exception{
ResumableSub_btn_Exit_Click rsub = new ResumableSub_btn_Exit_Click(this);
rsub.resume(ba, null);
}
public static class ResumableSub_btn_Exit_Click extends BA.ResumableSub {
public ResumableSub_btn_Exit_Click(b4a.example.Unfold_Sheets_Parts.b4xmainpage parent) {
this.parent = parent;
}
b4a.example.Unfold_Sheets_Parts.b4xmainpage parent;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _icon = null;
Object _msj = null;
int _result = 0;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 91;BA.debugLine="Dim icon As B4XBitmap = xui.LoadBitmap(File.DirAs";
_icon = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_icon = parent._xui.LoadBitmap(parent.__c.File.getDirAssets(),"Question.jpg");
 //BA.debugLineNum = 92;BA.debugLine="Dim msj As Object =xui.Msgbox2Async(\"Exit the app";
_msj = parent._xui.Msgbox2Async(ba,BA.ObjectToCharSequence("Exit the application ?"),BA.ObjectToCharSequence("Confirm"),"Yes","","No",(anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper(), (android.graphics.Bitmap)(_icon.getObject())));
 //BA.debugLineNum = 93;BA.debugLine="Wait For (msj) Msgbox_Result (Result As Int)";
parent.__c.WaitFor("msgbox_result", ba, this, _msj);
this.state = 5;
return;
case 5:
//C
this.state = 1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 94;BA.debugLine="If Result = xui.DialogResponse_POSITIVE Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_result==parent._xui.DialogResponse_Positive) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 95;BA.debugLine="B4XPages.ClosePage(Me)";
parent._b4xpages._closepage /*String*/ (ba,parent);
 if (true) break;

case 4:
//C
this.state = -1;
;
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _msgbox_result(int _result) throws Exception{
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private Root As B4XView";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="Private xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 12;BA.debugLine="Public Pagina1 As Pag1";
_pagina1 = new b4a.example.Unfold_Sheets_Parts.pag1();
 //BA.debugLineNum = 13;BA.debugLine="Public Pagina2 As Pag2";
_pagina2 = new b4a.example.Unfold_Sheets_Parts.pag2();
 //BA.debugLineNum = 14;BA.debugLine="Public Pagina3 As Pag3";
_pagina3 = new b4a.example.Unfold_Sheets_Parts.pag3();
 //BA.debugLineNum = 15;BA.debugLine="Public Pagina4 As Pag4";
_pagina4 = new b4a.example.Unfold_Sheets_Parts.pag4();
 //BA.debugLineNum = 16;BA.debugLine="Public PagAbout As About";
_pagabout = new b4a.example.Unfold_Sheets_Parts.about();
 //BA.debugLineNum = 17;BA.debugLine="Public PagWeb As WebPage";
_pagweb = new b4a.example.Unfold_Sheets_Parts.webpage();
 //BA.debugLineNum = 18;BA.debugLine="Private Main_Menu() As String";
_main_menu = new String[(int) (0)];
java.util.Arrays.fill(_main_menu,"");
 //BA.debugLineNum = 19;BA.debugLine="Private btn_Exit As B4XView";
_btn_exit = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private lblResolution As B4XView";
_lblresolution = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Type Point (X As Float, Y As Float)";
;
 //BA.debugLineNum = 22;BA.debugLine="Private Main_ImgView1 As B4XView";
_main_imgview1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Private Main_ImgView2 As B4XView";
_main_imgview2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Private Main_ImgView3 As B4XView";
_main_imgview3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private Main_ImgView4 As B4XView";
_main_imgview4 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private lblAbout As B4XView";
_lblabout = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public int  _getindexinarray(String[] _arr,String _txt) throws Exception{
int _iindex = 0;
int _icount = 0;
String _stxt = "";
 //BA.debugLineNum = 81;BA.debugLine="Sub GetIndexInArray(arr() As String, txt As String";
 //BA.debugLineNum = 82;BA.debugLine="Dim iIndex As Int = -1, iCount As Int = 0";
_iindex = (int) (-1);
_icount = (int) (0);
 //BA.debugLineNum = 83;BA.debugLine="For Each sTxt As String In arr";
{
final String[] group2 = _arr;
final int groupLen2 = group2.length
;int index2 = 0;
;
for (; index2 < groupLen2;index2++){
_stxt = group2[index2];
 //BA.debugLineNum = 84;BA.debugLine="If sTxt = txt Then iIndex = iCount";
if ((_stxt).equals(_txt)) { 
_iindex = _icount;};
 //BA.debugLineNum = 85;BA.debugLine="iCount = iCount + 1";
_icount = (int) (_icount+1);
 }
};
 //BA.debugLineNum = 87;BA.debugLine="Return iIndex";
if (true) return _iindex;
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return 0;
}
public String  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 29;BA.debugLine="Public Sub Initialize";
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return "";
}
public String  _lblabout_click() throws Exception{
 //BA.debugLineNum = 111;BA.debugLine="Private Sub lblAbout_Click";
 //BA.debugLineNum = 112;BA.debugLine="B4XPages.ShowPage(\"idPagAbout\")";
_b4xpages._showpage /*String*/ (ba,"idPagAbout");
 //BA.debugLineNum = 113;BA.debugLine="End Sub";
return "";
}
public String  _main_imgview1_click() throws Exception{
 //BA.debugLineNum = 99;BA.debugLine="Private Sub Main_ImgView1_Click";
 //BA.debugLineNum = 100;BA.debugLine="B4XPages.ShowPage(\"idPagina1\")";
_b4xpages._showpage /*String*/ (ba,"idPagina1");
 //BA.debugLineNum = 101;BA.debugLine="End Sub";
return "";
}
public String  _main_imgview2_click() throws Exception{
 //BA.debugLineNum = 102;BA.debugLine="Private Sub Main_ImgView2_Click";
 //BA.debugLineNum = 103;BA.debugLine="B4XPages.ShowPage(\"idPagina2\")";
_b4xpages._showpage /*String*/ (ba,"idPagina2");
 //BA.debugLineNum = 104;BA.debugLine="End Sub";
return "";
}
public String  _main_imgview3_click() throws Exception{
 //BA.debugLineNum = 105;BA.debugLine="Private Sub Main_ImgView3_Click";
 //BA.debugLineNum = 106;BA.debugLine="B4XPages.ShowPage(\"idPagina3\")";
_b4xpages._showpage /*String*/ (ba,"idPagina3");
 //BA.debugLineNum = 107;BA.debugLine="End Sub";
return "";
}
public String  _main_imgview4_click() throws Exception{
 //BA.debugLineNum = 108;BA.debugLine="Private Sub Main_ImgView4_Click";
 //BA.debugLineNum = 109;BA.debugLine="B4XPages.ShowPage(\"idPagina4\")";
_b4xpages._showpage /*String*/ (ba,"idPagina4");
 //BA.debugLineNum = 110;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
