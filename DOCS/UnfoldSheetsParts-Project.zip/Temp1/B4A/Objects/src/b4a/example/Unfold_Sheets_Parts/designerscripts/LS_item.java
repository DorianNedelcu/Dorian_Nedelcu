package b4a.example.Unfold_Sheets_Parts.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_item{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("item1").vw.setWidth((int)((28d / 100 * width)));
views.get("item1").vw.setHeight((int)((40d * scale)));
views.get("item1").vw.setLeft((int)(0d));
views.get("item1").vw.setTop((int)(0d));
views.get("item2").vw.setWidth((int)((25d / 100 * width)));
views.get("item2").vw.setHeight((int)((40d * scale)));
views.get("item2").vw.setLeft((int)((views.get("item1").vw.getLeft() + views.get("item1").vw.getWidth())+(3d * scale)));
views.get("item2").vw.setTop((int)(0d));
views.get("item3").vw.setWidth((int)((28d / 100 * width)));
views.get("item3").vw.setHeight((int)((40d * scale)));
views.get("item3").vw.setLeft((int)((views.get("item2").vw.getLeft() + views.get("item2").vw.getWidth())+(3d * scale)));
views.get("item3").vw.setTop((int)(0d));

}
}