package b4a.example.Unfold_Sheets_Parts.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_lay1{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _wlbl="";
String _wtxt="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("imageview").vw.setWidth((int)((60d / 100 * width)));
views.get("imageview").vw.setHeight((int)((45d / 100 * height)));
views.get("imageview").vw.setTop((int)((0d / 100 * height)+(1d * scale)));
views.get("imageview").vw.setLeft((int)((20d / 100 * width)));
views.get("btncalculate").vw.setHeight((int)((60d * scale)));
views.get("btncalculate").vw.setWidth((int)((75d / 100 * width)));
views.get("btncalculate").vw.setTop((int)((views.get("imageview").vw.getTop() + views.get("imageview").vw.getHeight())+(5d * scale)));
views.get("btncalculate").vw.setLeft((int)(((100d / 100 * width)-(views.get("btncalculate").vw.getWidth()))/2d));
views.get("pnldrawing").vw.setHeight((int)((40d / 100 * height)));
views.get("pnldrawing").vw.setWidth((int)((100d / 100 * width)));
views.get("pnldrawing").vw.setTop((int)((55d / 100 * height)));
views.get("pnldrawing").vw.setLeft((int)((1d / 100 * width)));
views.get("pnldrawing").vw.setVisible(BA.parseBoolean("false"));
views.get("lblxy").vw.setHeight((int)((30d * scale)));
views.get("lblxy").vw.setWidth((int)((100d * scale)));
//BA.debugLineNum = 11;BA.debugLine="lblXY.Height = 30dip : lblXY.Width = 100dip : lblXY.Top = 15dip : lblXY.Right = 100%X-5dip"[lay1/General script]
views.get("lblxy").vw.setTop((int)((15d * scale)));
//BA.debugLineNum = 11;BA.debugLine="lblXY.Height = 30dip : lblXY.Width = 100dip : lblXY.Top = 15dip : lblXY.Right = 100%X-5dip"[lay1/General script]
views.get("lblxy").vw.setLeft((int)((100d / 100 * width)-(5d * scale) - (views.get("lblxy").vw.getWidth())));
//BA.debugLineNum = 13;BA.debugLine="ImgFolded.Width=pnlDrawing.Width: ImgFolded.Height=pnlDrawing.Height :  ImgFolded.Left=pnlDrawing.left : ImgFolded.Top=pnlDrawing.Top"[lay1/General script]
views.get("imgfolded").vw.setWidth((int)((views.get("pnldrawing").vw.getWidth())));
//BA.debugLineNum = 13;BA.debugLine="ImgFolded.Width=pnlDrawing.Width: ImgFolded.Height=pnlDrawing.Height :  ImgFolded.Left=pnlDrawing.left : ImgFolded.Top=pnlDrawing.Top"[lay1/General script]
views.get("imgfolded").vw.setHeight((int)((views.get("pnldrawing").vw.getHeight())));
//BA.debugLineNum = 13;BA.debugLine="ImgFolded.Width=pnlDrawing.Width: ImgFolded.Height=pnlDrawing.Height :  ImgFolded.Left=pnlDrawing.left : ImgFolded.Top=pnlDrawing.Top"[lay1/General script]
views.get("imgfolded").vw.setLeft((int)((views.get("pnldrawing").vw.getLeft())));
//BA.debugLineNum = 13;BA.debugLine="ImgFolded.Width=pnlDrawing.Width: ImgFolded.Height=pnlDrawing.Height :  ImgFolded.Left=pnlDrawing.left : ImgFolded.Top=pnlDrawing.Top"[lay1/General script]
views.get("imgfolded").vw.setTop((int)((views.get("pnldrawing").vw.getTop())));
//BA.debugLineNum = 14;BA.debugLine="ImgFolded.Visible=True"[lay1/General script]
views.get("imgfolded").vw.setVisible(BA.parseBoolean("true"));
//BA.debugLineNum = 17;BA.debugLine="Wlbl = 30%X : Wtxt=30%X"[lay1/General script]
_wlbl = BA.NumberToString((30d / 100 * width));
//BA.debugLineNum = 17;BA.debugLine="Wlbl = 30%X : Wtxt=30%X"[lay1/General script]
_wtxt = BA.NumberToString((30d / 100 * width));
//BA.debugLineNum = 19;BA.debugLine="lblInputData.Width=100%X"[lay1/General script]
views.get("lblinputdata").vw.setWidth((int)((100d / 100 * width)));
//BA.debugLineNum = 21;BA.debugLine="pnlInputData.Width=70%X  : pnlInputData.Height=260dip :  pnlInputData.Left=(100%X-pnlInputData.Width)/2 : pnlInputData.Top=btnCalculate.top"[lay1/General script]
views.get("pnlinputdata").vw.setWidth((int)((70d / 100 * width)));
//BA.debugLineNum = 21;BA.debugLine="pnlInputData.Width=70%X  : pnlInputData.Height=260dip :  pnlInputData.Left=(100%X-pnlInputData.Width)/2 : pnlInputData.Top=btnCalculate.top"[lay1/General script]
views.get("pnlinputdata").vw.setHeight((int)((260d * scale)));
//BA.debugLineNum = 21;BA.debugLine="pnlInputData.Width=70%X  : pnlInputData.Height=260dip :  pnlInputData.Left=(100%X-pnlInputData.Width)/2 : pnlInputData.Top=btnCalculate.top"[lay1/General script]
views.get("pnlinputdata").vw.setLeft((int)(((100d / 100 * width)-(views.get("pnlinputdata").vw.getWidth()))/2d));
//BA.debugLineNum = 21;BA.debugLine="pnlInputData.Width=70%X  : pnlInputData.Height=260dip :  pnlInputData.Left=(100%X-pnlInputData.Width)/2 : pnlInputData.Top=btnCalculate.top"[lay1/General script]
views.get("pnlinputdata").vw.setTop((int)((views.get("btncalculate").vw.getTop())));
//BA.debugLineNum = 23;BA.debugLine="lblDiameter.width=Wlbl  : lblDiameter.Height=40dip :  lblDiameter.Left=3%X : lblDiameter.Top=lblInputData.Bottom"[lay1/General script]
views.get("lbldiameter").vw.setWidth((int)(Double.parseDouble(_wlbl)));
//BA.debugLineNum = 23;BA.debugLine="lblDiameter.width=Wlbl  : lblDiameter.Height=40dip :  lblDiameter.Left=3%X : lblDiameter.Top=lblInputData.Bottom"[lay1/General script]
views.get("lbldiameter").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 23;BA.debugLine="lblDiameter.width=Wlbl  : lblDiameter.Height=40dip :  lblDiameter.Left=3%X : lblDiameter.Top=lblInputData.Bottom"[lay1/General script]
views.get("lbldiameter").vw.setLeft((int)((3d / 100 * width)));
//BA.debugLineNum = 23;BA.debugLine="lblDiameter.width=Wlbl  : lblDiameter.Height=40dip :  lblDiameter.Left=3%X : lblDiameter.Top=lblInputData.Bottom"[lay1/General script]
views.get("lbldiameter").vw.setTop((int)((views.get("lblinputdata").vw.getTop() + views.get("lblinputdata").vw.getHeight())));
//BA.debugLineNum = 24;BA.debugLine="lblHeight.width=Wlbl  : lblHeight.Height=40dip :  lblHeight.Left=3%X : lblHeight.Top=lblDiameter.Bottom"[lay1/General script]
views.get("lblheight").vw.setWidth((int)(Double.parseDouble(_wlbl)));
//BA.debugLineNum = 24;BA.debugLine="lblHeight.width=Wlbl  : lblHeight.Height=40dip :  lblHeight.Left=3%X : lblHeight.Top=lblDiameter.Bottom"[lay1/General script]
views.get("lblheight").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 24;BA.debugLine="lblHeight.width=Wlbl  : lblHeight.Height=40dip :  lblHeight.Left=3%X : lblHeight.Top=lblDiameter.Bottom"[lay1/General script]
views.get("lblheight").vw.setLeft((int)((3d / 100 * width)));
//BA.debugLineNum = 24;BA.debugLine="lblHeight.width=Wlbl  : lblHeight.Height=40dip :  lblHeight.Left=3%X : lblHeight.Top=lblDiameter.Bottom"[lay1/General script]
views.get("lblheight").vw.setTop((int)((views.get("lbldiameter").vw.getTop() + views.get("lbldiameter").vw.getHeight())));
//BA.debugLineNum = 25;BA.debugLine="lblAlfa.width=Wlbl  : lblAlfa.Height=40dip :  lblAlfa.Left=3%X : lblAlfa.Top=lblHeight.Bottom"[lay1/General script]
views.get("lblalfa").vw.setWidth((int)(Double.parseDouble(_wlbl)));
//BA.debugLineNum = 25;BA.debugLine="lblAlfa.width=Wlbl  : lblAlfa.Height=40dip :  lblAlfa.Left=3%X : lblAlfa.Top=lblHeight.Bottom"[lay1/General script]
views.get("lblalfa").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 25;BA.debugLine="lblAlfa.width=Wlbl  : lblAlfa.Height=40dip :  lblAlfa.Left=3%X : lblAlfa.Top=lblHeight.Bottom"[lay1/General script]
views.get("lblalfa").vw.setLeft((int)((3d / 100 * width)));
//BA.debugLineNum = 25;BA.debugLine="lblAlfa.width=Wlbl  : lblAlfa.Height=40dip :  lblAlfa.Left=3%X : lblAlfa.Top=lblHeight.Bottom"[lay1/General script]
views.get("lblalfa").vw.setTop((int)((views.get("lblheight").vw.getTop() + views.get("lblheight").vw.getHeight())));
//BA.debugLineNum = 26;BA.debugLine="lblBeta.width=Wlbl  : lblBeta.Height=40dip :  lblBeta.Left=3%X : lblBeta.Top=lblAlfa.Bottom"[lay1/General script]
views.get("lblbeta").vw.setWidth((int)(Double.parseDouble(_wlbl)));
//BA.debugLineNum = 26;BA.debugLine="lblBeta.width=Wlbl  : lblBeta.Height=40dip :  lblBeta.Left=3%X : lblBeta.Top=lblAlfa.Bottom"[lay1/General script]
views.get("lblbeta").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 26;BA.debugLine="lblBeta.width=Wlbl  : lblBeta.Height=40dip :  lblBeta.Left=3%X : lblBeta.Top=lblAlfa.Bottom"[lay1/General script]
views.get("lblbeta").vw.setLeft((int)((3d / 100 * width)));
//BA.debugLineNum = 26;BA.debugLine="lblBeta.width=Wlbl  : lblBeta.Height=40dip :  lblBeta.Left=3%X : lblBeta.Top=lblAlfa.Bottom"[lay1/General script]
views.get("lblbeta").vw.setTop((int)((views.get("lblalfa").vw.getTop() + views.get("lblalfa").vw.getHeight())));
//BA.debugLineNum = 28;BA.debugLine="txtDiameter.width=Wtxt : txtDiameter.Height=40dip :  txtDiameter.Left=lblDiameter.Right : txtDiameter.Top=lblInputData.Bottom"[lay1/General script]
views.get("txtdiameter").vw.setWidth((int)(Double.parseDouble(_wtxt)));
//BA.debugLineNum = 28;BA.debugLine="txtDiameter.width=Wtxt : txtDiameter.Height=40dip :  txtDiameter.Left=lblDiameter.Right : txtDiameter.Top=lblInputData.Bottom"[lay1/General script]
views.get("txtdiameter").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 28;BA.debugLine="txtDiameter.width=Wtxt : txtDiameter.Height=40dip :  txtDiameter.Left=lblDiameter.Right : txtDiameter.Top=lblInputData.Bottom"[lay1/General script]
views.get("txtdiameter").vw.setLeft((int)((views.get("lbldiameter").vw.getLeft() + views.get("lbldiameter").vw.getWidth())));
//BA.debugLineNum = 28;BA.debugLine="txtDiameter.width=Wtxt : txtDiameter.Height=40dip :  txtDiameter.Left=lblDiameter.Right : txtDiameter.Top=lblInputData.Bottom"[lay1/General script]
views.get("txtdiameter").vw.setTop((int)((views.get("lblinputdata").vw.getTop() + views.get("lblinputdata").vw.getHeight())));
//BA.debugLineNum = 29;BA.debugLine="txtHeight.width=Wtxt : txtHeight.Height=40dip :  txtHeight.Left=lblHeight.Right : txtHeight.Top=txtDiameter.Bottom"[lay1/General script]
views.get("txtheight").vw.setWidth((int)(Double.parseDouble(_wtxt)));
//BA.debugLineNum = 29;BA.debugLine="txtHeight.width=Wtxt : txtHeight.Height=40dip :  txtHeight.Left=lblHeight.Right : txtHeight.Top=txtDiameter.Bottom"[lay1/General script]
views.get("txtheight").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 29;BA.debugLine="txtHeight.width=Wtxt : txtHeight.Height=40dip :  txtHeight.Left=lblHeight.Right : txtHeight.Top=txtDiameter.Bottom"[lay1/General script]
views.get("txtheight").vw.setLeft((int)((views.get("lblheight").vw.getLeft() + views.get("lblheight").vw.getWidth())));
//BA.debugLineNum = 29;BA.debugLine="txtHeight.width=Wtxt : txtHeight.Height=40dip :  txtHeight.Left=lblHeight.Right : txtHeight.Top=txtDiameter.Bottom"[lay1/General script]
views.get("txtheight").vw.setTop((int)((views.get("txtdiameter").vw.getTop() + views.get("txtdiameter").vw.getHeight())));
//BA.debugLineNum = 30;BA.debugLine="txtAlfa.width=Wtxt : txtAlfa.Height=40dip :  txtAlfa.Left=lblAlfa.Right : txtAlfa.Top=txtHeight.Bottom"[lay1/General script]
views.get("txtalfa").vw.setWidth((int)(Double.parseDouble(_wtxt)));
//BA.debugLineNum = 30;BA.debugLine="txtAlfa.width=Wtxt : txtAlfa.Height=40dip :  txtAlfa.Left=lblAlfa.Right : txtAlfa.Top=txtHeight.Bottom"[lay1/General script]
views.get("txtalfa").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 30;BA.debugLine="txtAlfa.width=Wtxt : txtAlfa.Height=40dip :  txtAlfa.Left=lblAlfa.Right : txtAlfa.Top=txtHeight.Bottom"[lay1/General script]
views.get("txtalfa").vw.setLeft((int)((views.get("lblalfa").vw.getLeft() + views.get("lblalfa").vw.getWidth())));
//BA.debugLineNum = 30;BA.debugLine="txtAlfa.width=Wtxt : txtAlfa.Height=40dip :  txtAlfa.Left=lblAlfa.Right : txtAlfa.Top=txtHeight.Bottom"[lay1/General script]
views.get("txtalfa").vw.setTop((int)((views.get("txtheight").vw.getTop() + views.get("txtheight").vw.getHeight())));
//BA.debugLineNum = 31;BA.debugLine="txtBeta.width=Wtxt : txtBeta.Height=40dip :  txtBeta.Left=lblBeta.Right : txtBeta.Top=txtAlfa.Bottom"[lay1/General script]
views.get("txtbeta").vw.setWidth((int)(Double.parseDouble(_wtxt)));
//BA.debugLineNum = 31;BA.debugLine="txtBeta.width=Wtxt : txtBeta.Height=40dip :  txtBeta.Left=lblBeta.Right : txtBeta.Top=txtAlfa.Bottom"[lay1/General script]
views.get("txtbeta").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 31;BA.debugLine="txtBeta.width=Wtxt : txtBeta.Height=40dip :  txtBeta.Left=lblBeta.Right : txtBeta.Top=txtAlfa.Bottom"[lay1/General script]
views.get("txtbeta").vw.setLeft((int)((views.get("lblbeta").vw.getLeft() + views.get("lblbeta").vw.getWidth())));
//BA.debugLineNum = 31;BA.debugLine="txtBeta.width=Wtxt : txtBeta.Height=40dip :  txtBeta.Left=lblBeta.Right : txtBeta.Top=txtAlfa.Bottom"[lay1/General script]
views.get("txtbeta").vw.setTop((int)((views.get("txtalfa").vw.getTop() + views.get("txtalfa").vw.getHeight())));
//BA.debugLineNum = 33;BA.debugLine="btnCalculateID.width=30%X : btnCalculateID.Height=40dip :  btnCalculateID.Left=2%X : btnCalculateID.Top=lblBeta.Bottom"[lay1/General script]
views.get("btncalculateid").vw.setWidth((int)((30d / 100 * width)));
//BA.debugLineNum = 33;BA.debugLine="btnCalculateID.width=30%X : btnCalculateID.Height=40dip :  btnCalculateID.Left=2%X : btnCalculateID.Top=lblBeta.Bottom"[lay1/General script]
views.get("btncalculateid").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 33;BA.debugLine="btnCalculateID.width=30%X : btnCalculateID.Height=40dip :  btnCalculateID.Left=2%X : btnCalculateID.Top=lblBeta.Bottom"[lay1/General script]
views.get("btncalculateid").vw.setLeft((int)((2d / 100 * width)));
//BA.debugLineNum = 33;BA.debugLine="btnCalculateID.width=30%X : btnCalculateID.Height=40dip :  btnCalculateID.Left=2%X : btnCalculateID.Top=lblBeta.Bottom"[lay1/General script]
views.get("btncalculateid").vw.setTop((int)((views.get("lblbeta").vw.getTop() + views.get("lblbeta").vw.getHeight())));
//BA.debugLineNum = 34;BA.debugLine="btnCancelID.width=30%X : btnCancelID.Height=40dip : btnCancelID.Top=btnCalculateID.Top :  btnCancelID.Left = btnCalculateID.Right+5dip"[lay1/General script]
views.get("btncancelid").vw.setWidth((int)((30d / 100 * width)));
//BA.debugLineNum = 34;BA.debugLine="btnCancelID.width=30%X : btnCancelID.Height=40dip : btnCancelID.Top=btnCalculateID.Top :  btnCancelID.Left = btnCalculateID.Right+5dip"[lay1/General script]
views.get("btncancelid").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 34;BA.debugLine="btnCancelID.width=30%X : btnCancelID.Height=40dip : btnCancelID.Top=btnCalculateID.Top :  btnCancelID.Left = btnCalculateID.Right+5dip"[lay1/General script]
views.get("btncancelid").vw.setTop((int)((views.get("btncalculateid").vw.getTop())));
//BA.debugLineNum = 34;BA.debugLine="btnCancelID.width=30%X : btnCancelID.Height=40dip : btnCancelID.Top=btnCalculateID.Top :  btnCancelID.Left = btnCalculateID.Right+5dip"[lay1/General script]
views.get("btncancelid").vw.setLeft((int)((views.get("btncalculateid").vw.getLeft() + views.get("btncalculateid").vw.getWidth())+(5d * scale)));
//BA.debugLineNum = 37;BA.debugLine="pnlRadioButton.Width=120dip  : pnlRadioButton.Height=80dip :  pnlRadioButton.Left=1%X : pnlRadioButton.Top=1%Y"[lay1/General script]
views.get("pnlradiobutton").vw.setWidth((int)((120d * scale)));
//BA.debugLineNum = 37;BA.debugLine="pnlRadioButton.Width=120dip  : pnlRadioButton.Height=80dip :  pnlRadioButton.Left=1%X : pnlRadioButton.Top=1%Y"[lay1/General script]
views.get("pnlradiobutton").vw.setHeight((int)((80d * scale)));
//BA.debugLineNum = 37;BA.debugLine="pnlRadioButton.Width=120dip  : pnlRadioButton.Height=80dip :  pnlRadioButton.Left=1%X : pnlRadioButton.Top=1%Y"[lay1/General script]
views.get("pnlradiobutton").vw.setLeft((int)((1d / 100 * width)));
//BA.debugLineNum = 37;BA.debugLine="pnlRadioButton.Width=120dip  : pnlRadioButton.Height=80dip :  pnlRadioButton.Left=1%X : pnlRadioButton.Top=1%Y"[lay1/General script]
views.get("pnlradiobutton").vw.setTop((int)((1d / 100 * height)));
//BA.debugLineNum = 38;BA.debugLine="RadioButton1.Width=110dip  : RadioButton1.Height=35dip:  RadioButton1.Left=5dip : RadioButton1.Top=1%x"[lay1/General script]
views.get("radiobutton1").vw.setWidth((int)((110d * scale)));
//BA.debugLineNum = 38;BA.debugLine="RadioButton1.Width=110dip  : RadioButton1.Height=35dip:  RadioButton1.Left=5dip : RadioButton1.Top=1%x"[lay1/General script]
views.get("radiobutton1").vw.setHeight((int)((35d * scale)));
//BA.debugLineNum = 38;BA.debugLine="RadioButton1.Width=110dip  : RadioButton1.Height=35dip:  RadioButton1.Left=5dip : RadioButton1.Top=1%x"[lay1/General script]
views.get("radiobutton1").vw.setLeft((int)((5d * scale)));
//BA.debugLineNum = 38;BA.debugLine="RadioButton1.Width=110dip  : RadioButton1.Height=35dip:  RadioButton1.Left=5dip : RadioButton1.Top=1%x"[lay1/General script]
views.get("radiobutton1").vw.setTop((int)((1d / 100 * width)));
//BA.debugLineNum = 39;BA.debugLine="RadioButton2.Width=RadioButton1.Width  : RadioButton2.Height=RadioButton1.Height :  RadioButton2.Left=RadioButton1.Left : RadioButton2.Top=RadioButton1.Bottom+1dip"[lay1/General script]
views.get("radiobutton2").vw.setWidth((int)((views.get("radiobutton1").vw.getWidth())));
//BA.debugLineNum = 39;BA.debugLine="RadioButton2.Width=RadioButton1.Width  : RadioButton2.Height=RadioButton1.Height :  RadioButton2.Left=RadioButton1.Left : RadioButton2.Top=RadioButton1.Bottom+1dip"[lay1/General script]
views.get("radiobutton2").vw.setHeight((int)((views.get("radiobutton1").vw.getHeight())));
//BA.debugLineNum = 39;BA.debugLine="RadioButton2.Width=RadioButton1.Width  : RadioButton2.Height=RadioButton1.Height :  RadioButton2.Left=RadioButton1.Left : RadioButton2.Top=RadioButton1.Bottom+1dip"[lay1/General script]
views.get("radiobutton2").vw.setLeft((int)((views.get("radiobutton1").vw.getLeft())));
//BA.debugLineNum = 39;BA.debugLine="RadioButton2.Width=RadioButton1.Width  : RadioButton2.Height=RadioButton1.Height :  RadioButton2.Left=RadioButton1.Left : RadioButton2.Top=RadioButton1.Bottom+1dip"[lay1/General script]
views.get("radiobutton2").vw.setTop((int)((views.get("radiobutton1").vw.getTop() + views.get("radiobutton1").vw.getHeight())+(1d * scale)));
//BA.debugLineNum = 41;BA.debugLine="pnlDemo.Width=95%X  : pnlDemo.Height=50%Y :  pnlDemo.Left=(100%X-pnlDemo.Width)/2 : pnlDemo.Top=(100%Y-pnlDemo.Height)/2"[lay1/General script]
views.get("pnldemo").vw.setWidth((int)((95d / 100 * width)));
//BA.debugLineNum = 41;BA.debugLine="pnlDemo.Width=95%X  : pnlDemo.Height=50%Y :  pnlDemo.Left=(100%X-pnlDemo.Width)/2 : pnlDemo.Top=(100%Y-pnlDemo.Height)/2"[lay1/General script]
views.get("pnldemo").vw.setHeight((int)((50d / 100 * height)));
//BA.debugLineNum = 41;BA.debugLine="pnlDemo.Width=95%X  : pnlDemo.Height=50%Y :  pnlDemo.Left=(100%X-pnlDemo.Width)/2 : pnlDemo.Top=(100%Y-pnlDemo.Height)/2"[lay1/General script]
views.get("pnldemo").vw.setLeft((int)(((100d / 100 * width)-(views.get("pnldemo").vw.getWidth()))/2d));
//BA.debugLineNum = 41;BA.debugLine="pnlDemo.Width=95%X  : pnlDemo.Height=50%Y :  pnlDemo.Left=(100%X-pnlDemo.Width)/2 : pnlDemo.Top=(100%Y-pnlDemo.Height)/2"[lay1/General script]
views.get("pnldemo").vw.setTop((int)(((100d / 100 * height)-(views.get("pnldemo").vw.getHeight()))/2d));
//BA.debugLineNum = 42;BA.debugLine="ImgDemo.Width=91%X  : ImgDemo.Height=40%Y :  ImgDemo.Left=2%X : ImgDemo.Top=2%Y  ' (100%X-ImgDemo.Width)/2  (100%Y-ImgDemo.Height)/2"[lay1/General script]
views.get("imgdemo").vw.setWidth((int)((91d / 100 * width)));
//BA.debugLineNum = 42;BA.debugLine="ImgDemo.Width=91%X  : ImgDemo.Height=40%Y :  ImgDemo.Left=2%X : ImgDemo.Top=2%Y  ' (100%X-ImgDemo.Width)/2  (100%Y-ImgDemo.Height)/2"[lay1/General script]
views.get("imgdemo").vw.setHeight((int)((40d / 100 * height)));
//BA.debugLineNum = 42;BA.debugLine="ImgDemo.Width=91%X  : ImgDemo.Height=40%Y :  ImgDemo.Left=2%X : ImgDemo.Top=2%Y  ' (100%X-ImgDemo.Width)/2  (100%Y-ImgDemo.Height)/2"[lay1/General script]
views.get("imgdemo").vw.setLeft((int)((2d / 100 * width)));
//BA.debugLineNum = 42;BA.debugLine="ImgDemo.Width=91%X  : ImgDemo.Height=40%Y :  ImgDemo.Left=2%X : ImgDemo.Top=2%Y  ' (100%X-ImgDemo.Width)/2  (100%Y-ImgDemo.Height)/2"[lay1/General script]
views.get("imgdemo").vw.setTop((int)((2d / 100 * height)));
//BA.debugLineNum = 43;BA.debugLine="btnExitDemo.Width=110dip  : btnExitDemo.Height=40dip:  btnExitDemo.Left=(pnlDemo.Width-btnExitDemo.Width)/2 : btnExitDemo.Top=ImgDemo.Bottom+10dip"[lay1/General script]
views.get("btnexitdemo").vw.setWidth((int)((110d * scale)));
//BA.debugLineNum = 43;BA.debugLine="btnExitDemo.Width=110dip  : btnExitDemo.Height=40dip:  btnExitDemo.Left=(pnlDemo.Width-btnExitDemo.Width)/2 : btnExitDemo.Top=ImgDemo.Bottom+10dip"[lay1/General script]
views.get("btnexitdemo").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 43;BA.debugLine="btnExitDemo.Width=110dip  : btnExitDemo.Height=40dip:  btnExitDemo.Left=(pnlDemo.Width-btnExitDemo.Width)/2 : btnExitDemo.Top=ImgDemo.Bottom+10dip"[lay1/General script]
views.get("btnexitdemo").vw.setLeft((int)(((views.get("pnldemo").vw.getWidth())-(views.get("btnexitdemo").vw.getWidth()))/2d));
//BA.debugLineNum = 43;BA.debugLine="btnExitDemo.Width=110dip  : btnExitDemo.Height=40dip:  btnExitDemo.Left=(pnlDemo.Width-btnExitDemo.Width)/2 : btnExitDemo.Top=ImgDemo.Bottom+10dip"[lay1/General script]
views.get("btnexitdemo").vw.setTop((int)((views.get("imgdemo").vw.getTop() + views.get("imgdemo").vw.getHeight())+(10d * scale)));
//BA.debugLineNum = 44;BA.debugLine="btnLoadDemo.Width=50dip : btnLoadDemo.Height=50dip : btnLoadDemo.left=ImageView.Right+5dip : btnLoadDemo.Top=ImageView.Top"[lay1/General script]
views.get("btnloaddemo").vw.setWidth((int)((50d * scale)));
//BA.debugLineNum = 44;BA.debugLine="btnLoadDemo.Width=50dip : btnLoadDemo.Height=50dip : btnLoadDemo.left=ImageView.Right+5dip : btnLoadDemo.Top=ImageView.Top"[lay1/General script]
views.get("btnloaddemo").vw.setHeight((int)((50d * scale)));
//BA.debugLineNum = 44;BA.debugLine="btnLoadDemo.Width=50dip : btnLoadDemo.Height=50dip : btnLoadDemo.left=ImageView.Right+5dip : btnLoadDemo.Top=ImageView.Top"[lay1/General script]
views.get("btnloaddemo").vw.setLeft((int)((views.get("imageview").vw.getLeft() + views.get("imageview").vw.getWidth())+(5d * scale)));
//BA.debugLineNum = 44;BA.debugLine="btnLoadDemo.Width=50dip : btnLoadDemo.Height=50dip : btnLoadDemo.left=ImageView.Right+5dip : btnLoadDemo.Top=ImageView.Top"[lay1/General script]
views.get("btnloaddemo").vw.setTop((int)((views.get("imageview").vw.getTop())));
//BA.debugLineNum = 46;BA.debugLine="pnlTabel.Width=95%X  : pnlTabel.Height=80%Y  :  pnlTabel.Left=2.5%X : pnlTabel.Top=10%Y"[lay1/General script]
views.get("pnltabel").vw.setWidth((int)((95d / 100 * width)));
//BA.debugLineNum = 46;BA.debugLine="pnlTabel.Width=95%X  : pnlTabel.Height=80%Y  :  pnlTabel.Left=2.5%X : pnlTabel.Top=10%Y"[lay1/General script]
views.get("pnltabel").vw.setHeight((int)((80d / 100 * height)));
//BA.debugLineNum = 46;BA.debugLine="pnlTabel.Width=95%X  : pnlTabel.Height=80%Y  :  pnlTabel.Left=2.5%X : pnlTabel.Top=10%Y"[lay1/General script]
views.get("pnltabel").vw.setLeft((int)((2.5d / 100 * width)));
//BA.debugLineNum = 46;BA.debugLine="pnlTabel.Width=95%X  : pnlTabel.Height=80%Y  :  pnlTabel.Left=2.5%X : pnlTabel.Top=10%Y"[lay1/General script]
views.get("pnltabel").vw.setTop((int)((10d / 100 * height)));
//BA.debugLineNum = 47;BA.debugLine="clvTabel.Width=85%X  : clvTabel.Height=70%Y  :  clvTabel.Left=2.5%X: clvTabel.Top=3%X"[lay1/General script]
views.get("clvtabel").vw.setWidth((int)((85d / 100 * width)));
//BA.debugLineNum = 47;BA.debugLine="clvTabel.Width=85%X  : clvTabel.Height=70%Y  :  clvTabel.Left=2.5%X: clvTabel.Top=3%X"[lay1/General script]
views.get("clvtabel").vw.setHeight((int)((70d / 100 * height)));
//BA.debugLineNum = 47;BA.debugLine="clvTabel.Width=85%X  : clvTabel.Height=70%Y  :  clvTabel.Left=2.5%X: clvTabel.Top=3%X"[lay1/General script]
views.get("clvtabel").vw.setLeft((int)((2.5d / 100 * width)));
//BA.debugLineNum = 47;BA.debugLine="clvTabel.Width=85%X  : clvTabel.Height=70%Y  :  clvTabel.Left=2.5%X: clvTabel.Top=3%X"[lay1/General script]
views.get("clvtabel").vw.setTop((int)((3d / 100 * width)));
//BA.debugLineNum = 48;BA.debugLine="btnExitTabel.Width=40%X  : btnExitTabel.Height=40dip  :  btnExitTabel.Left=30%X : btnExitTabel.Top=clvTabel.Bottom+5dip"[lay1/General script]
views.get("btnexittabel").vw.setWidth((int)((40d / 100 * width)));
//BA.debugLineNum = 48;BA.debugLine="btnExitTabel.Width=40%X  : btnExitTabel.Height=40dip  :  btnExitTabel.Left=30%X : btnExitTabel.Top=clvTabel.Bottom+5dip"[lay1/General script]
views.get("btnexittabel").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 48;BA.debugLine="btnExitTabel.Width=40%X  : btnExitTabel.Height=40dip  :  btnExitTabel.Left=30%X : btnExitTabel.Top=clvTabel.Bottom+5dip"[lay1/General script]
views.get("btnexittabel").vw.setLeft((int)((30d / 100 * width)));
//BA.debugLineNum = 48;BA.debugLine="btnExitTabel.Width=40%X  : btnExitTabel.Height=40dip  :  btnExitTabel.Left=30%X : btnExitTabel.Top=clvTabel.Bottom+5dip"[lay1/General script]
views.get("btnexittabel").vw.setTop((int)((views.get("clvtabel").vw.getTop() + views.get("clvtabel").vw.getHeight())+(5d * scale)));
//BA.debugLineNum = 50;BA.debugLine="btnTabel.Width=120dip  : btnTabel.Height=50dip :  btnTabel.Left=1%X : btnTabel.Top=pnlRadioButton.Bottom+5dip"[lay1/General script]
views.get("btntabel").vw.setWidth((int)((120d * scale)));
//BA.debugLineNum = 50;BA.debugLine="btnTabel.Width=120dip  : btnTabel.Height=50dip :  btnTabel.Left=1%X : btnTabel.Top=pnlRadioButton.Bottom+5dip"[lay1/General script]
views.get("btntabel").vw.setHeight((int)((50d * scale)));
//BA.debugLineNum = 50;BA.debugLine="btnTabel.Width=120dip  : btnTabel.Height=50dip :  btnTabel.Left=1%X : btnTabel.Top=pnlRadioButton.Bottom+5dip"[lay1/General script]
views.get("btntabel").vw.setLeft((int)((1d / 100 * width)));
//BA.debugLineNum = 50;BA.debugLine="btnTabel.Width=120dip  : btnTabel.Height=50dip :  btnTabel.Left=1%X : btnTabel.Top=pnlRadioButton.Bottom+5dip"[lay1/General script]
views.get("btntabel").vw.setTop((int)((views.get("pnlradiobutton").vw.getTop() + views.get("pnlradiobutton").vw.getHeight())+(5d * scale)));

}
}