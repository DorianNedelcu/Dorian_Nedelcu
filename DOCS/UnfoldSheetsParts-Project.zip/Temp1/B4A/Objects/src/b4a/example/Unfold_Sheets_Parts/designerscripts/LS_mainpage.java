package b4a.example.Unfold_Sheets_Parts.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_mainpage{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
views.get("panel_buttonbar").vw.setWidth((int)((100d / 100 * width)));
views.get("panel_buttonbar").vw.setHeight((int)((13d / 100 * height)));
views.get("btn_exit").vw.setWidth((int)((60d * scale)));
views.get("btn_exit").vw.setHeight((int)((55d * scale)));
views.get("btn_exit").vw.setLeft((int)((5d * scale)));
views.get("btn_exit").vw.setTop((int)((0d / 100 * width)));
views.get("lblresolution").vw.setWidth((int)((250d * scale)));
views.get("lblresolution").vw.setHeight((int)((views.get("btn_exit").vw.getHeight())+(5d * scale)));
views.get("lblresolution").vw.setLeft((int)((100d / 100 * width) - (views.get("lblresolution").vw.getWidth())));
views.get("lblresolution").vw.setTop((int)((0d / 100 * width)));
views.get("lbl_infostart").vw.setWidth((int)((90d / 100 * width)));
views.get("lbl_infostart").vw.setHeight((int)((15d / 100 * height)));
views.get("lbl_infostart").vw.setTop((int)((views.get("panel_buttonbar").vw.getTop() + views.get("panel_buttonbar").vw.getHeight())+(10d * scale)));
views.get("lbl_infostart").vw.setLeft((int)((5d / 100 * width)));
views.get("main_imgview1").vw.setWidth((int)((45d / 100 * width)));
views.get("main_imgview1").vw.setHeight((int)((25d / 100 * height)));
views.get("main_imgview1").vw.setLeft((int)(((100d / 100 * width)-2d*(views.get("main_imgview1").vw.getWidth()))/2d));
views.get("main_imgview1").vw.setTop((int)((views.get("lbl_infostart").vw.getTop() + views.get("lbl_infostart").vw.getHeight())+(5d * scale)));
views.get("main_imgview2").vw.setWidth((int)((45d / 100 * width)));
views.get("main_imgview2").vw.setHeight((int)((25d / 100 * height)));
views.get("main_imgview2").vw.setLeft((int)((views.get("main_imgview1").vw.getLeft() + views.get("main_imgview1").vw.getWidth())+(5d * scale)));
views.get("main_imgview2").vw.setTop((int)((views.get("main_imgview1").vw.getTop())));
views.get("main_imgview3").vw.setWidth((int)((45d / 100 * width)));
views.get("main_imgview3").vw.setHeight((int)((22d / 100 * height)));
views.get("main_imgview3").vw.setLeft((int)((views.get("main_imgview1").vw.getLeft())));
views.get("main_imgview3").vw.setTop((int)((views.get("main_imgview1").vw.getTop() + views.get("main_imgview1").vw.getHeight())+(5d * scale)));
views.get("main_imgview4").vw.setWidth((int)((45d / 100 * width)));
views.get("main_imgview4").vw.setHeight((int)((22d / 100 * height)));
views.get("main_imgview4").vw.setLeft((int)((views.get("main_imgview2").vw.getLeft())));
views.get("main_imgview4").vw.setTop((int)((views.get("main_imgview2").vw.getTop() + views.get("main_imgview2").vw.getHeight())+(5d * scale)));
views.get("lblabout").vw.setWidth((int)((25d / 100 * width)));
views.get("lblabout").vw.setHeight((int)((40d * scale)));
views.get("lblabout").vw.setLeft((int)(((100d / 100 * width)-(views.get("lblabout").vw.getWidth()))/2d));
views.get("lblabout").vw.setTop((int)((views.get("main_imgview4").vw.getTop() + views.get("main_imgview4").vw.getHeight())+(5d * scale)));

}
}