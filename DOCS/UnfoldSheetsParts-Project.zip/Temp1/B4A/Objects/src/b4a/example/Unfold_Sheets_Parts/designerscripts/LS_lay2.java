package b4a.example.Unfold_Sheets_Parts.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_lay2{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
String _wlbl="";
String _wtxt="";
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("imageview2").vw.setWidth((int)((80d / 100 * width)));
views.get("imageview2").vw.setHeight((int)((40d / 100 * height)));
views.get("imageview2").vw.setLeft((int)(((100d / 100 * width)-(views.get("imageview2").vw.getWidth()))/2d));
views.get("imageview2").vw.setTop((int)((0d / 100 * height)));
views.get("btncalculate2").vw.setWidth((int)((75d / 100 * width)));
views.get("btncalculate2").vw.setHeight((int)((8d / 100 * height)));
views.get("btncalculate2").vw.setLeft((int)(((100d / 100 * width)-(views.get("btncalculate2").vw.getWidth()))/2d));
views.get("btncalculate2").vw.setTop((int)((views.get("imageview2").vw.getTop() + views.get("imageview2").vw.getHeight())+(5d * scale)));
_wlbl = BA.NumberToString((30d / 100 * width));
_wtxt = BA.NumberToString((30d / 100 * width));
views.get("lblinputdata").vw.setWidth((int)((100d / 100 * width)));
views.get("pnlinputdata2").vw.setWidth((int)((70d / 100 * width)));
views.get("pnlinputdata2").vw.setHeight((int)((300d * scale)));
views.get("pnlinputdata2").vw.setLeft((int)(((100d / 100 * width)-(views.get("pnlinputdata2").vw.getWidth()))/2d));
views.get("pnlinputdata2").vw.setTop((int)((25d / 100 * height)));
views.get("lblxy2a").vw.setHeight((int)((30d * scale)));
views.get("lblxy2a").vw.setWidth((int)((100d * scale)));
views.get("lblxy2a").vw.setTop((int)((15d * scale)));
views.get("lblxy2a").vw.setLeft((int)((100d / 100 * width)-(5d * scale) - (views.get("lblxy2a").vw.getWidth())));
views.get("lblxy2b").vw.setHeight((int)((30d * scale)));
views.get("lblxy2b").vw.setWidth((int)((100d * scale)));
views.get("lblxy2b").vw.setTop((int)((15d * scale)));
views.get("lblxy2b").vw.setLeft((int)((100d / 100 * width)-(5d * scale) - (views.get("lblxy2b").vw.getWidth())));
views.get("lbldiameter").vw.setWidth((int)(Double.parseDouble(_wlbl)));
views.get("lbldiameter").vw.setHeight((int)((40d * scale)));
views.get("lbldiameter").vw.setLeft((int)((3d / 100 * width)));
views.get("lbldiameter").vw.setTop((int)((views.get("lblinputdata").vw.getTop() + views.get("lblinputdata").vw.getHeight())));
views.get("lblheight").vw.setWidth((int)(Double.parseDouble(_wlbl)));
views.get("lblheight").vw.setHeight((int)((40d * scale)));
views.get("lblheight").vw.setLeft((int)((3d / 100 * width)));
views.get("lblheight").vw.setTop((int)((views.get("lbldiameter").vw.getTop() + views.get("lbldiameter").vw.getHeight())));
views.get("lblgama").vw.setWidth((int)(Double.parseDouble(_wlbl)));
views.get("lblgama").vw.setHeight((int)((40d * scale)));
views.get("lblgama").vw.setLeft((int)((3d / 100 * width)));
views.get("lblgama").vw.setTop((int)((views.get("lblheight").vw.getTop() + views.get("lblheight").vw.getHeight())));
views.get("lbll1").vw.setWidth((int)(Double.parseDouble(_wlbl)));
views.get("lbll1").vw.setHeight((int)((40d * scale)));
views.get("lbll1").vw.setLeft((int)((3d / 100 * width)));
views.get("lbll1").vw.setTop((int)((views.get("lblgama").vw.getTop() + views.get("lblgama").vw.getHeight())));
views.get("lbl_l").vw.setWidth((int)(Double.parseDouble(_wlbl)));
views.get("lbl_l").vw.setHeight((int)((40d * scale)));
views.get("lbl_l").vw.setLeft((int)((3d / 100 * width)));
views.get("lbl_l").vw.setTop((int)((views.get("lbll1").vw.getTop() + views.get("lbll1").vw.getHeight())));
views.get("txtdiameter").vw.setWidth((int)(Double.parseDouble(_wtxt)));
views.get("txtdiameter").vw.setHeight((int)((40d * scale)));
views.get("txtdiameter").vw.setLeft((int)((views.get("lbldiameter").vw.getLeft() + views.get("lbldiameter").vw.getWidth())));
views.get("txtdiameter").vw.setTop((int)((views.get("lblinputdata").vw.getTop() + views.get("lblinputdata").vw.getHeight())));
views.get("txtheight").vw.setWidth((int)(Double.parseDouble(_wtxt)));
views.get("txtheight").vw.setHeight((int)((40d * scale)));
views.get("txtheight").vw.setLeft((int)((views.get("lblheight").vw.getLeft() + views.get("lblheight").vw.getWidth())));
views.get("txtheight").vw.setTop((int)((views.get("txtdiameter").vw.getTop() + views.get("txtdiameter").vw.getHeight())));
views.get("txtgama").vw.setWidth((int)(Double.parseDouble(_wtxt)));
views.get("txtgama").vw.setHeight((int)((40d * scale)));
views.get("txtgama").vw.setLeft((int)((views.get("lblgama").vw.getLeft() + views.get("lblgama").vw.getWidth())));
views.get("txtgama").vw.setTop((int)((views.get("txtheight").vw.getTop() + views.get("txtheight").vw.getHeight())));
views.get("txtl1").vw.setWidth((int)(Double.parseDouble(_wtxt)));
views.get("txtl1").vw.setHeight((int)((40d * scale)));
views.get("txtl1").vw.setLeft((int)((views.get("lbll1").vw.getLeft() + views.get("lbll1").vw.getWidth())));
views.get("txtl1").vw.setTop((int)((views.get("txtgama").vw.getTop() + views.get("txtgama").vw.getHeight())));
views.get("txt_l").vw.setWidth((int)(Double.parseDouble(_wtxt)));
views.get("txt_l").vw.setHeight((int)((40d * scale)));
views.get("txt_l").vw.setLeft((int)((views.get("lbl_l").vw.getLeft() + views.get("lbl_l").vw.getWidth())));
views.get("txt_l").vw.setTop((int)((views.get("txtl1").vw.getTop() + views.get("txtl1").vw.getHeight())));
views.get("btncalculateid").vw.setWidth((int)((30d / 100 * width)));
views.get("btncalculateid").vw.setHeight((int)((40d * scale)));
views.get("btncalculateid").vw.setLeft((int)((2d / 100 * width)));
views.get("btncalculateid").vw.setTop((int)((views.get("lbl_l").vw.getTop() + views.get("lbl_l").vw.getHeight())));
views.get("btncancelid").vw.setWidth((int)((30d / 100 * width)));
views.get("btncancelid").vw.setHeight((int)((40d * scale)));
views.get("btncancelid").vw.setTop((int)((views.get("btncalculateid").vw.getTop())));
views.get("btncancelid").vw.setLeft((int)((views.get("btncalculateid").vw.getLeft() + views.get("btncalculateid").vw.getWidth())+(5d * scale)));
views.get("imgfolded2").vw.setWidth((int)((100d / 100 * width)));
views.get("imgfolded2").vw.setHeight((int)((52d / 100 * height)));
views.get("imgfolded2").vw.setLeft((int)((0d / 100 * width)));
views.get("imgfolded2").vw.setTop((int)((views.get("btncalculate2").vw.getTop() + views.get("btncalculate2").vw.getHeight())));
views.get("imgfolded2").vw.setVisible(BA.parseBoolean("true"));
views.get("panel2a").vw.setWidth((int)((100d / 100 * width)));
views.get("panel2a").vw.setHeight((int)((25d / 100 * height)));
views.get("panel2a").vw.setLeft((int)((0d / 100 * width)));
views.get("panel2a").vw.setTop((int)((views.get("btncalculate2").vw.getTop() + views.get("btncalculate2").vw.getHeight())+(5d * scale)));
views.get("panel2b").vw.setWidth((int)((100d / 100 * width)));
views.get("panel2b").vw.setHeight((int)((25d / 100 * height)));
views.get("panel2b").vw.setLeft((int)((0d / 100 * width)));
views.get("panel2b").vw.setTop((int)((views.get("panel2a").vw.getTop() + views.get("panel2a").vw.getHeight())+(5d * scale)));
views.get("panel2a").vw.setVisible(BA.parseBoolean("false"));
views.get("panel2b").vw.setVisible(BA.parseBoolean("false"));
views.get("pnldemo").vw.setWidth((int)((95d / 100 * width)));
views.get("pnldemo").vw.setHeight((int)((60d / 100 * height)));
views.get("pnldemo").vw.setLeft((int)(((100d / 100 * width)-(views.get("pnldemo").vw.getWidth()))/2d));
views.get("pnldemo").vw.setTop((int)(((100d / 100 * height)-(views.get("pnldemo").vw.getHeight()))/2d));
views.get("imgdemo").vw.setWidth((int)((91d / 100 * width)));
views.get("imgdemo").vw.setHeight((int)((50d / 100 * height)));
views.get("imgdemo").vw.setLeft((int)((2d / 100 * width)));
views.get("imgdemo").vw.setTop((int)((2d / 100 * height)));
views.get("btnexitdemo").vw.setWidth((int)((110d * scale)));
views.get("btnexitdemo").vw.setHeight((int)((45d * scale)));
views.get("btnexitdemo").vw.setLeft((int)(((views.get("pnldemo").vw.getWidth())-(views.get("btnexitdemo").vw.getWidth()))/2d));
views.get("btnexitdemo").vw.setTop((int)((views.get("imgdemo").vw.getTop() + views.get("imgdemo").vw.getHeight())+(10d * scale)));
views.get("btnloaddemo").vw.setWidth((int)((50d * scale)));
views.get("btnloaddemo").vw.setHeight((int)((50d * scale)));
views.get("btnloaddemo").vw.setLeft((int)((views.get("imageview2").vw.getLeft())+(5d * scale)));
views.get("btnloaddemo").vw.setTop((int)((1d / 100 * height)));
views.get("pnltabel").vw.setWidth((int)((95d / 100 * width)));
views.get("pnltabel").vw.setHeight((int)((80d / 100 * height)));
views.get("pnltabel").vw.setLeft((int)((2.5d / 100 * width)));
views.get("pnltabel").vw.setTop((int)((10d / 100 * height)));
views.get("clvtabel").vw.setWidth((int)((85d / 100 * width)));
views.get("clvtabel").vw.setHeight((int)((70d / 100 * height)));
views.get("clvtabel").vw.setLeft((int)((2.5d / 100 * width)));
views.get("clvtabel").vw.setTop((int)((3d / 100 * width)));
views.get("btnexittabel").vw.setWidth((int)((40d / 100 * width)));
views.get("btnexittabel").vw.setHeight((int)((40d * scale)));
//BA.debugLineNum = 45;BA.debugLine="btnExitTabel.Width=40%X  : btnExitTabel.Height=40dip  :  btnExitTabel.Left=30%X : btnExitTabel.Top=clvTabel.Bottom+5dip"[lay2/General script]
views.get("btnexittabel").vw.setLeft((int)((30d / 100 * width)));
//BA.debugLineNum = 45;BA.debugLine="btnExitTabel.Width=40%X  : btnExitTabel.Height=40dip  :  btnExitTabel.Left=30%X : btnExitTabel.Top=clvTabel.Bottom+5dip"[lay2/General script]
views.get("btnexittabel").vw.setTop((int)((views.get("clvtabel").vw.getTop() + views.get("clvtabel").vw.getHeight())+(5d * scale)));
//BA.debugLineNum = 47;BA.debugLine="btnTabel.Width=120dip  : btnTabel.Height=50dip :  btnTabel.Left=1%X : btnTabel.Top=btnLoadDemo.Bottom+5dip"[lay2/General script]
views.get("btntabel").vw.setWidth((int)((120d * scale)));
//BA.debugLineNum = 47;BA.debugLine="btnTabel.Width=120dip  : btnTabel.Height=50dip :  btnTabel.Left=1%X : btnTabel.Top=btnLoadDemo.Bottom+5dip"[lay2/General script]
views.get("btntabel").vw.setHeight((int)((50d * scale)));
//BA.debugLineNum = 47;BA.debugLine="btnTabel.Width=120dip  : btnTabel.Height=50dip :  btnTabel.Left=1%X : btnTabel.Top=btnLoadDemo.Bottom+5dip"[lay2/General script]
views.get("btntabel").vw.setLeft((int)((1d / 100 * width)));
//BA.debugLineNum = 47;BA.debugLine="btnTabel.Width=120dip  : btnTabel.Height=50dip :  btnTabel.Left=1%X : btnTabel.Top=btnLoadDemo.Bottom+5dip"[lay2/General script]
views.get("btntabel").vw.setTop((int)((views.get("btnloaddemo").vw.getTop() + views.get("btnloaddemo").vw.getHeight())+(5d * scale)));

}
}