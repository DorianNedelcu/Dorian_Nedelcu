package b4a.example.Unfold_Sheets_Parts;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pag1 extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.Unfold_Sheets_Parts.pag1");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.Unfold_Sheets_Parts.pag1.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnldrawing = null;
public anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvsdrawing = null;
public anywheresoftware.b4a.objects.collections.List _listxy = null;
public anywheresoftware.b4a.objects.collections.List _listxy1 = null;
public anywheresoftware.b4a.objects.collections.List _lstxy = null;
public anywheresoftware.b4a.objects.collections.List _lstxy1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblxy = null;
public float _xgmin = 0f;
public float _xgmax = 0f;
public float _ygmin = 0f;
public float _ygmax = 0f;
public float _pi = 0f;
public b4a.example.Unfold_Sheets_Parts.grafic _chrt = null;
public b4a.example.Unfold_Sheets_Parts.b4xdialog _inputdialog = null;
public float[] _xp = null;
public float[] _yp = null;
public float[] _yp1 = null;
public float[] _yp2 = null;
public float[] _yp1h = null;
public float[] _yp2h = null;
public float _diametru = 0f;
public float _inaltime = 0f;
public float _alfa = 0f;
public float _beta = 0f;
public int _nrpct = 0;
public anywheresoftware.b4a.objects.PanelWrapper _pnlinputdata = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtdiameter = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtheight = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtalfa = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtbeta = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btncalculate = null;
public b4a.example.Unfold_Sheets_Parts.b4ximageview _imgfolded = null;
public b4a.example.Unfold_Sheets_Parts.b4ximageview _imageview = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlradiobutton = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _radiobutton1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _radiobutton2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnldemo = null;
public b4a.example.Unfold_Sheets_Parts.b4ximageview _imgdemo = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnexitdemo = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnloaddemo = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnltabel = null;
public b4a.example3.customlistview _clvtabel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _item1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _item2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _item3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btntabel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnexittabel = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.Unfold_Sheets_Parts.main _main = null;
public b4a.example.Unfold_Sheets_Parts.starter _starter = null;
public b4a.example.Unfold_Sheets_Parts.b4xpages _b4xpages = null;
public b4a.example.Unfold_Sheets_Parts.b4xcollections _b4xcollections = null;
public b4a.example.Unfold_Sheets_Parts.xuiviewsutils _xuiviewsutils = null;
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 60;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 61;BA.debugLine="B4XPages.SetTitle(Me, \"Cylinder intersected by 2";
_b4xpages._settitle /*String*/ (ba,this,(Object)("Cylinder intersected by 2 planes"));
 //BA.debugLineNum = 62;BA.debugLine="Root.LoadLayout(\"lay1\")";
_root.LoadLayout("lay1",ba);
 //BA.debugLineNum = 64;BA.debugLine="InputDialog.Initialize(Root)";
_inputdialog._initialize /*String*/ (ba,_root);
 //BA.debugLineNum = 65;BA.debugLine="B4XPages.MainPage.Pagina1.pnlInputData.Visible =F";
_b4xpages._mainpage /*b4a.example.Unfold_Sheets_Parts.b4xmainpage*/ (ba)._pagina1 /*b4a.example.Unfold_Sheets_Parts.pag1*/ ._pnlinputdata /*anywheresoftware.b4a.objects.PanelWrapper*/ .setVisible(__c.False);
 //BA.debugLineNum = 66;BA.debugLine="pnlDemo.Visible=False";
_pnldemo.setVisible(__c.False);
 //BA.debugLineNum = 67;BA.debugLine="pnlTabel.Visible=False";
_pnltabel.setVisible(__c.False);
 //BA.debugLineNum = 68;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 70;BA.debugLine="LoadImage";
_loadimage();
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
return "";
}
public String  _btncalculate_click() throws Exception{
 //BA.debugLineNum = 137;BA.debugLine="Private Sub btnCalculate_Click";
 //BA.debugLineNum = 139;BA.debugLine="pnlInputData.Visible = True";
_pnlinputdata.setVisible(__c.True);
 //BA.debugLineNum = 140;BA.debugLine="btnCalculate.Visible=False";
_btncalculate.setVisible(__c.False);
 //BA.debugLineNum = 141;BA.debugLine="pnlDrawing.Visible=True";
_pnldrawing.setVisible(__c.True);
 //BA.debugLineNum = 164;BA.debugLine="End Sub";
return "";
}
public String  _btncalculateid_click() throws Exception{
 //BA.debugLineNum = 111;BA.debugLine="Private Sub btnCalculateID_Click";
 //BA.debugLineNum = 112;BA.debugLine="pnlInputData.Visible = False";
_pnlinputdata.setVisible(__c.False);
 //BA.debugLineNum = 113;BA.debugLine="btnCalculate.Visible=True";
_btncalculate.setVisible(__c.True);
 //BA.debugLineNum = 114;BA.debugLine="pnlDrawing.Visible=True";
_pnldrawing.setVisible(__c.True);
 //BA.debugLineNum = 115;BA.debugLine="ImgFolded.mBase.Visible = False";
_imgfolded._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.False);
 //BA.debugLineNum = 117;BA.debugLine="Diametru = txtDiameter.Text";
_diametru = (float)(Double.parseDouble(_txtdiameter.getText()));
 //BA.debugLineNum = 118;BA.debugLine="Inaltime =  txtHeight.Text";
_inaltime = (float)(Double.parseDouble(_txtheight.getText()));
 //BA.debugLineNum = 119;BA.debugLine="Alfa = txtAlfa.Text";
_alfa = (float)(Double.parseDouble(_txtalfa.getText()));
 //BA.debugLineNum = 120;BA.debugLine="Beta = txtBeta.Text";
_beta = (float)(Double.parseDouble(_txtbeta.getText()));
 //BA.debugLineNum = 128;BA.debugLine="Diametru = txtDiameter.Text";
_diametru = (float)(Double.parseDouble(_txtdiameter.getText()));
 //BA.debugLineNum = 129;BA.debugLine="Inaltime =  txtHeight.Text";
_inaltime = (float)(Double.parseDouble(_txtheight.getText()));
 //BA.debugLineNum = 130;BA.debugLine="Alfa = txtAlfa.Text";
_alfa = (float)(Double.parseDouble(_txtalfa.getText()));
 //BA.debugLineNum = 131;BA.debugLine="Beta = txtBeta.Text";
_beta = (float)(Double.parseDouble(_txtbeta.getText()));
 //BA.debugLineNum = 134;BA.debugLine="Calcul_Desfasurata";
_calcul_desfasurata();
 //BA.debugLineNum = 135;BA.debugLine="End Sub";
return "";
}
public String  _btncancelid_click() throws Exception{
 //BA.debugLineNum = 100;BA.debugLine="Private Sub btnCancelID_Click";
 //BA.debugLineNum = 101;BA.debugLine="pnlInputData.Visible = False";
_pnlinputdata.setVisible(__c.False);
 //BA.debugLineNum = 102;BA.debugLine="pnlDrawing.Visible=False";
_pnldrawing.setVisible(__c.False);
 //BA.debugLineNum = 103;BA.debugLine="btnCalculate.Visible=True";
_btncalculate.setVisible(__c.True);
 //BA.debugLineNum = 104;BA.debugLine="ImgFolded.mBase.Visible = True";
_imgfolded._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.True);
 //BA.debugLineNum = 105;BA.debugLine="pnlTabel.Visible=False";
_pnltabel.setVisible(__c.False);
 //BA.debugLineNum = 106;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 107;BA.debugLine="btnExitTabel.Visible=False";
_btnexittabel.setVisible(__c.False);
 //BA.debugLineNum = 108;BA.debugLine="LoadImage";
_loadimage();
 //BA.debugLineNum = 109;BA.debugLine="End Sub";
return "";
}
public String  _btnexitdemo_click() throws Exception{
 //BA.debugLineNum = 338;BA.debugLine="Private Sub btnExitDemo_Click";
 //BA.debugLineNum = 339;BA.debugLine="pnlDemo.Visible=False";
_pnldemo.setVisible(__c.False);
 //BA.debugLineNum = 340;BA.debugLine="End Sub";
return "";
}
public String  _btnexittabel_click() throws Exception{
 //BA.debugLineNum = 390;BA.debugLine="Private Sub btnExitTabel_Click";
 //BA.debugLineNum = 391;BA.debugLine="pnlTabel.Visible=False";
_pnltabel.setVisible(__c.False);
 //BA.debugLineNum = 392;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 393;BA.debugLine="btnCalculate.Visible=True";
_btncalculate.setVisible(__c.True);
 //BA.debugLineNum = 394;BA.debugLine="pnlDrawing.Visible = True";
_pnldrawing.setVisible(__c.True);
 //BA.debugLineNum = 395;BA.debugLine="End Sub";
return "";
}
public String  _btnloaddemo_click() throws Exception{
 //BA.debugLineNum = 342;BA.debugLine="Private Sub btnLoadDemo_Click";
 //BA.debugLineNum = 343;BA.debugLine="pnlDemo.Visible=True";
_pnldemo.setVisible(__c.True);
 //BA.debugLineNum = 344;BA.debugLine="End Sub";
return "";
}
public String  _btntabel_click() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
float _pas = 0f;
int _i = 0;
 //BA.debugLineNum = 346;BA.debugLine="Private Sub btnTabel_Click";
 //BA.debugLineNum = 348;BA.debugLine="Dim xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 349;BA.debugLine="clvTabel.Clear";
_clvtabel._clear();
 //BA.debugLineNum = 351;BA.debugLine="Dim p As B4XView  = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 352;BA.debugLine="p.SetLayoutAnimated(0,0,0,100%X, 60dip)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),__c.PerXToCurrent((float) (100),ba),__c.DipToCurrent((int) (60)));
 //BA.debugLineNum = 353;BA.debugLine="p.LoadLayout(\"item\")";
_p.LoadLayout("item",ba);
 //BA.debugLineNum = 355;BA.debugLine="If RadioButton1.Checked=True Then";
if (_radiobutton1.getChecked()==__c.True) { 
 //BA.debugLineNum = 356;BA.debugLine="item1.Text = \"ID/Angle\"";
_item1.setText(BA.ObjectToCharSequence("ID/Angle"));
 //BA.debugLineNum = 357;BA.debugLine="item2.Text=\"X [mm]\"";
_item2.setText(BA.ObjectToCharSequence("X [mm]"));
 //BA.debugLineNum = 358;BA.debugLine="item3.Text=\"Y [mm]\"";
_item3.setText(BA.ObjectToCharSequence("Y [mm]"));
 }else {
 //BA.debugLineNum = 360;BA.debugLine="item1.Text = \"X [mm]\"";
_item1.setText(BA.ObjectToCharSequence("X [mm]"));
 //BA.debugLineNum = 361;BA.debugLine="item2.Text=\"Y1 [mm]\"";
_item2.setText(BA.ObjectToCharSequence("Y1 [mm]"));
 //BA.debugLineNum = 362;BA.debugLine="item3.Text=\"Y2 [mm]\"";
_item3.setText(BA.ObjectToCharSequence("Y2 [mm]"));
 };
 //BA.debugLineNum = 364;BA.debugLine="clvTabel.Add(p,\"\")";
_clvtabel._add(_p,(Object)(""));
 //BA.debugLineNum = 365;BA.debugLine="Dim pas=360/(4 * NrPct) As Float";
_pas = (float) (360/(double)(4*_nrpct));
 //BA.debugLineNum = 366;BA.debugLine="For i = 1 To 4 * NrPct + 1";
{
final int step17 = 1;
final int limit17 = (int) (4*_nrpct+1);
_i = (int) (1) ;
for (;_i <= limit17 ;_i = _i + step17 ) {
 //BA.debugLineNum = 367;BA.debugLine="Dim p As B4XView  = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 368;BA.debugLine="p.SetLayoutAnimated(100,0,0,100%X, 60dip)";
_p.SetLayoutAnimated((int) (100),(int) (0),(int) (0),__c.PerXToCurrent((float) (100),ba),__c.DipToCurrent((int) (60)));
 //BA.debugLineNum = 369;BA.debugLine="p.LoadLayout(\"item\")";
_p.LoadLayout("item",ba);
 //BA.debugLineNum = 371;BA.debugLine="If RadioButton1.Checked=True Then";
if (_radiobutton1.getChecked()==__c.True) { 
 //BA.debugLineNum = 372;BA.debugLine="item1.Text = i & \" / \" & ((i-1) * pas)";
_item1.setText(BA.ObjectToCharSequence(BA.NumberToString(_i)+" / "+BA.NumberToString(((_i-1)*_pas))));
 //BA.debugLineNum = 373;BA.debugLine="item2.Text=Round2(XP(i), 2)";
_item2.setText(BA.ObjectToCharSequence(__c.Round2(_xp[_i],(int) (2))));
 //BA.debugLineNum = 374;BA.debugLine="item3.Text=Round2(YP(i), 2)";
_item3.setText(BA.ObjectToCharSequence(__c.Round2(_yp[_i],(int) (2))));
 }else {
 //BA.debugLineNum = 376;BA.debugLine="item1.Text = Round2(XP(i), 2)";
_item1.setText(BA.ObjectToCharSequence(__c.Round2(_xp[_i],(int) (2))));
 //BA.debugLineNum = 377;BA.debugLine="item2.Text= Round2(YP2H(i), 2)";
_item2.setText(BA.ObjectToCharSequence(__c.Round2(_yp2h[_i],(int) (2))));
 //BA.debugLineNum = 378;BA.debugLine="item3.Text=Round2(YP1H(i), 2)";
_item3.setText(BA.ObjectToCharSequence(__c.Round2(_yp1h[_i],(int) (2))));
 };
 //BA.debugLineNum = 380;BA.debugLine="clvTabel.Add(p,\"\")";
_clvtabel._add(_p,(Object)(""));
 }
};
 //BA.debugLineNum = 382;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 383;BA.debugLine="btnCalculate.Visible=False";
_btncalculate.setVisible(__c.False);
 //BA.debugLineNum = 384;BA.debugLine="pnlTabel.Visible=True";
_pnltabel.setVisible(__c.True);
 //BA.debugLineNum = 385;BA.debugLine="btnExitTabel.Visible=True";
_btnexittabel.setVisible(__c.True);
 //BA.debugLineNum = 386;BA.debugLine="pnlDrawing.Visible = False";
_pnldrawing.setVisible(__c.False);
 //BA.debugLineNum = 388;BA.debugLine="End Sub";
return "";
}
public void  _calcul_desfasurata() throws Exception{
ResumableSub_Calcul_Desfasurata rsub = new ResumableSub_Calcul_Desfasurata(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Calcul_Desfasurata extends BA.ResumableSub {
public ResumableSub_Calcul_Desfasurata(b4a.example.Unfold_Sheets_Parts.pag1 parent) {
this.parent = parent;
}
b4a.example.Unfold_Sheets_Parts.pag1 parent;
float _h1 = 0f;
float _h2 = 0f;
float _lungime = 0f;
float _teta = 0f;
float _aria = 0f;
String _mesaj = "";
String _mesaj_v = "";
float _umax = 0f;
String _sir = "";
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct1 = null;
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct2 = null;
float _lg = 0f;
int _i = 0;
float _halfa = 0f;
float _hbeta = 0f;
b4a.example.Unfold_Sheets_Parts.b4xlongtexttemplate _s = null;
int _result = 0;
int step38;
int limit38;
int step47;
int limit47;
int step64;
int limit64;
int step78;
int limit78;
int step84;
int limit84;
int step105;
int limit105;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 168;BA.debugLine="Private H1, H2, Lungime, Teta, Aria As Float";
_h1 = 0f;
_h2 = 0f;
_lungime = 0f;
_teta = 0f;
_aria = 0f;
 //BA.debugLineNum = 169;BA.debugLine="Private mesaj=\"\", mesaj_V As String";
_mesaj = "";
_mesaj_v = "";
 //BA.debugLineNum = 174;BA.debugLine="If RadioButton1.Checked=True Then";
if (true) break;

case 1:
//if
this.state = 14;
if (parent._radiobutton1.getChecked()==parent.__c.True) { 
this.state = 3;
}else {
this.state = 9;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 175;BA.debugLine="Dim Umax As Float";
_umax = 0f;
 //BA.debugLineNum = 176;BA.debugLine="Dim sir As String";
_sir = "";
 //BA.debugLineNum = 177;BA.debugLine="Umax= ATan(2 * Inaltime / Diametru) * 180 / PI";
_umax = (float) (parent.__c.ATan(2*parent._inaltime/(double)parent._diametru)*180/(double)parent._pi);
 //BA.debugLineNum = 178;BA.debugLine="If Alfa > Umax Or Beta > Umax Then";
if (true) break;

case 4:
//if
this.state = 7;
if (parent._alfa>_umax || parent._beta>_umax) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 179;BA.debugLine="sir = \"The angles 'Alpha' , 'Beta' must be smal";
_sir = "The angles 'Alpha' , 'Beta' must be smaller than "+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 180;BA.debugLine="sir = sir &  Umax & \" [degrees]\" & Chr(10) & \"T";
_sir = _sir+BA.NumberToString(_umax)+" [degrees]"+BA.ObjectToString(parent.__c.Chr((int) (10)))+"Try increasing the height of the cylinder !";
 //BA.debugLineNum = 181;BA.debugLine="xui.MsgboxAsync( sir, \"Error\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence(_sir),BA.ObjectToCharSequence("Error"));
 //BA.debugLineNum = 182;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 7:
//C
this.state = 14;
;
 if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 185;BA.debugLine="H1 = Inaltime - Diametru * (Tan(Alfa * PI / 180)";
_h1 = (float) (parent._inaltime-parent._diametru*(parent.__c.Tan(parent._alfa*parent._pi/(double)180)+parent.__c.Tan(parent._beta*parent._pi/(double)180)));
 //BA.debugLineNum = 186;BA.debugLine="If H1 < 0 Then";
if (true) break;

case 10:
//if
this.state = 13;
if (_h1<0) { 
this.state = 12;
}if (true) break;

case 12:
//C
this.state = 13;
 //BA.debugLineNum = 187;BA.debugLine="sir = \"The H1 = \" & Round2(H1,2) & \" height can";
_sir = "The H1 = "+BA.NumberToString(parent.__c.Round2(_h1,(int) (2)))+" height cannot be negative !"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 188;BA.debugLine="sir = sir & Chr(10) & \"Try increasing the heigh";
_sir = _sir+BA.ObjectToString(parent.__c.Chr((int) (10)))+"Try increasing the height of the cylinder !";
 //BA.debugLineNum = 189;BA.debugLine="xui.MsgboxAsync( sir, \"Error\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence(_sir),BA.ObjectToCharSequence("Error"));
 //BA.debugLineNum = 190;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 13:
//C
this.state = 14;
;
 if (true) break;

case 14:
//C
this.state = 15;
;
 //BA.debugLineNum = 194;BA.debugLine="Dim pct1, Pct2 As Point";
_pct1 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
_pct2 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
 //BA.debugLineNum = 195;BA.debugLine="Dim LG = 0.03 * PI * Diametru As Float";
_lg = (float) (0.03*parent._pi*parent._diametru);
 //BA.debugLineNum = 196;BA.debugLine="XGmin=-LG : XGmax = PI * Diametru+LG : YGmin=-LG";
parent._xgmin = (float) (-_lg);
 //BA.debugLineNum = 196;BA.debugLine="XGmin=-LG : XGmax = PI * Diametru+LG : YGmin=-LG";
parent._xgmax = (float) (parent._pi*parent._diametru+_lg);
 //BA.debugLineNum = 196;BA.debugLine="XGmin=-LG : XGmax = PI * Diametru+LG : YGmin=-LG";
parent._ygmin = (float) (-_lg);
 //BA.debugLineNum = 196;BA.debugLine="XGmin=-LG : XGmax = PI * Diametru+LG : YGmin=-LG";
parent._ygmax = (float) (parent._inaltime+_lg);
 //BA.debugLineNum = 197;BA.debugLine="chrt.Initialize( pnlDrawing, cvsDrawing, XGmin, Y";
parent._chrt._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(parent._pnldrawing.getObject())),parent._cvsdrawing,parent._xgmin,parent._ygmin,parent._xgmax,parent._ygmax);
 //BA.debugLineNum = 200;BA.debugLine="ListXY.Initialize : ListXY1.Initialize";
parent._listxy.Initialize();
 //BA.debugLineNum = 200;BA.debugLine="ListXY.Initialize : ListXY1.Initialize";
parent._listxy1.Initialize();
 //BA.debugLineNum = 201;BA.debugLine="lblXY.Visible = True";
parent._lblxy.setVisible(parent.__c.True);
 //BA.debugLineNum = 202;BA.debugLine="lblXY.Text=\"Click graph area\"";
parent._lblxy.setText(BA.ObjectToCharSequence("Click graph area"));
 //BA.debugLineNum = 203;BA.debugLine="If RadioButton1.Checked=True Then";
if (true) break;

case 15:
//if
this.state = 48;
if (parent._radiobutton1.getChecked()==parent.__c.True) { 
this.state = 17;
}else {
this.state = 36;
}if (true) break;

case 17:
//C
this.state = 18;
 //BA.debugLineNum = 204;BA.debugLine="H1 = Inaltime - Diametru * Tan(Alfa * PI / 180)";
_h1 = (float) (parent._inaltime-parent._diametru*parent.__c.Tan(parent._alfa*parent._pi/(double)180)/(double)2);
 //BA.debugLineNum = 205;BA.debugLine="H2 = Inaltime - Diametru * Tan(Beta * PI / 180)";
_h2 = (float) (parent._inaltime-parent._diametru*parent.__c.Tan(parent._beta*parent._pi/(double)180)/(double)2);
 //BA.debugLineNum = 206;BA.debugLine="Lungime = PI * Diametru ' Lungime desfasurata";
_lungime = (float) (parent._pi*parent._diametru);
 //BA.debugLineNum = 207;BA.debugLine="Aria = Diametru * (Inaltime * PI - Diametru * (T";
_aria = (float) (parent._diametru*(parent._inaltime*parent._pi-parent._diametru*(parent.__c.Tan(parent._alfa*parent._pi/(double)180)+parent.__c.Tan(parent._beta*parent._pi/(double)180))/(double)2));
 //BA.debugLineNum = 208;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 18:
//for
this.state = 27;
step38 = 1;
limit38 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 49;
if (true) break;

case 49:
//C
this.state = 27;
if ((step38 > 0 && _i <= limit38) || (step38 < 0 && _i >= limit38)) this.state = 20;
if (true) break;

case 50:
//C
this.state = 49;
_i = ((int)(0 + _i + step38)) ;
if (true) break;

case 20:
//C
this.state = 21;
 //BA.debugLineNum = 209;BA.debugLine="Teta = (i - 1) * PI / 2 / NrPct";
_teta = (float) ((_i-1)*parent._pi/(double)2/(double)parent._nrpct);
 //BA.debugLineNum = 210;BA.debugLine="XP(i) = Teta * Diametru / 2";
parent._xp[_i] = (float) (_teta*parent._diametru/(double)2);
 //BA.debugLineNum = 211;BA.debugLine="If Teta < PI / 2 Or Teta > 3 * PI / 2 Then";
if (true) break;

case 21:
//if
this.state = 26;
if (_teta<parent._pi/(double)2 || _teta>3*parent._pi/(double)2) { 
this.state = 23;
}else {
this.state = 25;
}if (true) break;

case 23:
//C
this.state = 26;
 //BA.debugLineNum = 212;BA.debugLine="YP(i) = Inaltime - Diametru / 2 * Cos(Teta) *";
parent._yp[_i] = (float) (parent._inaltime-parent._diametru/(double)2*parent.__c.Cos(_teta)*parent.__c.Tan(parent._alfa*parent._pi/(double)180));
 if (true) break;

case 25:
//C
this.state = 26;
 //BA.debugLineNum = 214;BA.debugLine="YP(i) = Inaltime + Diametru / 2 * Cos(Teta) *";
parent._yp[_i] = (float) (parent._inaltime+parent._diametru/(double)2*parent.__c.Cos(_teta)*parent.__c.Tan(parent._beta*parent._pi/(double)180));
 if (true) break;

case 26:
//C
this.state = 50;
;
 if (true) break;
if (true) break;
;
 //BA.debugLineNum = 219;BA.debugLine="For i = 1 To 4 * NrPct + 1";

case 27:
//for
this.state = 30;
step47 = 1;
limit47 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 51;
if (true) break;

case 51:
//C
this.state = 30;
if ((step47 > 0 && _i <= limit47) || (step47 < 0 && _i >= limit47)) this.state = 29;
if (true) break;

case 52:
//C
this.state = 51;
_i = ((int)(0 + _i + step47)) ;
if (true) break;

case 29:
//C
this.state = 52;
 //BA.debugLineNum = 220;BA.debugLine="lstXY.Initialize : lstXY.Add(XP(i)) : lstXY.Add";
parent._lstxy.Initialize();
 //BA.debugLineNum = 220;BA.debugLine="lstXY.Initialize : lstXY.Add(XP(i)) : lstXY.Add";
parent._lstxy.Add((Object)(parent._xp[_i]));
 //BA.debugLineNum = 220;BA.debugLine="lstXY.Initialize : lstXY.Add(XP(i)) : lstXY.Add";
parent._lstxy.Add((Object)(parent._yp[_i]));
 //BA.debugLineNum = 221;BA.debugLine="ListXY.Add(lstXY)";
parent._listxy.Add((Object)(parent._lstxy.getObject()));
 if (true) break;
if (true) break;

case 30:
//C
this.state = 31;
;
 //BA.debugLineNum = 224;BA.debugLine="chrt.DrawCurve(ListXY, Colors.Blue, 3dip, False,";
parent._chrt._drawcurve /*String*/ (parent._listxy,(long) (parent.__c.Colors.Blue),parent.__c.DipToCurrent((int) (3)),parent.__c.False,parent.__c.True,(int) (0),(int) (0));
 //BA.debugLineNum = 225;BA.debugLine="cvsDrawing.DrawCircle(chrt.RealToPix(0, 0).X, ch";
parent._cvsdrawing.DrawCircle(parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).X /*float*/ ,parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).Y /*float*/ ,(float) (parent.__c.DipToCurrent((int) (5))),parent.__c.Colors.Red,parent.__c.True,(float) (0));
 //BA.debugLineNum = 227;BA.debugLine="pct1 = chrt.RealToPix(0, 0)  :  Pct2 = chrt.Real";
_pct1 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0));
 //BA.debugLineNum = 227;BA.debugLine="pct1 = chrt.RealToPix(0, 0)  :  Pct2 = chrt.Real";
_pct2 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),_h1);
 //BA.debugLineNum = 228;BA.debugLine="cvsDrawing.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 229;BA.debugLine="pct1 = chrt.RealToPix(0, 0)  :  Pct2 = chrt.Real";
_pct1 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0));
 //BA.debugLineNum = 229;BA.debugLine="pct1 = chrt.RealToPix(0, 0)  :  Pct2 = chrt.Real";
_pct2 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_lungime,(float) (0));
 //BA.debugLineNum = 230;BA.debugLine="cvsDrawing.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 231;BA.debugLine="pct1 = chrt.RealToPix(Lungime , 0)  :  Pct2 = ch";
_pct1 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_lungime,(float) (0));
 //BA.debugLineNum = 231;BA.debugLine="pct1 = chrt.RealToPix(Lungime , 0)  :  Pct2 = ch";
_pct2 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_lungime,_h1);
 //BA.debugLineNum = 232;BA.debugLine="cvsDrawing.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 234;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 31:
//for
this.state = 34;
step64 = 1;
limit64 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 53;
if (true) break;

case 53:
//C
this.state = 34;
if ((step64 > 0 && _i <= limit64) || (step64 < 0 && _i >= limit64)) this.state = 33;
if (true) break;

case 54:
//C
this.state = 53;
_i = ((int)(0 + _i + step64)) ;
if (true) break;

case 33:
//C
this.state = 54;
 //BA.debugLineNum = 235;BA.debugLine="pct1 = chrt.RealToPix(XP(i), 0)  :  Pct2 = chrt";
_pct1 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._xp[_i],(float) (0));
 //BA.debugLineNum = 235;BA.debugLine="pct1 = chrt.RealToPix(XP(i), 0)  :  Pct2 = chrt";
_pct2 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._xp[_i],parent._yp[_i]);
 //BA.debugLineNum = 236;BA.debugLine="cvsDrawing.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct";
parent._cvsdrawing.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Black,(float) (parent.__c.DipToCurrent((int) (1))));
 if (true) break;
if (true) break;

case 34:
//C
this.state = 48;
;
 //BA.debugLineNum = 238;BA.debugLine="mesaj_V = \"H1 height = \" & Round2(H1, 2) & \" [mm";
_mesaj_v = "H1 height = "+BA.NumberToString(parent.__c.Round2(_h1,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 239;BA.debugLine="mesaj_V = mesaj_V & \"H2 height = \" & Round2(H2,";
_mesaj_v = _mesaj_v+"H2 height = "+BA.NumberToString(parent.__c.Round2(_h2,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 240;BA.debugLine="mesaj_V = mesaj_V & \"Hmax maxim height = \" & Rou";
_mesaj_v = _mesaj_v+"Hmax maxim height = "+BA.NumberToString(parent.__c.Round2(parent._inaltime,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 if (true) break;

case 36:
//C
this.state = 37;
 //BA.debugLineNum = 242;BA.debugLine="Dim HAlfa As Float, HBeta As Float";
_halfa = 0f;
_hbeta = 0f;
 //BA.debugLineNum = 243;BA.debugLine="Lungime = PI * Diametru ' Lungime desfasurata";
_lungime = (float) (parent._pi*parent._diametru);
 //BA.debugLineNum = 244;BA.debugLine="HAlfa = Diametru * Tan(Alfa * PI / 180)";
_halfa = (float) (parent._diametru*parent.__c.Tan(parent._alfa*parent._pi/(double)180));
 //BA.debugLineNum = 245;BA.debugLine="HBeta = Diametru * Tan(Beta * PI / 180)";
_hbeta = (float) (parent._diametru*parent.__c.Tan(parent._beta*parent._pi/(double)180));
 //BA.debugLineNum = 246;BA.debugLine="Aria = PI * Diametru * (Inaltime - Diametru * (T";
_aria = (float) (parent._pi*parent._diametru*(parent._inaltime-parent._diametru*(parent.__c.Tan(parent._alfa*parent._pi/(double)180)+parent.__c.Tan(parent._beta*parent._pi/(double)180))/(double)2));
 //BA.debugLineNum = 247;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 37:
//for
this.state = 40;
step78 = 1;
limit78 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 55;
if (true) break;

case 55:
//C
this.state = 40;
if ((step78 > 0 && _i <= limit78) || (step78 < 0 && _i >= limit78)) this.state = 39;
if (true) break;

case 56:
//C
this.state = 55;
_i = ((int)(0 + _i + step78)) ;
if (true) break;

case 39:
//C
this.state = 56;
 //BA.debugLineNum = 248;BA.debugLine="Teta = (i - 1) * PI / 2 / NrPct";
_teta = (float) ((_i-1)*parent._pi/(double)2/(double)parent._nrpct);
 //BA.debugLineNum = 249;BA.debugLine="XP(i) = Teta * Diametru / 2";
parent._xp[_i] = (float) (_teta*parent._diametru/(double)2);
 //BA.debugLineNum = 250;BA.debugLine="YP1(i) = Diametru * (1 - Cos(Teta)) * Tan(Alfa";
parent._yp1[_i] = (float) (parent._diametru*(1-parent.__c.Cos(_teta))*parent.__c.Tan(parent._alfa*parent._pi/(double)180)/(double)2);
 //BA.debugLineNum = 251;BA.debugLine="YP2(i) = Diametru * (1 - Cos(Teta)) * Tan(Beta";
parent._yp2[_i] = (float) (parent._diametru*(1-parent.__c.Cos(_teta))*parent.__c.Tan(parent._beta*parent._pi/(double)180)/(double)2);
 if (true) break;
if (true) break;
;
 //BA.debugLineNum = 255;BA.debugLine="For i = 1 To 4 * NrPct + 1";

case 40:
//for
this.state = 43;
step84 = 1;
limit84 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 57;
if (true) break;

case 57:
//C
this.state = 43;
if ((step84 > 0 && _i <= limit84) || (step84 < 0 && _i >= limit84)) this.state = 42;
if (true) break;

case 58:
//C
this.state = 57;
_i = ((int)(0 + _i + step84)) ;
if (true) break;

case 42:
//C
this.state = 58;
 //BA.debugLineNum = 256;BA.debugLine="YP1H(i) = H1+HBeta+YP1(i)";
parent._yp1h[_i] = (float) (_h1+_hbeta+parent._yp1[_i]);
 //BA.debugLineNum = 257;BA.debugLine="YP2H(i) = HBeta-YP2(i)";
parent._yp2h[_i] = (float) (_hbeta-parent._yp2[_i]);
 //BA.debugLineNum = 259;BA.debugLine="lstXY.Initialize : lstXY.Add(XP(i)) : lstXY.Add";
parent._lstxy.Initialize();
 //BA.debugLineNum = 259;BA.debugLine="lstXY.Initialize : lstXY.Add(XP(i)) : lstXY.Add";
parent._lstxy.Add((Object)(parent._xp[_i]));
 //BA.debugLineNum = 259;BA.debugLine="lstXY.Initialize : lstXY.Add(XP(i)) : lstXY.Add";
parent._lstxy.Add((Object)(parent._yp1h[_i]));
 //BA.debugLineNum = 260;BA.debugLine="ListXY.Add(lstXY)";
parent._listxy.Add((Object)(parent._lstxy.getObject()));
 //BA.debugLineNum = 261;BA.debugLine="lstXY1.Initialize : lstXY1.Add(XP(i)) : lstXY1.";
parent._lstxy1.Initialize();
 //BA.debugLineNum = 261;BA.debugLine="lstXY1.Initialize : lstXY1.Add(XP(i)) : lstXY1.";
parent._lstxy1.Add((Object)(parent._xp[_i]));
 //BA.debugLineNum = 261;BA.debugLine="lstXY1.Initialize : lstXY1.Add(XP(i)) : lstXY1.";
parent._lstxy1.Add((Object)(_hbeta-parent._yp2[_i]));
 //BA.debugLineNum = 262;BA.debugLine="ListXY1.Add(lstXY1)";
parent._listxy1.Add((Object)(parent._lstxy1.getObject()));
 if (true) break;
if (true) break;

case 43:
//C
this.state = 44;
;
 //BA.debugLineNum = 264;BA.debugLine="chrt.DrawCurve(ListXY, Colors.Blue, 3dip, False,";
parent._chrt._drawcurve /*String*/ (parent._listxy,(long) (parent.__c.Colors.Blue),parent.__c.DipToCurrent((int) (3)),parent.__c.False,parent.__c.True,(int) (0),(int) (0));
 //BA.debugLineNum = 265;BA.debugLine="chrt.DrawCurve(ListXY1, Colors.Blue, 3dip, False";
parent._chrt._drawcurve /*String*/ (parent._listxy1,(long) (parent.__c.Colors.Blue),parent.__c.DipToCurrent((int) (3)),parent.__c.False,parent.__c.False,(int) (0),(int) (0));
 //BA.debugLineNum = 266;BA.debugLine="cvsDrawing.DrawCircle(chrt.RealToPix(0, 0).X, ch";
parent._cvsdrawing.DrawCircle(parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).X /*float*/ ,parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).Y /*float*/ ,(float) (parent.__c.DipToCurrent((int) (5))),parent.__c.Colors.Red,parent.__c.True,(float) (0));
 //BA.debugLineNum = 268;BA.debugLine="pct1 = chrt.RealToPix(0, HBeta)  :  Pct2 = chrt.";
_pct1 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),_hbeta);
 //BA.debugLineNum = 268;BA.debugLine="pct1 = chrt.RealToPix(0, HBeta)  :  Pct2 = chrt.";
_pct2 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (_h1+_hbeta));
 //BA.debugLineNum = 269;BA.debugLine="cvsDrawing.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 270;BA.debugLine="pct1 = chrt.RealToPix(Lungime, HBeta)  :  Pct2 =";
_pct1 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_lungime,_hbeta);
 //BA.debugLineNum = 270;BA.debugLine="pct1 = chrt.RealToPix(Lungime, HBeta)  :  Pct2 =";
_pct2 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_lungime,(float) (_h1+_hbeta));
 //BA.debugLineNum = 271;BA.debugLine="cvsDrawing.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 274;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 44:
//for
this.state = 47;
step105 = 1;
limit105 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 59;
if (true) break;

case 59:
//C
this.state = 47;
if ((step105 > 0 && _i <= limit105) || (step105 < 0 && _i >= limit105)) this.state = 46;
if (true) break;

case 60:
//C
this.state = 59;
_i = ((int)(0 + _i + step105)) ;
if (true) break;

case 46:
//C
this.state = 60;
 //BA.debugLineNum = 275;BA.debugLine="pct1 = chrt.RealToPix(XP(i), HBeta-YP2(i))  :";
_pct1 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._xp[_i],(float) (_hbeta-parent._yp2[_i]));
 //BA.debugLineNum = 275;BA.debugLine="pct1 = chrt.RealToPix(XP(i), HBeta-YP2(i))  :";
_pct2 = parent._chrt._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._xp[_i],(float) (_h1+_hbeta+parent._yp1[_i]));
 //BA.debugLineNum = 276;BA.debugLine="cvsDrawing.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct";
parent._cvsdrawing.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Black,(float) (parent.__c.DipToCurrent((int) (1))));
 if (true) break;
if (true) break;

case 47:
//C
this.state = 48;
;
 //BA.debugLineNum = 279;BA.debugLine="mesaj_V = \"H1 = \" & Round2(H1, 2) & \" [mm]\" & Ch";
_mesaj_v = "H1 = "+BA.NumberToString(parent.__c.Round2(_h1,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 280;BA.debugLine="mesaj_V = mesaj_V & \"HAlfa = \" & Round2(HAlfa, 2";
_mesaj_v = _mesaj_v+"HAlfa = "+BA.NumberToString(parent.__c.Round2(_halfa,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 281;BA.debugLine="mesaj_V = mesaj_V & \"HBeta = \" & Round2(HBeta, 2";
_mesaj_v = _mesaj_v+"HBeta = "+BA.NumberToString(parent.__c.Round2(_hbeta,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 if (true) break;

case 48:
//C
this.state = -1;
;
 //BA.debugLineNum = 284;BA.debugLine="mesaj=\"\"";
_mesaj = "";
 //BA.debugLineNum = 285;BA.debugLine="mesaj = mesaj & \"Cylinder diameter  = \" & Round2(";
_mesaj = _mesaj+"Cylinder diameter  = "+BA.NumberToString(parent.__c.Round2(parent._diametru,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 286;BA.debugLine="mesaj = mesaj & \"Cylinder height = \" & Round2(Ina";
_mesaj = _mesaj+"Cylinder height = "+BA.NumberToString(parent.__c.Round2(parent._inaltime,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 287;BA.debugLine="mesaj = mesaj & \"Alfa angle = \"& Round2(Alfa, 2)";
_mesaj = _mesaj+"Alfa angle = "+BA.NumberToString(parent.__c.Round2(parent._alfa,(int) (2)))+" [gr]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 288;BA.debugLine="mesaj = mesaj & \"Beta angle = \" & Round2(Beta, 2)";
_mesaj = _mesaj+"Beta angle = "+BA.NumberToString(parent.__c.Round2(parent._beta,(int) (2)))+" [gr]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 289;BA.debugLine="mesaj = mesaj & \"=======================\" & Chr(1";
_mesaj = _mesaj+"======================="+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 290;BA.debugLine="mesaj = mesaj & mesaj_V";
_mesaj = _mesaj+_mesaj_v;
 //BA.debugLineNum = 291;BA.debugLine="mesaj = mesaj & \"Length = \"& Round2(Lungime, 2) &";
_mesaj = _mesaj+"Length = "+BA.NumberToString(parent.__c.Round2(_lungime,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 292;BA.debugLine="mesaj = mesaj & \"Surface area = \" & Round2(Aria,";
_mesaj = _mesaj+"Surface area = "+BA.NumberToString(parent.__c.Round2(_aria,(int) (2)))+" [mm2]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 294;BA.debugLine="Dim s As B4XLongTextTemplate";
_s = new b4a.example.Unfold_Sheets_Parts.b4xlongtexttemplate();
 //BA.debugLineNum = 295;BA.debugLine="s.Initialize  :  s.Text = mesaj";
_s._initialize /*String*/ (ba);
 //BA.debugLineNum = 295;BA.debugLine="s.Initialize  :  s.Text = mesaj";
_s._text /*Object*/  = (Object)(_mesaj);
 //BA.debugLineNum = 296;BA.debugLine="s.CustomListView1.DefaultTextBackgroundColor=xui.";
_s._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextbackgroundcolor = parent._xui.Color_White;
 //BA.debugLineNum = 297;BA.debugLine="s.CustomListView1.DefaultTextColor = xui.Color_Bl";
_s._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextcolor = parent._xui.Color_Black;
 //BA.debugLineNum = 298;BA.debugLine="InputDialog.Title=\"Info results\"";
parent._inputdialog._title /*Object*/  = (Object)("Info results");
 //BA.debugLineNum = 299;BA.debugLine="InputDialog.TitleBarColor=Colors.Blue  :  InputDi";
parent._inputdialog._titlebarcolor /*int*/  = parent.__c.Colors.Blue;
 //BA.debugLineNum = 299;BA.debugLine="InputDialog.TitleBarColor=Colors.Blue  :  InputDi";
parent._inputdialog._buttonscolor /*int*/  = parent.__c.Colors.Blue;
 //BA.debugLineNum = 300;BA.debugLine="InputDialog.BorderWidth = 4  :  InputDialog.Borde";
parent._inputdialog._borderwidth /*int*/  = (int) (4);
 //BA.debugLineNum = 300;BA.debugLine="InputDialog.BorderWidth = 4  :  InputDialog.Borde";
parent._inputdialog._bordercornersradius /*int*/  = parent.__c.DipToCurrent((int) (10));
 //BA.debugLineNum = 301;BA.debugLine="InputDialog.BackgroundColor=Colors.White  :  Inpu";
parent._inputdialog._backgroundcolor /*int*/  = parent.__c.Colors.White;
 //BA.debugLineNum = 301;BA.debugLine="InputDialog.BackgroundColor=Colors.White  :  Inpu";
parent._inputdialog._buttonstextcolor /*int*/  = parent.__c.Colors.White;
 //BA.debugLineNum = 302;BA.debugLine="wait for (InputDialog.ShowTemplate(s,\"OK\",\"\",\"\"))";
parent.__c.WaitFor("complete", ba, this, parent._inputdialog._showtemplate /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((Object)(_s),(Object)("OK"),(Object)(""),(Object)("")));
this.state = 61;
return;
case 61:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 308;BA.debugLine="btnTabel.Visible=True";
parent._btntabel.setVisible(parent.__c.True);
 //BA.debugLineNum = 310;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Public Root As B4XView 'ignore";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 3;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 5;BA.debugLine="Private pnlDrawing As B4XView";
_pnldrawing = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 6;BA.debugLine="Dim cvsDrawing As Canvas";
_cvsdrawing = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 7;BA.debugLine="Dim ListXY, ListXY1 As List";
_listxy = new anywheresoftware.b4a.objects.collections.List();
_listxy1 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 8;BA.debugLine="Dim lstXY, lstXY1 As List";
_lstxy = new anywheresoftware.b4a.objects.collections.List();
_lstxy1 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 10;BA.debugLine="Private lblXY As B4XView";
_lblxy = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 11;BA.debugLine="Private XGmin, XGmax, YGmin, YGmax As Float";
_xgmin = 0f;
_xgmax = 0f;
_ygmin = 0f;
_ygmax = 0f;
 //BA.debugLineNum = 13;BA.debugLine="Public PI=ATan(1)*4 As Float";
_pi = (float) (__c.ATan(1)*4);
 //BA.debugLineNum = 14;BA.debugLine="Public chrt As GRAFIC";
_chrt = new b4a.example.Unfold_Sheets_Parts.grafic();
 //BA.debugLineNum = 16;BA.debugLine="Public InputDialog As B4XDialog";
_inputdialog = new b4a.example.Unfold_Sheets_Parts.b4xdialog();
 //BA.debugLineNum = 18;BA.debugLine="Public XP (100), YP(100), YP1(100), YP2(100) As F";
_xp = new float[(int) (100)];
;
_yp = new float[(int) (100)];
;
_yp1 = new float[(int) (100)];
;
_yp2 = new float[(int) (100)];
;
 //BA.debugLineNum = 19;BA.debugLine="Public YP1H(100), YP2H(100) As Float";
_yp1h = new float[(int) (100)];
;
_yp2h = new float[(int) (100)];
;
 //BA.debugLineNum = 20;BA.debugLine="Public Diametru, Inaltime, Alfa, Beta As Float";
_diametru = 0f;
_inaltime = 0f;
_alfa = 0f;
_beta = 0f;
 //BA.debugLineNum = 21;BA.debugLine="Public NrPct = 8 As Int";
_nrpct = (int) (8);
 //BA.debugLineNum = 23;BA.debugLine="Public pnlInputData As Panel";
_pnlinputdata = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Public txtDiameter As B4XView";
_txtdiameter = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Public txtHeight As B4XView";
_txtheight = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Public txtAlfa As B4XView";
_txtalfa = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Public txtBeta As B4XView";
_txtbeta = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Public btnCalculate As B4XView";
_btncalculate = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Private ImgFolded As B4XImageView";
_imgfolded = new b4a.example.Unfold_Sheets_Parts.b4ximageview();
 //BA.debugLineNum = 32;BA.debugLine="Private ImageView As B4XImageView";
_imageview = new b4a.example.Unfold_Sheets_Parts.b4ximageview();
 //BA.debugLineNum = 33;BA.debugLine="Private pnlRadioButton As B4XView";
_pnlradiobutton = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private RadioButton1 As B4XView";
_radiobutton1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private RadioButton2 As B4XView";
_radiobutton2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 37;BA.debugLine="Private pnlDemo As B4XView";
_pnldemo = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 38;BA.debugLine="Private ImgDemo As B4XImageView";
_imgdemo = new b4a.example.Unfold_Sheets_Parts.b4ximageview();
 //BA.debugLineNum = 39;BA.debugLine="Private btnExitDemo As B4XView";
_btnexitdemo = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 40;BA.debugLine="Private btnLoadDemo As B4XView";
_btnloaddemo = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 42;BA.debugLine="Private pnlTabel As B4XView";
_pnltabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 43;BA.debugLine="Private clvTabel As CustomListView";
_clvtabel = new b4a.example3.customlistview();
 //BA.debugLineNum = 44;BA.debugLine="Private item1 As B4XView";
_item1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 45;BA.debugLine="Private item2 As B4XView";
_item2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 46;BA.debugLine="Private item3 As B4XView";
_item3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 48;BA.debugLine="Private btnTabel As B4XView";
_btntabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 49;BA.debugLine="Private btnExitTabel As B4XView";
_btnexittabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 50;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 54;BA.debugLine="Public Sub Initialize As Object";
 //BA.debugLineNum = 55;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return null;
}
public String  _loadimage() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _b = null;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _c = null;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _d = null;
 //BA.debugLineNum = 318;BA.debugLine="Sub LoadImage";
 //BA.debugLineNum = 319;BA.debugLine="Dim b, c, d As B4XBitmap";
_b = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_c = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_d = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
 //BA.debugLineNum = 320;BA.debugLine="If RadioButton1.Checked=True Then";
if (_radiobutton1.getChecked()==__c.True) { 
 //BA.debugLineNum = 321;BA.debugLine="b=LoadBitmap(File.DirAssets,\"Cylinder_2Planes.jp";
_b = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"Cylinder_2Planes.jpg").getObject()));
 //BA.debugLineNum = 322;BA.debugLine="c=LoadBitmap(File.DirAssets,\"Cylinder_2Planes un";
_c = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"Cylinder_2Planes unfolded V1.jpg").getObject()));
 //BA.debugLineNum = 323;BA.debugLine="d=LoadBitmap(File.DirAssets,\"cylinder_2planes de";
_d = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"cylinder_2planes demo v1.jpg").getObject()));
 }else {
 //BA.debugLineNum = 325;BA.debugLine="b=LoadBitmap(File.DirAssets,\"Cylinder.jpg\")";
_b = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"Cylinder.jpg").getObject()));
 //BA.debugLineNum = 326;BA.debugLine="c=LoadBitmap(File.DirAssets,\"Cylinder_2Planes un";
_c = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"Cylinder_2Planes unfolded V2.jpg").getObject()));
 //BA.debugLineNum = 327;BA.debugLine="d=LoadBitmap(File.DirAssets,\"cylinder_2planes de";
_d = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"cylinder_2planes demo v2.jpg").getObject()));
 };
 //BA.debugLineNum = 329;BA.debugLine="ImageView.SetBitmap(b)  :  ImageView. ResizeMode";
_imageview._setbitmap /*String*/ (_b);
 //BA.debugLineNum = 329;BA.debugLine="ImageView.SetBitmap(b)  :  ImageView. ResizeMode";
_imageview._setresizemode /*String*/ ("FILL");
 //BA.debugLineNum = 330;BA.debugLine="ImgFolded.SetBitmap(c)  :  ImgFolded. ResizeMode";
_imgfolded._setbitmap /*String*/ (_c);
 //BA.debugLineNum = 330;BA.debugLine="ImgFolded.SetBitmap(c)  :  ImgFolded. ResizeMode";
_imgfolded._setresizemode /*String*/ ("FILL");
 //BA.debugLineNum = 331;BA.debugLine="ImgDemo.SetBitmap(d)  :  ImgDemo. ResizeMode = \"F";
_imgdemo._setbitmap /*String*/ (_d);
 //BA.debugLineNum = 331;BA.debugLine="ImgDemo.SetBitmap(d)  :  ImgDemo. ResizeMode = \"F";
_imgdemo._setresizemode /*String*/ ("FILL");
 //BA.debugLineNum = 333;BA.debugLine="pnlDrawing.Visible=False";
_pnldrawing.setVisible(__c.False);
 //BA.debugLineNum = 334;BA.debugLine="ImgFolded.mBase.Visible = True";
_imgfolded._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.True);
 //BA.debugLineNum = 335;BA.debugLine="End Sub";
return "";
}
public boolean  _pnldrawing_touch(int _action,float _x,float _y) throws Exception{
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct = null;
 //BA.debugLineNum = 75;BA.debugLine="Sub pnlDrawing_Touch (Action As Int, X As Float, Y";
 //BA.debugLineNum = 76;BA.debugLine="Dim pct = chrt.PixToReal(X, Y) As Point";
_pct = _chrt._pixtoreal /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_x,_y);
 //BA.debugLineNum = 77;BA.debugLine="lblXY.Visible = True";
_lblxy.setVisible(__c.True);
 //BA.debugLineNum = 78;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,_pnldrawing.TOUCH_ACTION_DOWN,_pnldrawing.TOUCH_ACTION_MOVE,_pnldrawing.TOUCH_ACTION_UP)) {
case 0: {
 //BA.debugLineNum = 80;BA.debugLine="lblXY.Text = Round2(pct.X, 1) & \", \" &  Round2(";
_lblxy.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 81;BA.debugLine="If X <= pnlDrawing.Width/2 Then";
if (_x<=_pnldrawing.getWidth()/(double)2) { 
 //BA.debugLineNum = 82;BA.debugLine="lblXY.Left = X : lblXY.Top = Y";
_lblxy.setLeft((int) (_x));
 //BA.debugLineNum = 82;BA.debugLine="lblXY.Left = X : lblXY.Top = Y";
_lblxy.setTop((int) (_y));
 }else {
 //BA.debugLineNum = 84;BA.debugLine="lblXY.Left = X-lblXY.Width : lblXY.Top = Y";
_lblxy.setLeft((int) (_x-_lblxy.getWidth()));
 //BA.debugLineNum = 84;BA.debugLine="lblXY.Left = X-lblXY.Width : lblXY.Top = Y";
_lblxy.setTop((int) (_y));
 };
 break; }
case 1: {
 //BA.debugLineNum = 87;BA.debugLine="lblXY.Text = Round2(pct.X, 1) & \", \" &  Round2(";
_lblxy.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 88;BA.debugLine="If X <= pnlDrawing.Width/2 Then";
if (_x<=_pnldrawing.getWidth()/(double)2) { 
 //BA.debugLineNum = 89;BA.debugLine="lblXY.Left = X : lblXY.Top = Y";
_lblxy.setLeft((int) (_x));
 //BA.debugLineNum = 89;BA.debugLine="lblXY.Left = X : lblXY.Top = Y";
_lblxy.setTop((int) (_y));
 }else {
 //BA.debugLineNum = 91;BA.debugLine="lblXY.Left = X-lblXY.Width : lblXY.Top = Y";
_lblxy.setLeft((int) (_x-_lblxy.getWidth()));
 //BA.debugLineNum = 91;BA.debugLine="lblXY.Left = X-lblXY.Width : lblXY.Top = Y";
_lblxy.setTop((int) (_y));
 };
 break; }
case 2: {
 //BA.debugLineNum = 94;BA.debugLine="lblXY.Text = \"\"  :  lblXY.Visible = False";
_lblxy.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 94;BA.debugLine="lblXY.Text = \"\"  :  lblXY.Visible = False";
_lblxy.setVisible(__c.False);
 break; }
}
;
 //BA.debugLineNum = 96;BA.debugLine="Return True";
if (true) return __c.True;
 //BA.debugLineNum = 97;BA.debugLine="End Sub";
return false;
}
public String  _rdo_checkedchange(boolean _checked) throws Exception{
 //BA.debugLineNum = 312;BA.debugLine="Sub rdo_CheckedChange(Checked As Boolean)";
 //BA.debugLineNum = 315;BA.debugLine="LoadImage";
_loadimage();
 //BA.debugLineNum = 316;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
