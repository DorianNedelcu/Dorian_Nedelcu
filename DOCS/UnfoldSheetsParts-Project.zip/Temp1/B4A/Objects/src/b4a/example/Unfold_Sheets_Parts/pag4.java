package b4a.example.Unfold_Sheets_Parts;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pag4 extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.Unfold_Sheets_Parts.pag4");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.Unfold_Sheets_Parts.pag4.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public float _pi = 0f;
public b4a.example.Unfold_Sheets_Parts.grafic _chrt1 = null;
public b4a.example.Unfold_Sheets_Parts.grafic _chrt2 = null;
public b4a.example.Unfold_Sheets_Parts.grafic _chrt3 = null;
public b4a.example.Unfold_Sheets_Parts.b4ximageview _imageview4 = null;
public b4a.example.Unfold_Sheets_Parts.b4ximageview _imgfolded4 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btncalculate4 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlinputdata4 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panel2a = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panel2b = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblxy2a = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblxy2b = null;
public b4a.example.Unfold_Sheets_Parts.b4xcombobox _cmbalfa = null;
public b4a.example.Unfold_Sheets_Parts.b4xcombobox _cmbgama = null;
public anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvsdrawing1 = null;
public anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvsdrawing2 = null;
public anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvsdrawing3 = null;
public float _gamapublic = 0f;
public float _alfapublic = 0f;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtdiameter = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtraza = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtnoelem = null;
public float[] _x = null;
public float[] _y1 = null;
public float[] _y2 = null;
public float[] _yh1 = null;
public float[] _yh2a = null;
public float[] _yh2b = null;
public int _nrpct = 0;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnldemo = null;
public b4a.example.Unfold_Sheets_Parts.b4xdialog _inputdialog = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnltabel = null;
public b4a.example3.customlistview _clvtabel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _item1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _item2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _item3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btntabel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnexittabel = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.Unfold_Sheets_Parts.main _main = null;
public b4a.example.Unfold_Sheets_Parts.starter _starter = null;
public b4a.example.Unfold_Sheets_Parts.b4xpages _b4xpages = null;
public b4a.example.Unfold_Sheets_Parts.b4xcollections _b4xcollections = null;
public b4a.example.Unfold_Sheets_Parts.xuiviewsutils _xuiviewsutils = null;
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
anywheresoftware.b4a.objects.collections.List _lst = null;
anywheresoftware.b4a.objects.collections.List _lst1 = null;
int _i = 0;
 //BA.debugLineNum = 55;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 56;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 58;BA.debugLine="Root.LoadLayout(\"lay4\")";
_root.LoadLayout("lay4",ba);
 //BA.debugLineNum = 59;BA.debugLine="B4XPages.SetTitle(Me, \"Cylindrical elbow\")";
_b4xpages._settitle /*String*/ (ba,this,(Object)("Cylindrical elbow"));
 //BA.debugLineNum = 60;BA.debugLine="InputDialog.Initialize(Root)";
_inputdialog._initialize /*String*/ (ba,_root);
 //BA.debugLineNum = 62;BA.debugLine="pnlTabel.Visible=False";
_pnltabel.setVisible(__c.False);
 //BA.debugLineNum = 63;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 65;BA.debugLine="LoadImage4";
_loadimage4();
 //BA.debugLineNum = 68;BA.debugLine="Private lst, lst1 As List";
_lst = new anywheresoftware.b4a.objects.collections.List();
_lst1 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 69;BA.debugLine="lst.Initialize  : lst1.Initialize";
_lst.Initialize();
 //BA.debugLineNum = 69;BA.debugLine="lst.Initialize  : lst1.Initialize";
_lst1.Initialize();
 //BA.debugLineNum = 70;BA.debugLine="lst.AddAll(Array As String(\"24\",\"25\",\"28\",\"30\",\"3";
_lst.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"24","25","28","30","32","33","35","36","40","42","44","45","48","49","50"}));
 //BA.debugLineNum = 71;BA.debugLine="lst.AddAll(Array As String(\"54\",\"55\",\"56\",\"60\",\"6";
_lst.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"54","55","56","60","63","64","65","66","67.5","70","72","75","77","78","80"}));
 //BA.debugLineNum = 72;BA.debugLine="lst.AddAll(Array As String(\"84\",\"85\",\"88\",\"90\"))";
_lst.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"84","85","88","90"}));
 //BA.debugLineNum = 73;BA.debugLine="For i=0 To lst.size-1   'Inversare lista Gama";
{
final int step14 = 1;
final int limit14 = (int) (_lst.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit14 ;_i = _i + step14 ) {
 //BA.debugLineNum = 74;BA.debugLine="lst1.Add(lst.Get(lst.size-i-1))";
_lst1.Add(_lst.Get((int) (_lst.getSize()-_i-1)));
 }
};
 //BA.debugLineNum = 76;BA.debugLine="cmbGama.SetItems(lst1)";
_cmbgama._setitems /*String*/ (_lst1);
 //BA.debugLineNum = 77;BA.debugLine="cmbGama.SelectedIndex = 15 'Setare valoare initia";
_cmbgama._setselectedindex /*int*/ ((int) (15));
 //BA.debugLineNum = 78;BA.debugLine="GamaPublic = 60";
_gamapublic = (float) (60);
 //BA.debugLineNum = 81;BA.debugLine="Private lst1 As List";
_lst1 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 82;BA.debugLine="lst1.Initialize";
_lst1.Initialize();
 //BA.debugLineNum = 83;BA.debugLine="lst1.AddAll(Array As String(\"2.5\",\"3\",\"5\",\"6\",\"7.";
_lst1.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"2.5","3","5","6","7.5","10"}));
 //BA.debugLineNum = 84;BA.debugLine="cmbAlfa.mBase.Enabled=True";
_cmbalfa._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setEnabled(__c.True);
 //BA.debugLineNum = 85;BA.debugLine="cmbAlfa.cmbBox.Clear 'clears the listbox";
_cmbalfa._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .Clear();
 //BA.debugLineNum = 86;BA.debugLine="cmbAlfa.SetItems(lst1)";
_cmbalfa._setitems /*String*/ (_lst1);
 //BA.debugLineNum = 87;BA.debugLine="cmbAlfa.SelectedIndex = 3 'Setare valoare initial";
_cmbalfa._setselectedindex /*int*/ ((int) (3));
 //BA.debugLineNum = 88;BA.debugLine="AlfaPublic = 6";
_alfapublic = (float) (6);
 //BA.debugLineNum = 89;BA.debugLine="txtNoElem.Text = \"6\"  ' Numar elemente cot ptr. u";
_txtnoelem.setText(BA.ObjectToCharSequence("6"));
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public String  _btncalculate4_click() throws Exception{
 //BA.debugLineNum = 104;BA.debugLine="Private Sub btnCalculate4_Click";
 //BA.debugLineNum = 105;BA.debugLine="pnlInputData4.Visible = True";
_pnlinputdata4.setVisible(__c.True);
 //BA.debugLineNum = 106;BA.debugLine="btnCalculate4.Visible = False";
_btncalculate4.setVisible(__c.False);
 //BA.debugLineNum = 107;BA.debugLine="End Sub";
return "";
}
public String  _btncalculateid_click() throws Exception{
 //BA.debugLineNum = 109;BA.debugLine="Private Sub btnCalculateID_Click";
 //BA.debugLineNum = 110;BA.debugLine="pnlInputData4.Visible = False";
_pnlinputdata4.setVisible(__c.False);
 //BA.debugLineNum = 111;BA.debugLine="Panel2a.Visible=True : Panel2b.Visible=True";
_panel2a.setVisible(__c.True);
 //BA.debugLineNum = 111;BA.debugLine="Panel2a.Visible=True : Panel2b.Visible=True";
_panel2b.setVisible(__c.True);
 //BA.debugLineNum = 112;BA.debugLine="ImgFolded4.mBase.Visible = False";
_imgfolded4._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.False);
 //BA.debugLineNum = 114;BA.debugLine="pnlDemo.Visible = False";
_pnldemo.setVisible(__c.False);
 //BA.debugLineNum = 115;BA.debugLine="ImageView4.mbase.Visible = True";
_imageview4._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.True);
 //BA.debugLineNum = 116;BA.debugLine="Calcul_Desfasurata";
_calcul_desfasurata();
 //BA.debugLineNum = 117;BA.debugLine="End Sub";
return "";
}
public String  _btncancelid_click() throws Exception{
 //BA.debugLineNum = 119;BA.debugLine="Private Sub btnCancelID_Click";
 //BA.debugLineNum = 120;BA.debugLine="pnlInputData4.Visible = False";
_pnlinputdata4.setVisible(__c.False);
 //BA.debugLineNum = 121;BA.debugLine="Panel2a.Visible=False : Panel2b.Visible=False";
_panel2a.setVisible(__c.False);
 //BA.debugLineNum = 121;BA.debugLine="Panel2a.Visible=False : Panel2b.Visible=False";
_panel2b.setVisible(__c.False);
 //BA.debugLineNum = 122;BA.debugLine="ImgFolded4.mBase.Visible = True";
_imgfolded4._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.True);
 //BA.debugLineNum = 123;BA.debugLine="btnCalculate4.Visible = True";
_btncalculate4.setVisible(__c.True);
 //BA.debugLineNum = 124;BA.debugLine="LoadImage4";
_loadimage4();
 //BA.debugLineNum = 125;BA.debugLine="End Sub";
return "";
}
public String  _btnexittabel_click() throws Exception{
 //BA.debugLineNum = 445;BA.debugLine="Private Sub btnExitTabel_Click";
 //BA.debugLineNum = 446;BA.debugLine="pnlTabel.Visible=False";
_pnltabel.setVisible(__c.False);
 //BA.debugLineNum = 447;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 448;BA.debugLine="btnCalculate4.Visible=True";
_btncalculate4.setVisible(__c.True);
 //BA.debugLineNum = 449;BA.debugLine="Panel2a.Visible = True";
_panel2a.setVisible(__c.True);
 //BA.debugLineNum = 450;BA.debugLine="Panel2b.Visible = True";
_panel2b.setVisible(__c.True);
 //BA.debugLineNum = 451;BA.debugLine="pnlDemo.Visible = True";
_pnldemo.setVisible(__c.True);
 //BA.debugLineNum = 452;BA.debugLine="End Sub";
return "";
}
public String  _btntabel_click() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
float _pas = 0f;
int _i = 0;
 //BA.debugLineNum = 409;BA.debugLine="Private Sub btnTabel_Click";
 //BA.debugLineNum = 411;BA.debugLine="Dim xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 412;BA.debugLine="clvTabel.Clear";
_clvtabel._clear();
 //BA.debugLineNum = 414;BA.debugLine="Dim p As B4XView  = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 415;BA.debugLine="p.SetLayoutAnimated(0,0,0,100%X, 60dip)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),__c.PerXToCurrent((float) (100),ba),__c.DipToCurrent((int) (60)));
 //BA.debugLineNum = 416;BA.debugLine="p.LoadLayout(\"item\")";
_p.LoadLayout("item",ba);
 //BA.debugLineNum = 418;BA.debugLine="item1.Text = \"Angle/X [mm]\"";
_item1.setText(BA.ObjectToCharSequence("Angle/X [mm]"));
 //BA.debugLineNum = 419;BA.debugLine="item2.Text=\"Y1 [mm]\"";
_item2.setText(BA.ObjectToCharSequence("Y1 [mm]"));
 //BA.debugLineNum = 420;BA.debugLine="item3.Text=\"Y2a/Y2b [mm]\"";
_item3.setText(BA.ObjectToCharSequence("Y2a/Y2b [mm]"));
 //BA.debugLineNum = 422;BA.debugLine="clvTabel.Add(p,\"\")";
_clvtabel._add(_p,(Object)(""));
 //BA.debugLineNum = 423;BA.debugLine="Dim pas=360/(4 * NrPct) As Float";
_pas = (float) (360/(double)(4*_nrpct));
 //BA.debugLineNum = 424;BA.debugLine="For i = 1 To 4 * NrPct + 1";
{
final int step11 = 1;
final int limit11 = (int) (4*_nrpct+1);
_i = (int) (1) ;
for (;_i <= limit11 ;_i = _i + step11 ) {
 //BA.debugLineNum = 425;BA.debugLine="Dim p As B4XView  = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 426;BA.debugLine="p.SetLayoutAnimated(100,0,0,100%X, 60dip)";
_p.SetLayoutAnimated((int) (100),(int) (0),(int) (0),__c.PerXToCurrent((float) (100),ba),__c.DipToCurrent((int) (60)));
 //BA.debugLineNum = 427;BA.debugLine="p.LoadLayout(\"item\")";
_p.LoadLayout("item",ba);
 //BA.debugLineNum = 430;BA.debugLine="item1.Text = ((i-1) * pas) & \" / \" & Round2(X(i)";
_item1.setText(BA.ObjectToCharSequence(BA.NumberToString(((_i-1)*_pas))+" / "+BA.NumberToString(__c.Round2(_x[_i],(int) (2)))));
 //BA.debugLineNum = 431;BA.debugLine="item2.Text=Round2(YH1(i), 2)";
_item2.setText(BA.ObjectToCharSequence(__c.Round2(_yh1[_i],(int) (2))));
 //BA.debugLineNum = 432;BA.debugLine="item3.Text=Round2(YH2a(i), 2) & \" / \" & Round2(Y";
_item3.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_yh2a[_i],(int) (2)))+" / "+BA.NumberToString(__c.Round2(_yh2b[_i],(int) (2)))));
 //BA.debugLineNum = 434;BA.debugLine="clvTabel.Add(p,\"\")";
_clvtabel._add(_p,(Object)(""));
 }
};
 //BA.debugLineNum = 436;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 437;BA.debugLine="btnCalculate4.Visible=False";
_btncalculate4.setVisible(__c.False);
 //BA.debugLineNum = 438;BA.debugLine="pnlTabel.Visible=True";
_pnltabel.setVisible(__c.True);
 //BA.debugLineNum = 439;BA.debugLine="btnExitTabel.Visible=True";
_btnexittabel.setVisible(__c.True);
 //BA.debugLineNum = 440;BA.debugLine="Panel2a.Visible = False";
_panel2a.setVisible(__c.False);
 //BA.debugLineNum = 441;BA.debugLine="Panel2b.Visible = False";
_panel2b.setVisible(__c.False);
 //BA.debugLineNum = 442;BA.debugLine="pnlDemo.Visible = False";
_pnldemo.setVisible(__c.False);
 //BA.debugLineNum = 443;BA.debugLine="End Sub";
return "";
}
public void  _calcul_desfasurata() throws Exception{
ResumableSub_Calcul_Desfasurata rsub = new ResumableSub_Calcul_Desfasurata(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Calcul_Desfasurata extends BA.ResumableSub {
public ResumableSub_Calcul_Desfasurata(b4a.example.Unfold_Sheets_Parts.pag4 parent) {
this.parent = parent;
}
b4a.example.Unfold_Sheets_Parts.pag4 parent;
float _diametru = 0f;
float _raza = 0f;
float _gamar = 0f;
float _alfar = 0f;
int _nec = 0;
float _ld = 0f;
float _aria1 = 0f;
float _aria2 = 0f;
float _k = 0f;
float _t = 0f;
float _h1 = 0f;
float _h2 = 0f;
String _mesaj = "";
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _icon = null;
Object _msj = null;
int _result = 0;
float _rpd2 = 0f;
float _rmd2 = 0f;
float _teta = 0f;
int _i = 0;
float _lg = 0f;
float _xgmin1 = 0f;
float _xgmax1 = 0f;
float _ygmin1 = 0f;
float _ygmax1 = 0f;
float _xgmin2 = 0f;
float _xgmax2 = 0f;
float _ygmin2 = 0f;
float _ygmax2 = 0f;
float _xgmin3 = 0f;
float _xgmax3 = 0f;
float _ygmin3 = 0f;
float _ygmax3 = 0f;
anywheresoftware.b4a.objects.collections.List _listxy1 = null;
anywheresoftware.b4a.objects.collections.List _listxy2a = null;
anywheresoftware.b4a.objects.collections.List _listxy2b = null;
anywheresoftware.b4a.objects.collections.List _lstxy1 = null;
anywheresoftware.b4a.objects.collections.List _lstxy2a = null;
anywheresoftware.b4a.objects.collections.List _lstxy2b = null;
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct1 = null;
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct2 = null;
int _cnt = 0;
float[] _x11 = null;
float[] _y11 = null;
float[] _x22 = null;
float[] _y22 = null;
float _unghi = 0f;
float _xant1 = 0f;
float _yant1 = 0f;
float _xant2 = 0f;
float _yant2 = 0f;
b4a.example.Unfold_Sheets_Parts.b4xlongtexttemplate _s = null;
int step26;
int limit26;
int step57;
int limit57;
int step95;
int limit95;
int step107;
int limit107;
int step124;
int limit124;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 182;BA.debugLine="Dim Diametru, Raza, GamaR, AlfaR As Float";
_diametru = 0f;
_raza = 0f;
_gamar = 0f;
_alfar = 0f;
 //BA.debugLineNum = 183;BA.debugLine="Dim NrPct = 8, nec As Int";
parent._nrpct = (int) (8);
_nec = 0;
 //BA.debugLineNum = 184;BA.debugLine="Private Ld, Aria1, Aria2, K, t, H1, H2 As Float";
_ld = 0f;
_aria1 = 0f;
_aria2 = 0f;
_k = 0f;
_t = 0f;
_h1 = 0f;
_h2 = 0f;
 //BA.debugLineNum = 185;BA.debugLine="Dim X (100), Y1(100), Y2(100) As Float";
parent._x = new float[(int) (100)];
;
parent._y1 = new float[(int) (100)];
;
parent._y2 = new float[(int) (100)];
;
 //BA.debugLineNum = 188;BA.debugLine="Diametru = txtDiameter.Text";
_diametru = (float)(Double.parseDouble(parent._txtdiameter.getText()));
 //BA.debugLineNum = 189;BA.debugLine="Raza =  txtRaza.Text";
_raza = (float)(Double.parseDouble(parent._txtraza.getText()));
 //BA.debugLineNum = 190;BA.debugLine="GamaR = GamaPublic * PI / 180";
_gamar = (float) (parent._gamapublic*parent._pi/(double)180);
 //BA.debugLineNum = 191;BA.debugLine="AlfaR = AlfaPublic * PI / 180";
_alfar = (float) (parent._alfapublic*parent._pi/(double)180);
 //BA.debugLineNum = 192;BA.debugLine="nec = txtNoElem.Text";
_nec = (int)(Double.parseDouble(parent._txtnoelem.getText()));
 //BA.debugLineNum = 195;BA.debugLine="Dim mesaj=\"\" As String";
_mesaj = "";
 //BA.debugLineNum = 203;BA.debugLine="If mesaj<>\"\" Then";
if (true) break;

case 1:
//if
this.state = 4;
if ((_mesaj).equals("") == false) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 204;BA.debugLine="Dim icon As B4XBitmap = xui.LoadBitmap(File.DirA";
_icon = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_icon = parent._xui.LoadBitmap(parent.__c.File.getDirAssets(),"edit.jpg");
 //BA.debugLineNum = 205;BA.debugLine="Dim msj As Object =xui.Msgbox2Async(mesaj, \"Wron";
_msj = parent._xui.Msgbox2Async(ba,BA.ObjectToCharSequence(_mesaj),BA.ObjectToCharSequence("Wrong input data"),"OK","","",(anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper(), (android.graphics.Bitmap)(_icon.getObject())));
 //BA.debugLineNum = 206;BA.debugLine="Wait For (msj) Msgbox_Result (Result As Int)";
parent.__c.WaitFor("msgbox_result", ba, this, _msj);
this.state = 35;
return;
case 35:
//C
this.state = 4;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 207;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 4:
//C
this.state = 5;
;
 //BA.debugLineNum = 210;BA.debugLine="Dim RpD2=Raza+Diametru/2, RmD2 = Raza- Diametru/2";
_rpd2 = (float) (_raza+_diametru/(double)2);
_rmd2 = (float) (_raza-_diametru/(double)2);
 //BA.debugLineNum = 213;BA.debugLine="K = Raza * Tan(GamaR / 2)";
_k = (float) (_raza*parent.__c.Tan(_gamar/(double)2));
 //BA.debugLineNum = 214;BA.debugLine="t = Raza * Tan(AlfaR)";
_t = (float) (_raza*parent.__c.Tan(_alfar));
 //BA.debugLineNum = 215;BA.debugLine="H1 = t - Diametru * Tan(AlfaR) / 2";
_h1 = (float) (_t-_diametru*parent.__c.Tan(_alfar)/(double)2);
 //BA.debugLineNum = 216;BA.debugLine="H2 = t + Diametru * Tan(AlfaR) / 2";
_h2 = (float) (_t+_diametru*parent.__c.Tan(_alfar)/(double)2);
 //BA.debugLineNum = 217;BA.debugLine="Ld = PI * Diametru   ' Lungime desfasurata";
_ld = (float) (parent._pi*_diametru);
 //BA.debugLineNum = 220;BA.debugLine="Private Teta As Float";
_teta = 0f;
 //BA.debugLineNum = 221;BA.debugLine="Aria1 = PI * Diametru * (H2 - Diametru * (Tan(Alf";
_aria1 = (float) (parent._pi*_diametru*(_h2-_diametru*(parent.__c.Tan(_alfar)+parent.__c.Tan(0))/(double)2));
 //BA.debugLineNum = 222;BA.debugLine="Aria2 = PI * Diametru * (2 * H2 - Diametru * (Tan";
_aria2 = (float) (parent._pi*_diametru*(2*_h2-_diametru*(parent.__c.Tan(_alfar)+parent.__c.Tan(0))/(double)2));
 //BA.debugLineNum = 223;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 5:
//for
this.state = 8;
step26 = 1;
limit26 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 36;
if (true) break;

case 36:
//C
this.state = 8;
if ((step26 > 0 && _i <= limit26) || (step26 < 0 && _i >= limit26)) this.state = 7;
if (true) break;

case 37:
//C
this.state = 36;
_i = ((int)(0 + _i + step26)) ;
if (true) break;

case 7:
//C
this.state = 37;
 //BA.debugLineNum = 224;BA.debugLine="Teta = (i - 1) * PI / 2 / NrPct";
_teta = (float) ((_i-1)*parent._pi/(double)2/(double)parent._nrpct);
 //BA.debugLineNum = 225;BA.debugLine="X(i) = Teta * Diametru/ 2";
parent._x[_i] = (float) (_teta*_diametru/(double)2);
 //BA.debugLineNum = 226;BA.debugLine="Y1(i) = Diametru / 2 * (1 - Cos(Teta)) * Tan(Alf";
parent._y1[_i] = (float) (_diametru/(double)2*(1-parent.__c.Cos(_teta))*parent.__c.Tan(_alfar));
 //BA.debugLineNum = 227;BA.debugLine="Y2(i) = Y1(i)";
parent._y2[_i] = parent._y1[_i];
 if (true) break;
if (true) break;

case 8:
//C
this.state = 9;
;
 //BA.debugLineNum = 230;BA.debugLine="Dim LG = 0.03 * PI * Diametru As Float";
_lg = (float) (0.03*parent._pi*_diametru);
 //BA.debugLineNum = 231;BA.debugLine="Private XGmin1, XGmax1, YGmin1, YGmax1 As Float";
_xgmin1 = 0f;
_xgmax1 = 0f;
_ygmin1 = 0f;
_ygmax1 = 0f;
 //BA.debugLineNum = 232;BA.debugLine="Private XGmin2, XGmax2, YGmin2, YGmax2 As Float";
_xgmin2 = 0f;
_xgmax2 = 0f;
_ygmin2 = 0f;
_ygmax2 = 0f;
 //BA.debugLineNum = 233;BA.debugLine="Private XGmin3, XGmax3, YGmin3, YGmax3 As Float";
_xgmin3 = 0f;
_xgmax3 = 0f;
_ygmin3 = 0f;
_ygmax3 = 0f;
 //BA.debugLineNum = 234;BA.debugLine="XGmin1=-LG : XGmax1 = Ld+LG : YGmin1=-LG : YGmax1";
_xgmin1 = (float) (-_lg);
 //BA.debugLineNum = 234;BA.debugLine="XGmin1=-LG : XGmax1 = Ld+LG : YGmin1=-LG : YGmax1";
_xgmax1 = (float) (_ld+_lg);
 //BA.debugLineNum = 234;BA.debugLine="XGmin1=-LG : XGmax1 = Ld+LG : YGmin1=-LG : YGmax1";
_ygmin1 = (float) (-_lg);
 //BA.debugLineNum = 234;BA.debugLine="XGmin1=-LG : XGmax1 = Ld+LG : YGmin1=-LG : YGmax1";
_ygmax1 = (float) (_h2+_lg);
 //BA.debugLineNum = 235;BA.debugLine="XGmin2=-LG : XGmax2 = Ld+LG : YGmin2=-LG : YGmax2";
_xgmin2 = (float) (-_lg);
 //BA.debugLineNum = 235;BA.debugLine="XGmin2=-LG : XGmax2 = Ld+LG : YGmin2=-LG : YGmax2";
_xgmax2 = (float) (_ld+_lg);
 //BA.debugLineNum = 235;BA.debugLine="XGmin2=-LG : XGmax2 = Ld+LG : YGmin2=-LG : YGmax2";
_ygmin2 = (float) (-_lg);
 //BA.debugLineNum = 235;BA.debugLine="XGmin2=-LG : XGmax2 = Ld+LG : YGmin2=-LG : YGmax2";
_ygmax2 = (float) (2*_h2+_lg);
 //BA.debugLineNum = 236;BA.debugLine="XGmin3=-LG : XGmax3 = RpD2 * Sin(GamaR)+LG : YGmi";
_xgmin3 = (float) (-_lg);
 //BA.debugLineNum = 236;BA.debugLine="XGmin3=-LG : XGmax3 = RpD2 * Sin(GamaR)+LG : YGmi";
_xgmax3 = (float) (_rpd2*parent.__c.Sin(_gamar)+_lg);
 //BA.debugLineNum = 236;BA.debugLine="XGmin3=-LG : XGmax3 = RpD2 * Sin(GamaR)+LG : YGmi";
_ygmin3 = (float) (-_lg);
 //BA.debugLineNum = 236;BA.debugLine="XGmin3=-LG : XGmax3 = RpD2 * Sin(GamaR)+LG : YGmi";
_ygmax3 = (float) (_rpd2+_lg);
 //BA.debugLineNum = 238;BA.debugLine="chrt1.Initialize(Panel2a, cvsDrawing1, XGmin1, YG";
parent._chrt1._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(parent._panel2a.getObject())),parent._cvsdrawing1,_xgmin1,_ygmin1,_xgmax1,_ygmax1);
 //BA.debugLineNum = 239;BA.debugLine="chrt2.Initialize(Panel2b, cvsDrawing2, XGmin2, YG";
parent._chrt2._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(parent._panel2b.getObject())),parent._cvsdrawing2,_xgmin2,_ygmin2,_xgmax2,_ygmax2);
 //BA.debugLineNum = 240;BA.debugLine="chrt3.Initialize(pnlDemo, cvsDrawing3, XGmin3, YG";
parent._chrt3._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(parent._pnldemo.getObject())),parent._cvsdrawing3,_xgmin3,_ygmin3,_xgmax3,_ygmax3);
 //BA.debugLineNum = 241;BA.debugLine="cvsDrawing3.DrawColor(Colors.Gray)  'Stergere tra";
parent._cvsdrawing3.DrawColor(parent.__c.Colors.Gray);
 //BA.debugLineNum = 243;BA.debugLine="Dim ListXY1, ListXY2a, ListXY2b As List";
_listxy1 = new anywheresoftware.b4a.objects.collections.List();
_listxy2a = new anywheresoftware.b4a.objects.collections.List();
_listxy2b = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 244;BA.debugLine="Dim lstXY1, lstXY2a, lstXY2b As List";
_lstxy1 = new anywheresoftware.b4a.objects.collections.List();
_lstxy2a = new anywheresoftware.b4a.objects.collections.List();
_lstxy2b = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 245;BA.debugLine="ListXY1.Initialize : ListXY2a.Initialize : ListXY";
_listxy1.Initialize();
 //BA.debugLineNum = 245;BA.debugLine="ListXY1.Initialize : ListXY2a.Initialize : ListXY";
_listxy2a.Initialize();
 //BA.debugLineNum = 245;BA.debugLine="ListXY1.Initialize : ListXY2a.Initialize : ListXY";
_listxy2b.Initialize();
 //BA.debugLineNum = 248;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 9:
//for
this.state = 12;
step57 = 1;
limit57 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 38;
if (true) break;

case 38:
//C
this.state = 12;
if ((step57 > 0 && _i <= limit57) || (step57 < 0 && _i >= limit57)) this.state = 11;
if (true) break;

case 39:
//C
this.state = 38;
_i = ((int)(0 + _i + step57)) ;
if (true) break;

case 11:
//C
this.state = 39;
 //BA.debugLineNum = 249;BA.debugLine="YH1(i)=H1+Y1(i)";
parent._yh1[_i] = (float) (_h1+parent._y1[_i]);
 //BA.debugLineNum = 250;BA.debugLine="YH2a(i)=H2-H1-Y2(i)";
parent._yh2a[_i] = (float) (_h2-_h1-parent._y2[_i]);
 //BA.debugLineNum = 251;BA.debugLine="YH2b(i)=H2+H1+Y2(i)";
parent._yh2b[_i] = (float) (_h2+_h1+parent._y2[_i]);
 //BA.debugLineNum = 253;BA.debugLine="lstXY1.Initialize : lstXY1.Add(X(i)) : lstXY1.Ad";
_lstxy1.Initialize();
 //BA.debugLineNum = 253;BA.debugLine="lstXY1.Initialize : lstXY1.Add(X(i)) : lstXY1.Ad";
_lstxy1.Add((Object)(parent._x[_i]));
 //BA.debugLineNum = 253;BA.debugLine="lstXY1.Initialize : lstXY1.Add(X(i)) : lstXY1.Ad";
_lstxy1.Add((Object)(parent._yh1[_i]));
 //BA.debugLineNum = 254;BA.debugLine="ListXY1.Add(lstXY1)";
_listxy1.Add((Object)(_lstxy1.getObject()));
 //BA.debugLineNum = 256;BA.debugLine="lstXY2a.Initialize : lstXY2a.Add(X(i)) : lstXY2a";
_lstxy2a.Initialize();
 //BA.debugLineNum = 256;BA.debugLine="lstXY2a.Initialize : lstXY2a.Add(X(i)) : lstXY2a";
_lstxy2a.Add((Object)(parent._x[_i]));
 //BA.debugLineNum = 256;BA.debugLine="lstXY2a.Initialize : lstXY2a.Add(X(i)) : lstXY2a";
_lstxy2a.Add((Object)(parent._yh2a[_i]));
 //BA.debugLineNum = 257;BA.debugLine="ListXY2a.Add(lstXY2a)";
_listxy2a.Add((Object)(_lstxy2a.getObject()));
 //BA.debugLineNum = 259;BA.debugLine="lstXY2b.Initialize : lstXY2b.Add(X(i)) : lstXY2b";
_lstxy2b.Initialize();
 //BA.debugLineNum = 259;BA.debugLine="lstXY2b.Initialize : lstXY2b.Add(X(i)) : lstXY2b";
_lstxy2b.Add((Object)(parent._x[_i]));
 //BA.debugLineNum = 259;BA.debugLine="lstXY2b.Initialize : lstXY2b.Add(X(i)) : lstXY2b";
_lstxy2b.Add((Object)(parent._yh2b[_i]));
 //BA.debugLineNum = 260;BA.debugLine="ListXY2b.Add(lstXY2b)";
_listxy2b.Add((Object)(_lstxy2b.getObject()));
 if (true) break;
if (true) break;

case 12:
//C
this.state = 13;
;
 //BA.debugLineNum = 263;BA.debugLine="chrt1.DrawCurve(ListXY1, Colors.Blue, 3dip, False";
parent._chrt1._drawcurve /*String*/ (_listxy1,(long) (parent.__c.Colors.Blue),parent.__c.DipToCurrent((int) (3)),parent.__c.False,parent.__c.True,(int) (0),(int) (0));
 //BA.debugLineNum = 264;BA.debugLine="chrt2.DrawCurve(ListXY2a, Colors.Blue, 3dip, Fals";
parent._chrt2._drawcurve /*String*/ (_listxy2a,(long) (parent.__c.Colors.Blue),parent.__c.DipToCurrent((int) (3)),parent.__c.False,parent.__c.True,(int) (0),(int) (0));
 //BA.debugLineNum = 265;BA.debugLine="chrt2.DrawCurve(ListXY2b, Colors.Blue, 3dip, Fals";
parent._chrt2._drawcurve /*String*/ (_listxy2b,(long) (parent.__c.Colors.Blue),parent.__c.DipToCurrent((int) (3)),parent.__c.False,parent.__c.False,(int) (0),(int) (0));
 //BA.debugLineNum = 267;BA.debugLine="cvsDrawing1.DrawCircle(chrt1.RealToPix(0, 0).X, c";
parent._cvsdrawing1.DrawCircle(parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).X /*float*/ ,parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).Y /*float*/ ,(float) (parent.__c.DipToCurrent((int) (5))),parent.__c.Colors.Red,parent.__c.True,(float) (0));
 //BA.debugLineNum = 268;BA.debugLine="cvsDrawing2.DrawCircle(chrt2.RealToPix(0, 0).X, c";
parent._cvsdrawing2.DrawCircle(parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).X /*float*/ ,parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).Y /*float*/ ,(float) (parent.__c.DipToCurrent((int) (5))),parent.__c.Colors.Red,parent.__c.True,(float) (0));
 //BA.debugLineNum = 271;BA.debugLine="Dim pct1, Pct2 As Point";
_pct1 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
_pct2 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
 //BA.debugLineNum = 272;BA.debugLine="pct1 = chrt1.RealToPix(0, 0)  :  Pct2 = chrt1.Rea";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0));
 //BA.debugLineNum = 272;BA.debugLine="pct1 = chrt1.RealToPix(0, 0)  :  Pct2 = chrt1.Rea";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),_h1);
 //BA.debugLineNum = 273;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 274;BA.debugLine="pct1 = chrt1.RealToPix(0, 0)  :  Pct2 = chrt1.Rea";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0));
 //BA.debugLineNum = 274;BA.debugLine="pct1 = chrt1.RealToPix(0, 0)  :  Pct2 = chrt1.Rea";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,(float) (0));
 //BA.debugLineNum = 275;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 276;BA.debugLine="pct1 = chrt1.RealToPix(Ld , 0)  :  Pct2 = chrt1.R";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,(float) (0));
 //BA.debugLineNum = 276;BA.debugLine="pct1 = chrt1.RealToPix(Ld , 0)  :  Pct2 = chrt1.R";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,_h1);
 //BA.debugLineNum = 277;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 280;BA.debugLine="pct1 = chrt2.RealToPix(0, H2-H1)  :  Pct2 = chrt2";
_pct1 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (_h2-_h1));
 //BA.debugLineNum = 280;BA.debugLine="pct1 = chrt2.RealToPix(0, H2-H1)  :  Pct2 = chrt2";
_pct2 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (_h2+_h1));
 //BA.debugLineNum = 281;BA.debugLine="cvsDrawing2.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing2.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 282;BA.debugLine="pct1 = chrt2.RealToPix(Ld , H2-H1)  :  Pct2 = chr";
_pct1 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,(float) (_h2-_h1));
 //BA.debugLineNum = 282;BA.debugLine="pct1 = chrt2.RealToPix(Ld , H2-H1)  :  Pct2 = chr";
_pct2 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,(float) (_h2+_h1));
 //BA.debugLineNum = 283;BA.debugLine="cvsDrawing2.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing2.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 286;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 13:
//for
this.state = 16;
step95 = 1;
limit95 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 40;
if (true) break;

case 40:
//C
this.state = 16;
if ((step95 > 0 && _i <= limit95) || (step95 < 0 && _i >= limit95)) this.state = 15;
if (true) break;

case 41:
//C
this.state = 40;
_i = ((int)(0 + _i + step95)) ;
if (true) break;

case 15:
//C
this.state = 41;
 //BA.debugLineNum = 287;BA.debugLine="pct1 = chrt1.RealToPix(X(i), 0)  :  Pct2 = chrt1";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],(float) (0));
 //BA.debugLineNum = 287;BA.debugLine="pct1 = chrt1.RealToPix(X(i), 0)  :  Pct2 = chrt1";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],(float) (_h1+parent._y1[_i]));
 //BA.debugLineNum = 288;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Black,(float) (parent.__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 290;BA.debugLine="pct1 = chrt2.RealToPix(X(i), H2-H1-Y2(i))  :  Pc";
_pct1 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],(float) (_h2-_h1-parent._y2[_i]));
 //BA.debugLineNum = 290;BA.debugLine="pct1 = chrt2.RealToPix(X(i), H2-H1-Y2(i))  :  Pc";
_pct2 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],(float) (_h2+_h1+parent._y2[_i]));
 //BA.debugLineNum = 291;BA.debugLine="cvsDrawing2.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct";
parent._cvsdrawing2.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Black,(float) (parent.__c.DipToCurrent((int) (1))));
 if (true) break;
if (true) break;

case 16:
//C
this.state = 17;
;
 //BA.debugLineNum = 295;BA.debugLine="pnlDemo.Visible = True";
parent._pnldemo.setVisible(parent.__c.True);
 //BA.debugLineNum = 296;BA.debugLine="ImageView4.mbase.Visible = False";
parent._imageview4._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(parent.__c.False);
 //BA.debugLineNum = 299;BA.debugLine="Dim cnt=0 As Int";
_cnt = (int) (0);
 //BA.debugLineNum = 300;BA.debugLine="Dim X11(60), Y11(60), X22(60), Y22(60) As Float";
_x11 = new float[(int) (60)];
;
_y11 = new float[(int) (60)];
;
_x22 = new float[(int) (60)];
;
_y22 = new float[(int) (60)];
;
 //BA.debugLineNum = 301;BA.debugLine="For i = 1 To (2 * nec - 2) + 1";
if (true) break;

case 17:
//for
this.state = 24;
step107 = 1;
limit107 = (int) ((2*_nec-2)+1);
_i = (int) (1) ;
this.state = 42;
if (true) break;

case 42:
//C
this.state = 24;
if ((step107 > 0 && _i <= limit107) || (step107 < 0 && _i >= limit107)) this.state = 19;
if (true) break;

case 43:
//C
this.state = 42;
_i = ((int)(0 + _i + step107)) ;
if (true) break;

case 19:
//C
this.state = 20;
 //BA.debugLineNum = 302;BA.debugLine="Dim unghi = AlfaR * (i - 1) As Float";
_unghi = (float) (_alfar*(_i-1));
 //BA.debugLineNum = 303;BA.debugLine="pct1 = chrt3.RealToPix(0, RpD2)  :  Pct2 = chrt3";
_pct1 = parent._chrt3._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),_rpd2);
 //BA.debugLineNum = 303;BA.debugLine="pct1 = chrt3.RealToPix(0, RpD2)  :  Pct2 = chrt3";
_pct2 = parent._chrt3._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (_rpd2*parent.__c.Sin(_unghi)),(float) (_rpd2-_rpd2*parent.__c.Cos(_unghi)));
 //BA.debugLineNum = 304;BA.debugLine="cvsDrawing3.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct";
parent._cvsdrawing3.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Yellow,(float) (parent.__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 305;BA.debugLine="If  i=1 Or Par(i)=True Or i=(2 * nec - 2) + 1 Th";
if (true) break;

case 20:
//if
this.state = 23;
if (_i==1 || parent._par(_i)==parent.__c.True || _i==(2*_nec-2)+1) { 
this.state = 22;
}if (true) break;

case 22:
//C
this.state = 23;
 //BA.debugLineNum = 306;BA.debugLine="pct1 = chrt3.RealToPix(RpD2*Sin(unghi), RpD2-Rp";
_pct1 = parent._chrt3._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (_rpd2*parent.__c.Sin(_unghi)),(float) (_rpd2-_rpd2*parent.__c.Cos(_unghi)));
 //BA.debugLineNum = 306;BA.debugLine="pct1 = chrt3.RealToPix(RpD2*Sin(unghi), RpD2-Rp";
_pct2 = parent._chrt3._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (_rmd2*parent.__c.Sin(_unghi)),(float) (_rpd2-_rmd2*parent.__c.Cos(_unghi)));
 //BA.debugLineNum = 307;BA.debugLine="cnt=cnt+1  :  X11(cnt) = pct1.X : Y11(cnt) = pc";
_cnt = (int) (_cnt+1);
 //BA.debugLineNum = 307;BA.debugLine="cnt=cnt+1  :  X11(cnt) = pct1.X : Y11(cnt) = pc";
_x11[_cnt] = _pct1.X /*float*/ ;
 //BA.debugLineNum = 307;BA.debugLine="cnt=cnt+1  :  X11(cnt) = pct1.X : Y11(cnt) = pc";
_y11[_cnt] = _pct1.Y /*float*/ ;
 //BA.debugLineNum = 308;BA.debugLine="X22(cnt) = Pct2.X : Y22(cnt) = Pct2.Y";
_x22[_cnt] = _pct2.X /*float*/ ;
 //BA.debugLineNum = 308;BA.debugLine="X22(cnt) = Pct2.X : Y22(cnt) = Pct2.Y";
_y22[_cnt] = _pct2.Y /*float*/ ;
 //BA.debugLineNum = 309;BA.debugLine="cvsDrawing3.DrawLine(pct1.X, pct1.Y, Pct2.X, Pc";
parent._cvsdrawing3.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 if (true) break;

case 23:
//C
this.state = 43;
;
 if (true) break;
if (true) break;

case 24:
//C
this.state = 25;
;
 //BA.debugLineNum = 313;BA.debugLine="Dim Xant1, Yant1, Xant2, Yant2 As Float";
_xant1 = 0f;
_yant1 = 0f;
_xant2 = 0f;
_yant2 = 0f;
 //BA.debugLineNum = 314;BA.debugLine="For i = 1 To cnt";
if (true) break;

case 25:
//for
this.state = 34;
step124 = 1;
limit124 = _cnt;
_i = (int) (1) ;
this.state = 44;
if (true) break;

case 44:
//C
this.state = 34;
if ((step124 > 0 && _i <= limit124) || (step124 < 0 && _i >= limit124)) this.state = 27;
if (true) break;

case 45:
//C
this.state = 44;
_i = ((int)(0 + _i + step124)) ;
if (true) break;

case 27:
//C
this.state = 28;
 //BA.debugLineNum = 315;BA.debugLine="If i=1 Then";
if (true) break;

case 28:
//if
this.state = 33;
if (_i==1) { 
this.state = 30;
}else {
this.state = 32;
}if (true) break;

case 30:
//C
this.state = 33;
 //BA.debugLineNum = 316;BA.debugLine="Xant1=X11(i) : Yant1=Y11(i)";
_xant1 = _x11[_i];
 //BA.debugLineNum = 316;BA.debugLine="Xant1=X11(i) : Yant1=Y11(i)";
_yant1 = _y11[_i];
 //BA.debugLineNum = 317;BA.debugLine="Xant2=X22(i) : Yant2=Y22(i)";
_xant2 = _x22[_i];
 //BA.debugLineNum = 317;BA.debugLine="Xant2=X22(i) : Yant2=Y22(i)";
_yant2 = _y22[_i];
 if (true) break;

case 32:
//C
this.state = 33;
 //BA.debugLineNum = 319;BA.debugLine="cvsDrawing3.DrawLine(Xant1, Yant1, X11(i), Y11(";
parent._cvsdrawing3.DrawLine(_xant1,_yant1,_x11[_i],_y11[_i],parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 320;BA.debugLine="cvsDrawing3.DrawLine(Xant2, Yant2, X22(i), Y22(";
parent._cvsdrawing3.DrawLine(_xant2,_yant2,_x22[_i],_y22[_i],parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 321;BA.debugLine="Xant1=X11(i) : Yant1=Y11(i)";
_xant1 = _x11[_i];
 //BA.debugLineNum = 321;BA.debugLine="Xant1=X11(i) : Yant1=Y11(i)";
_yant1 = _y11[_i];
 //BA.debugLineNum = 322;BA.debugLine="Xant2=X22(i) : Yant2=Y22(i)";
_xant2 = _x22[_i];
 //BA.debugLineNum = 322;BA.debugLine="Xant2=X22(i) : Yant2=Y22(i)";
_yant2 = _y22[_i];
 if (true) break;

case 33:
//C
this.state = 45;
;
 if (true) break;
if (true) break;

case 34:
//C
this.state = -1;
;
 //BA.debugLineNum = 327;BA.debugLine="mesaj=\"\"";
_mesaj = "";
 //BA.debugLineNum = 328;BA.debugLine="mesaj = mesaj & \"Diameter  = \" & Round2(Diametru,";
_mesaj = _mesaj+"Diameter  = "+BA.NumberToString(parent.__c.Round2(_diametru,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 329;BA.debugLine="mesaj = mesaj & \"Radius  = \" & Round2(Raza, 2)  &";
_mesaj = _mesaj+"Radius  = "+BA.NumberToString(parent.__c.Round2(_raza,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 330;BA.debugLine="mesaj = mesaj & \"Gama angle= \" & Round2(GamaPubli";
_mesaj = _mesaj+"Gama angle= "+BA.NumberToString(parent.__c.Round2(parent._gamapublic,(int) (2)))+" [deg]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 331;BA.debugLine="mesaj = mesaj & \"Alfa angle  = \" & Round2(AlfaPub";
_mesaj = _mesaj+"Alfa angle  = "+BA.NumberToString(parent.__c.Round2(parent._alfapublic,(int) (2)))+" [deg]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 332;BA.debugLine="mesaj = mesaj & \"No. of elbow elements  = \" & nec";
_mesaj = _mesaj+"No. of elbow elements  = "+BA.NumberToString(_nec)+" [-]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 333;BA.debugLine="mesaj = mesaj & \"=======================\" & Chr(1";
_mesaj = _mesaj+"======================="+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 334;BA.debugLine="mesaj = mesaj & \"K length = \" & Round2(K, 2)  & \"";
_mesaj = _mesaj+"K length = "+BA.NumberToString(parent.__c.Round2(_k,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 335;BA.debugLine="mesaj = mesaj & \"t length= \" & Round2(t, 2)  & \"";
_mesaj = _mesaj+"t length= "+BA.NumberToString(parent.__c.Round2(_t,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 336;BA.debugLine="mesaj = mesaj & \"Height H1 = \" & Round2(H1, 2)  &";
_mesaj = _mesaj+"Height H1 = "+BA.NumberToString(parent.__c.Round2(_h1,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 337;BA.debugLine="mesaj = mesaj & \"Height H2 = \" & Round2(H2, 2)  &";
_mesaj = _mesaj+"Height H2 = "+BA.NumberToString(parent.__c.Round2(_h2,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 338;BA.debugLine="mesaj = mesaj & \"Unfolded length Ld = \" & Round2(";
_mesaj = _mesaj+"Unfolded length Ld = "+BA.NumberToString(parent.__c.Round2(_ld,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 339;BA.debugLine="mesaj = mesaj & \"Surface area 1 = \" & Round2(Aria";
_mesaj = _mesaj+"Surface area 1 = "+BA.NumberToString(parent.__c.Round2(_aria1,(int) (2)))+" [mm2]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 340;BA.debugLine="mesaj = mesaj & \"Surface area 2 = \" & Round2(Aria";
_mesaj = _mesaj+"Surface area 2 = "+BA.NumberToString(parent.__c.Round2(_aria2,(int) (2)))+" [mm2]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 342;BA.debugLine="Dim s As B4XLongTextTemplate";
_s = new b4a.example.Unfold_Sheets_Parts.b4xlongtexttemplate();
 //BA.debugLineNum = 343;BA.debugLine="s.Initialize  :  s.Text = mesaj";
_s._initialize /*String*/ (ba);
 //BA.debugLineNum = 343;BA.debugLine="s.Initialize  :  s.Text = mesaj";
_s._text /*Object*/  = (Object)(_mesaj);
 //BA.debugLineNum = 344;BA.debugLine="s.CustomListView1.DefaultTextBackgroundColor=xui.";
_s._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextbackgroundcolor = parent._xui.Color_White;
 //BA.debugLineNum = 345;BA.debugLine="s.CustomListView1.DefaultTextColor = xui.Color_Bl";
_s._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextcolor = parent._xui.Color_Black;
 //BA.debugLineNum = 346;BA.debugLine="InputDialog.Title=\"Info results\"";
parent._inputdialog._title /*Object*/  = (Object)("Info results");
 //BA.debugLineNum = 347;BA.debugLine="InputDialog.TitleBarColor=Colors.Blue  :  InputDi";
parent._inputdialog._titlebarcolor /*int*/  = parent.__c.Colors.Blue;
 //BA.debugLineNum = 347;BA.debugLine="InputDialog.TitleBarColor=Colors.Blue  :  InputDi";
parent._inputdialog._buttonscolor /*int*/  = parent.__c.Colors.Blue;
 //BA.debugLineNum = 348;BA.debugLine="InputDialog.BorderWidth = 4  :  InputDialog.Borde";
parent._inputdialog._borderwidth /*int*/  = (int) (4);
 //BA.debugLineNum = 348;BA.debugLine="InputDialog.BorderWidth = 4  :  InputDialog.Borde";
parent._inputdialog._bordercornersradius /*int*/  = parent.__c.DipToCurrent((int) (10));
 //BA.debugLineNum = 349;BA.debugLine="InputDialog.BackgroundColor=Colors.White  :  Inpu";
parent._inputdialog._backgroundcolor /*int*/  = parent.__c.Colors.White;
 //BA.debugLineNum = 349;BA.debugLine="InputDialog.BackgroundColor=Colors.White  :  Inpu";
parent._inputdialog._buttonstextcolor /*int*/  = parent.__c.Colors.White;
 //BA.debugLineNum = 350;BA.debugLine="wait for (InputDialog.ShowTemplate(s,\"OK\",\"\",\"\"))";
parent.__c.WaitFor("complete", ba, this, parent._inputdialog._showtemplate /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((Object)(_s),(Object)("OK"),(Object)(""),(Object)("")));
this.state = 46;
return;
case 46:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 356;BA.debugLine="btnCalculate4.Visible = True";
parent._btncalculate4.setVisible(parent.__c.True);
 //BA.debugLineNum = 357;BA.debugLine="btnTabel.Visible=True";
parent._btntabel.setVisible(parent.__c.True);
 //BA.debugLineNum = 358;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _msgbox_result(int _result) throws Exception{
}
public void  _complete(int _result) throws Exception{
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private Root As B4XView 'ignore";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 3;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 5;BA.debugLine="Public PI=ATan(1)*4 As Float";
_pi = (float) (__c.ATan(1)*4);
 //BA.debugLineNum = 6;BA.debugLine="Public chrt1 As GRAFIC";
_chrt1 = new b4a.example.Unfold_Sheets_Parts.grafic();
 //BA.debugLineNum = 7;BA.debugLine="Public chrt2 As GRAFIC";
_chrt2 = new b4a.example.Unfold_Sheets_Parts.grafic();
 //BA.debugLineNum = 8;BA.debugLine="Public chrt3 As GRAFIC";
_chrt3 = new b4a.example.Unfold_Sheets_Parts.grafic();
 //BA.debugLineNum = 10;BA.debugLine="Private ImageView4 As B4XImageView";
_imageview4 = new b4a.example.Unfold_Sheets_Parts.b4ximageview();
 //BA.debugLineNum = 11;BA.debugLine="Private ImgFolded4 As B4XImageView";
_imgfolded4 = new b4a.example.Unfold_Sheets_Parts.b4ximageview();
 //BA.debugLineNum = 12;BA.debugLine="Private btnCalculate4 As B4XView";
_btncalculate4 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private pnlInputData4 As B4XView";
_pnlinputdata4 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private Panel2a As B4XView";
_panel2a = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private Panel2b As B4XView";
_panel2b = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private lblXY2a As B4XView";
_lblxy2a = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private lblXY2b As B4XView";
_lblxy2b = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Private cmbAlfa As B4XComboBox";
_cmbalfa = new b4a.example.Unfold_Sheets_Parts.b4xcombobox();
 //BA.debugLineNum = 20;BA.debugLine="Private cmbGama As B4XComboBox";
_cmbgama = new b4a.example.Unfold_Sheets_Parts.b4xcombobox();
 //BA.debugLineNum = 22;BA.debugLine="Dim cvsDrawing1 As Canvas";
_cvsdrawing1 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Dim cvsDrawing2 As Canvas";
_cvsdrawing2 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Dim cvsDrawing3 As Canvas";
_cvsdrawing3 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Public GamaPublic, AlfaPublic As Float";
_gamapublic = 0f;
_alfapublic = 0f;
 //BA.debugLineNum = 27;BA.debugLine="Public txtDiameter As B4XView";
_txtdiameter = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 28;BA.debugLine="Public txtRaza As B4XView";
_txtraza = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Public txtNoElem As B4XView";
_txtnoelem = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 31;BA.debugLine="Public X (100), Y1(100), Y2(100) As Float";
_x = new float[(int) (100)];
;
_y1 = new float[(int) (100)];
;
_y2 = new float[(int) (100)];
;
 //BA.debugLineNum = 32;BA.debugLine="Public YH1 (100), YH2a(100), YH2b(100) As Float";
_yh1 = new float[(int) (100)];
;
_yh2a = new float[(int) (100)];
;
_yh2b = new float[(int) (100)];
;
 //BA.debugLineNum = 33;BA.debugLine="Public NrPct = 8 As Int";
_nrpct = (int) (8);
 //BA.debugLineNum = 35;BA.debugLine="Private pnlDemo As B4XView";
_pnldemo = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 37;BA.debugLine="Public InputDialog As B4XDialog";
_inputdialog = new b4a.example.Unfold_Sheets_Parts.b4xdialog();
 //BA.debugLineNum = 39;BA.debugLine="Private pnlTabel As B4XView";
_pnltabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 40;BA.debugLine="Private clvTabel As CustomListView";
_clvtabel = new b4a.example3.customlistview();
 //BA.debugLineNum = 41;BA.debugLine="Private item1 As B4XView";
_item1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 42;BA.debugLine="Private item2 As B4XView";
_item2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 43;BA.debugLine="Private item3 As B4XView";
_item3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 45;BA.debugLine="Private btnTabel As B4XView";
_btntabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 46;BA.debugLine="Private btnExitTabel As B4XView";
_btnexittabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 47;BA.debugLine="End Sub";
return "";
}
public String  _cmbalfa_selectedindexchanged(int _index) throws Exception{
float _alfa = 0f;
float _n = 0f;
float _r = 0f;
 //BA.debugLineNum = 169;BA.debugLine="Private Sub cmbAlfa_SelectedIndexChanged (Index As";
 //BA.debugLineNum = 170;BA.debugLine="Private Alfa=cmbAlfa.SelectedItem As Float";
_alfa = (float)(Double.parseDouble(_cmbalfa._getselecteditem /*String*/ ()));
 //BA.debugLineNum = 171;BA.debugLine="AlfaPublic=Alfa";
_alfapublic = _alfa;
 //BA.debugLineNum = 172;BA.debugLine="Private n, r As Float";
_n = 0f;
_r = 0f;
 //BA.debugLineNum = 173;BA.debugLine="n = (GamaPublic / Alfa + 2) / 2";
_n = (float) ((_gamapublic/(double)_alfa+2)/(double)2);
 //BA.debugLineNum = 174;BA.debugLine="r =  RoundDown(n)";
_r = (float) (_rounddown(_n));
 //BA.debugLineNum = 175;BA.debugLine="If n = r Then";
if (_n==_r) { 
 //BA.debugLineNum = 176;BA.debugLine="txtNoElem.Text = RoundDown(n)";
_txtnoelem.setText(BA.ObjectToCharSequence(_rounddown(_n)));
 };
 //BA.debugLineNum = 178;BA.debugLine="End Sub";
return "";
}
public String  _cmbgama_selectedindexchanged(int _index) throws Exception{
anywheresoftware.b4a.objects.collections.List _lst1 = null;
anywheresoftware.b4a.objects.collections.List _lst2 = null;
float _n = 0f;
float _r = 0f;
float _sg = 0f;
int _i = 0;
 //BA.debugLineNum = 127;BA.debugLine="Private Sub cmbGama_SelectedIndexChanged (Index As";
 //BA.debugLineNum = 129;BA.debugLine="GamaPublic=cmbGama.SelectedItem";
_gamapublic = (float)(Double.parseDouble(_cmbgama._getselecteditem /*String*/ ()));
 //BA.debugLineNum = 131;BA.debugLine="cmbAlfa.mBase.Enabled=True";
_cmbalfa._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setEnabled(__c.True);
 //BA.debugLineNum = 132;BA.debugLine="cmbAlfa.cmbBox.Clear 'clears the listbox";
_cmbalfa._cmbbox /*anywheresoftware.b4a.objects.SpinnerWrapper*/ .Clear();
 //BA.debugLineNum = 134;BA.debugLine="Private lst1, lst2 As List";
_lst1 = new anywheresoftware.b4a.objects.collections.List();
_lst2 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 135;BA.debugLine="Private n, r, SG As Float";
_n = 0f;
_r = 0f;
_sg = 0f;
 //BA.debugLineNum = 136;BA.debugLine="lst1.Initialize  :  lst2.Initialize";
_lst1.Initialize();
 //BA.debugLineNum = 136;BA.debugLine="lst1.Initialize  :  lst2.Initialize";
_lst2.Initialize();
 //BA.debugLineNum = 138;BA.debugLine="lst1.AddAll(Array As String(\"2.5\",\"3\",\"3.5\",\"4\",\"";
_lst1.AddAll(anywheresoftware.b4a.keywords.Common.ArrayToList(new String[]{"2.5","3","3.5","4","5","5.5","6","7.5","8","10","11.25"}));
 //BA.debugLineNum = 139;BA.debugLine="For i = 0 To 11-1";
{
final int step9 = 1;
final int limit9 = (int) (11-1);
_i = (int) (0) ;
for (;_i <= limit9 ;_i = _i + step9 ) {
 //BA.debugLineNum = 140;BA.debugLine="SG = lst1.Get(i)";
_sg = (float)(BA.ObjectToNumber(_lst1.Get(_i)));
 //BA.debugLineNum = 141;BA.debugLine="n = (GamaPublic / SG  + 2) / 2";
_n = (float) ((_gamapublic/(double)_sg+2)/(double)2);
 //BA.debugLineNum = 142;BA.debugLine="r =  RoundDown(n)";
_r = (float) (_rounddown(_n));
 //BA.debugLineNum = 143;BA.debugLine="If n = r  And n >= 2 And n <= 19 Then";
if (_n==_r && _n>=2 && _n<=19) { 
 //BA.debugLineNum = 144;BA.debugLine="lst2.Add(lst1.Get(i))";
_lst2.Add(_lst1.Get(_i));
 };
 }
};
 //BA.debugLineNum = 147;BA.debugLine="cmbAlfa.SetItems(lst2)";
_cmbalfa._setitems /*String*/ (_lst2);
 //BA.debugLineNum = 148;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 50;BA.debugLine="Public Sub Initialize As Object";
 //BA.debugLineNum = 51;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 52;BA.debugLine="End Sub";
return null;
}
public String  _loadimage4() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _b = null;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _c = null;
 //BA.debugLineNum = 93;BA.debugLine="Sub LoadImage4";
 //BA.debugLineNum = 94;BA.debugLine="Dim b = LoadBitmap(File.DirAssets,\"cylindrical el";
_b = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_b = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"cylindrical elbow.jpg").getObject()));
 //BA.debugLineNum = 95;BA.debugLine="ImageView4.SetBitmap(b)  :  ImageView4. ResizeMod";
_imageview4._setbitmap /*String*/ (_b);
 //BA.debugLineNum = 95;BA.debugLine="ImageView4.SetBitmap(b)  :  ImageView4. ResizeMod";
_imageview4._setresizemode /*String*/ ("FILL");
 //BA.debugLineNum = 97;BA.debugLine="Dim c = LoadBitmap(File.DirAssets,\"cylindrical el";
_c = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_c = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"cylindrical elbow unfolded.jpg").getObject()));
 //BA.debugLineNum = 98;BA.debugLine="ImgFolded4.SetBitmap(c)  :  ImgFolded4.ResizeMode";
_imgfolded4._setbitmap /*String*/ (_c);
 //BA.debugLineNum = 98;BA.debugLine="ImgFolded4.SetBitmap(c)  :  ImgFolded4.ResizeMode";
_imgfolded4._setresizemode /*String*/ ("FILL");
 //BA.debugLineNum = 100;BA.debugLine="pnlDemo.Visible = False";
_pnldemo.setVisible(__c.False);
 //BA.debugLineNum = 101;BA.debugLine="ImageView4.mbase.Visible = True";
_imageview4._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.True);
 //BA.debugLineNum = 102;BA.debugLine="End Sub";
return "";
}
public boolean  _panel2a_touch(int _action,float _xmouse,float _ymouse) throws Exception{
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct = null;
 //BA.debugLineNum = 361;BA.debugLine="Sub Panel2a_Touch (Action As Int, XMouse As Float,";
 //BA.debugLineNum = 362;BA.debugLine="Dim pct = chrt1.PixToReal(XMouse, YMouse) As Poin";
_pct = _chrt1._pixtoreal /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_xmouse,_ymouse);
 //BA.debugLineNum = 363;BA.debugLine="lblXY2a.Visible = True";
_lblxy2a.setVisible(__c.True);
 //BA.debugLineNum = 364;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,_panel2a.TOUCH_ACTION_DOWN,_panel2a.TOUCH_ACTION_MOVE,_panel2a.TOUCH_ACTION_UP)) {
case 0: {
 //BA.debugLineNum = 366;BA.debugLine="lblXY2a.Text = Round2(pct.X, 1) & \", \" &  Round";
_lblxy2a.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 367;BA.debugLine="If XMouse <= Panel2a.Width/2 Then";
if (_xmouse<=_panel2a.getWidth()/(double)2) { 
 //BA.debugLineNum = 368;BA.debugLine="lblXY2a.Left = XMouse : lblXY2a.Top = YMouse";
_lblxy2a.setLeft((int) (_xmouse));
 //BA.debugLineNum = 368;BA.debugLine="lblXY2a.Left = XMouse : lblXY2a.Top = YMouse";
_lblxy2a.setTop((int) (_ymouse));
 }else {
 //BA.debugLineNum = 370;BA.debugLine="lblXY2a.Left = XMouse-lblXY2a.Width : lblXY2a.";
_lblxy2a.setLeft((int) (_xmouse-_lblxy2a.getWidth()));
 //BA.debugLineNum = 370;BA.debugLine="lblXY2a.Left = XMouse-lblXY2a.Width : lblXY2a.";
_lblxy2a.setTop((int) (_ymouse));
 };
 break; }
case 1: {
 //BA.debugLineNum = 373;BA.debugLine="lblXY2a.Text = Round2(pct.X, 1) & \", \" &  Round";
_lblxy2a.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 374;BA.debugLine="If XMouse <= Panel2a.Width/2 Then";
if (_xmouse<=_panel2a.getWidth()/(double)2) { 
 //BA.debugLineNum = 375;BA.debugLine="lblXY2a.Left = XMouse : lblXY2a.Top = YMouse";
_lblxy2a.setLeft((int) (_xmouse));
 //BA.debugLineNum = 375;BA.debugLine="lblXY2a.Left = XMouse : lblXY2a.Top = YMouse";
_lblxy2a.setTop((int) (_ymouse));
 }else {
 //BA.debugLineNum = 377;BA.debugLine="lblXY2a.Left = XMouse-lblXY2a.Width : lblXY2a.";
_lblxy2a.setLeft((int) (_xmouse-_lblxy2a.getWidth()));
 //BA.debugLineNum = 377;BA.debugLine="lblXY2a.Left = XMouse-lblXY2a.Width : lblXY2a.";
_lblxy2a.setTop((int) (_ymouse));
 };
 break; }
case 2: {
 //BA.debugLineNum = 380;BA.debugLine="lblXY2a.Text = \"\"  :  lblXY2a.Visible = False";
_lblxy2a.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 380;BA.debugLine="lblXY2a.Text = \"\"  :  lblXY2a.Visible = False";
_lblxy2a.setVisible(__c.False);
 break; }
}
;
 //BA.debugLineNum = 382;BA.debugLine="Return True";
if (true) return __c.True;
 //BA.debugLineNum = 383;BA.debugLine="End Sub";
return false;
}
public boolean  _panel2b_touch(int _action,float _xmouse,float _ymouse) throws Exception{
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct = null;
 //BA.debugLineNum = 385;BA.debugLine="Sub Panel2b_Touch (Action As Int, XMouse As Float,";
 //BA.debugLineNum = 386;BA.debugLine="Dim pct = chrt2.PixToReal(XMouse, YMouse) As Poin";
_pct = _chrt2._pixtoreal /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_xmouse,_ymouse);
 //BA.debugLineNum = 387;BA.debugLine="lblXY2b.Visible = True";
_lblxy2b.setVisible(__c.True);
 //BA.debugLineNum = 388;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,_panel2b.TOUCH_ACTION_DOWN,_panel2b.TOUCH_ACTION_MOVE,_panel2b.TOUCH_ACTION_UP)) {
case 0: {
 //BA.debugLineNum = 390;BA.debugLine="lblXY2b.Text = Round2(pct.X, 1) & \", \" &  Round";
_lblxy2b.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 391;BA.debugLine="If XMouse <= Panel2b.Width/2 Then";
if (_xmouse<=_panel2b.getWidth()/(double)2) { 
 //BA.debugLineNum = 392;BA.debugLine="lblXY2b.Left = XMouse : lblXY2b.Top = YMouse";
_lblxy2b.setLeft((int) (_xmouse));
 //BA.debugLineNum = 392;BA.debugLine="lblXY2b.Left = XMouse : lblXY2b.Top = YMouse";
_lblxy2b.setTop((int) (_ymouse));
 }else {
 //BA.debugLineNum = 394;BA.debugLine="lblXY2b.Left = XMouse-lblXY2b.Width : lblXY2b.";
_lblxy2b.setLeft((int) (_xmouse-_lblxy2b.getWidth()));
 //BA.debugLineNum = 394;BA.debugLine="lblXY2b.Left = XMouse-lblXY2b.Width : lblXY2b.";
_lblxy2b.setTop((int) (_ymouse));
 };
 break; }
case 1: {
 //BA.debugLineNum = 397;BA.debugLine="lblXY2b.Text = Round2(pct.X, 1) & \", \" &  Round";
_lblxy2b.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 398;BA.debugLine="If XMouse <= Panel2b.Width/2 Then";
if (_xmouse<=_panel2b.getWidth()/(double)2) { 
 //BA.debugLineNum = 399;BA.debugLine="lblXY2b.Left = XMouse : lblXY2b.Top = YMouse";
_lblxy2b.setLeft((int) (_xmouse));
 //BA.debugLineNum = 399;BA.debugLine="lblXY2b.Left = XMouse : lblXY2b.Top = YMouse";
_lblxy2b.setTop((int) (_ymouse));
 }else {
 //BA.debugLineNum = 401;BA.debugLine="lblXY2b.Left = XMouse-lblXY2b.Width : lblXY2b.";
_lblxy2b.setLeft((int) (_xmouse-_lblxy2b.getWidth()));
 //BA.debugLineNum = 401;BA.debugLine="lblXY2b.Left = XMouse-lblXY2b.Width : lblXY2b.";
_lblxy2b.setTop((int) (_ymouse));
 };
 break; }
case 2: {
 //BA.debugLineNum = 404;BA.debugLine="lblXY2b.Text = \"\"  :  lblXY2b.Visible = False";
_lblxy2b.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 404;BA.debugLine="lblXY2b.Text = \"\"  :  lblXY2b.Visible = False";
_lblxy2b.setVisible(__c.False);
 break; }
}
;
 //BA.debugLineNum = 406;BA.debugLine="Return True";
if (true) return __c.True;
 //BA.debugLineNum = 407;BA.debugLine="End Sub";
return false;
}
public boolean  _par(int _numar) throws Exception{
boolean _parimp = false;
 //BA.debugLineNum = 160;BA.debugLine="Private Sub Par(Numar As Int) As Boolean     'Mod";
 //BA.debugLineNum = 162;BA.debugLine="Dim ParImp=True As Boolean    'Numar is even (par";
_parimp = __c.True;
 //BA.debugLineNum = 163;BA.debugLine="If Numar Mod 2 <> 0 Then";
if (_numar%2!=0) { 
 //BA.debugLineNum = 164;BA.debugLine="ParImp = False    'Numar is odd (impar)";
_parimp = __c.False;
 };
 //BA.debugLineNum = 166;BA.debugLine="Return ParImp";
if (true) return _parimp;
 //BA.debugLineNum = 167;BA.debugLine="End Sub";
return false;
}
public int  _rounddown(float _numar) throws Exception{
int _rd = 0;
 //BA.debugLineNum = 150;BA.debugLine="Private Sub RoundDown(Numar As Float) As Int 'Alwa";
 //BA.debugLineNum = 151;BA.debugLine="Private RD As Int";
_rd = 0;
 //BA.debugLineNum = 152;BA.debugLine="If Numar > 0 Then";
if (_numar>0) { 
 //BA.debugLineNum = 153;BA.debugLine="RD=Floor(Numar)";
_rd = (int) (__c.Floor(_numar));
 }else {
 //BA.debugLineNum = 155;BA.debugLine="RD=Ceil(Numar)";
_rd = (int) (__c.Ceil(_numar));
 };
 //BA.debugLineNum = 157;BA.debugLine="Return RD";
if (true) return _rd;
 //BA.debugLineNum = 158;BA.debugLine="End Sub";
return 0;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
