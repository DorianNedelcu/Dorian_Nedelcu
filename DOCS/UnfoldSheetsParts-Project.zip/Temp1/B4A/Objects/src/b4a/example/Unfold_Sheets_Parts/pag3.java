package b4a.example.Unfold_Sheets_Parts;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pag3 extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.Unfold_Sheets_Parts.pag3");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.Unfold_Sheets_Parts.pag3.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public float _pi = 0f;
public b4a.example.Unfold_Sheets_Parts.grafic _chrt1 = null;
public b4a.example.Unfold_Sheets_Parts.grafic _chrt2 = null;
public b4a.example.Unfold_Sheets_Parts.b4ximageview _imageview3 = null;
public b4a.example.Unfold_Sheets_Parts.b4ximageview _imgfolded3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btncalculate3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnlinputdata3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panel2a = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panel2b = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblxy2a = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblxy2b = null;
public float[] _x = null;
public float[] _y1 = null;
public float[] _y2 = null;
public int _nrpct = 0;
public anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvsdrawing1 = null;
public anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvsdrawing2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtdiameter = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtheight1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtheight2 = null;
public b4a.example.Unfold_Sheets_Parts.b4xdialog _inputdialog = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnltabel = null;
public b4a.example3.customlistview _clvtabel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _item1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _item2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _item3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btntabel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnexittabel = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.Unfold_Sheets_Parts.main _main = null;
public b4a.example.Unfold_Sheets_Parts.starter _starter = null;
public b4a.example.Unfold_Sheets_Parts.b4xpages _b4xpages = null;
public b4a.example.Unfold_Sheets_Parts.b4xcollections _b4xcollections = null;
public b4a.example.Unfold_Sheets_Parts.xuiviewsutils _xuiviewsutils = null;
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 48;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 49;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 51;BA.debugLine="Root.LoadLayout(\"lay3\")";
_root.LoadLayout("lay3",ba);
 //BA.debugLineNum = 52;BA.debugLine="B4XPages.SetTitle(Me, \"Three cylinders intersecti";
_b4xpages._settitle /*String*/ (ba,this,(Object)("Three cylinders intersection"));
 //BA.debugLineNum = 53;BA.debugLine="InputDialog.Initialize(Root)";
_inputdialog._initialize /*String*/ (ba,_root);
 //BA.debugLineNum = 55;BA.debugLine="pnlTabel.Visible=False";
_pnltabel.setVisible(__c.False);
 //BA.debugLineNum = 56;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 58;BA.debugLine="LoadImage3";
_loadimage3();
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return "";
}
public String  _btncalculate3_click() throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="Private Sub btnCalculate3_Click";
 //BA.debugLineNum = 64;BA.debugLine="pnlInputData3.Visible = True";
_pnlinputdata3.setVisible(__c.True);
 //BA.debugLineNum = 65;BA.debugLine="btnCalculate3.Visible=False";
_btncalculate3.setVisible(__c.False);
 //BA.debugLineNum = 66;BA.debugLine="End Sub";
return "";
}
public String  _btncalculateid_click() throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Private Sub btnCalculateID_Click";
 //BA.debugLineNum = 77;BA.debugLine="pnlInputData3.Visible = False";
_pnlinputdata3.setVisible(__c.False);
 //BA.debugLineNum = 78;BA.debugLine="Panel2a.Visible=True : Panel2b.Visible=True";
_panel2a.setVisible(__c.True);
 //BA.debugLineNum = 78;BA.debugLine="Panel2a.Visible=True : Panel2b.Visible=True";
_panel2b.setVisible(__c.True);
 //BA.debugLineNum = 79;BA.debugLine="ImgFolded3.mBase.Visible = False";
_imgfolded3._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.False);
 //BA.debugLineNum = 80;BA.debugLine="btnCalculate3.Visible=True";
_btncalculate3.setVisible(__c.True);
 //BA.debugLineNum = 81;BA.debugLine="Calcul_Desfasurata";
_calcul_desfasurata();
 //BA.debugLineNum = 82;BA.debugLine="End Sub";
return "";
}
public String  _btncancelid_click() throws Exception{
 //BA.debugLineNum = 84;BA.debugLine="Private Sub btnCancelID_Click";
 //BA.debugLineNum = 85;BA.debugLine="pnlInputData3.Visible = False";
_pnlinputdata3.setVisible(__c.False);
 //BA.debugLineNum = 86;BA.debugLine="Panel2a.Visible=False : Panel2b.Visible=False";
_panel2a.setVisible(__c.False);
 //BA.debugLineNum = 86;BA.debugLine="Panel2a.Visible=False : Panel2b.Visible=False";
_panel2b.setVisible(__c.False);
 //BA.debugLineNum = 87;BA.debugLine="ImgFolded3.mBase.Visible = True";
_imgfolded3._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.True);
 //BA.debugLineNum = 88;BA.debugLine="btnCalculate3.Visible = True";
_btncalculate3.setVisible(__c.True);
 //BA.debugLineNum = 89;BA.debugLine="LoadImage3";
_loadimage3();
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public String  _btnexittabel_click() throws Exception{
 //BA.debugLineNum = 326;BA.debugLine="Private Sub btnExitTabel_Click";
 //BA.debugLineNum = 327;BA.debugLine="pnlTabel.Visible=False";
_pnltabel.setVisible(__c.False);
 //BA.debugLineNum = 328;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 329;BA.debugLine="btnCalculate3.Visible=True";
_btncalculate3.setVisible(__c.True);
 //BA.debugLineNum = 330;BA.debugLine="Panel2a.Visible = True";
_panel2a.setVisible(__c.True);
 //BA.debugLineNum = 331;BA.debugLine="Panel2b.Visible = True";
_panel2b.setVisible(__c.True);
 //BA.debugLineNum = 332;BA.debugLine="End Sub";
return "";
}
public String  _btntabel_click() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
float _pas = 0f;
int _i = 0;
 //BA.debugLineNum = 291;BA.debugLine="Private Sub btnTabel_Click";
 //BA.debugLineNum = 293;BA.debugLine="Dim xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 294;BA.debugLine="clvTabel.Clear";
_clvtabel._clear();
 //BA.debugLineNum = 296;BA.debugLine="Dim p As B4XView  = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 297;BA.debugLine="p.SetLayoutAnimated(0,0,0,100%X, 60dip)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),__c.PerXToCurrent((float) (100),ba),__c.DipToCurrent((int) (60)));
 //BA.debugLineNum = 298;BA.debugLine="p.LoadLayout(\"item\")";
_p.LoadLayout("item",ba);
 //BA.debugLineNum = 300;BA.debugLine="item1.Text = \"Angle/X [mm]\"";
_item1.setText(BA.ObjectToCharSequence("Angle/X [mm]"));
 //BA.debugLineNum = 301;BA.debugLine="item2.Text=\"Y1 [mm]\"";
_item2.setText(BA.ObjectToCharSequence("Y1 [mm]"));
 //BA.debugLineNum = 302;BA.debugLine="item3.Text=\"Y2 [mm]\"";
_item3.setText(BA.ObjectToCharSequence("Y2 [mm]"));
 //BA.debugLineNum = 304;BA.debugLine="clvTabel.Add(p,\"\")";
_clvtabel._add(_p,(Object)(""));
 //BA.debugLineNum = 305;BA.debugLine="Dim pas=360/(4 * NrPct) As Float";
_pas = (float) (360/(double)(4*_nrpct));
 //BA.debugLineNum = 306;BA.debugLine="For i = 1 To 4 * NrPct + 1";
{
final int step11 = 1;
final int limit11 = (int) (4*_nrpct+1);
_i = (int) (1) ;
for (;_i <= limit11 ;_i = _i + step11 ) {
 //BA.debugLineNum = 307;BA.debugLine="Dim p As B4XView  = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 308;BA.debugLine="p.SetLayoutAnimated(100,0,0,100%X, 60dip)";
_p.SetLayoutAnimated((int) (100),(int) (0),(int) (0),__c.PerXToCurrent((float) (100),ba),__c.DipToCurrent((int) (60)));
 //BA.debugLineNum = 309;BA.debugLine="p.LoadLayout(\"item\")";
_p.LoadLayout("item",ba);
 //BA.debugLineNum = 312;BA.debugLine="item1.Text = ((i-1) * pas) & \" / \" & Round2(X(i)";
_item1.setText(BA.ObjectToCharSequence(BA.NumberToString(((_i-1)*_pas))+" / "+BA.NumberToString(__c.Round2(_x[_i],(int) (2)))));
 //BA.debugLineNum = 313;BA.debugLine="item2.Text=Round2(Y1(i), 2)";
_item2.setText(BA.ObjectToCharSequence(__c.Round2(_y1[_i],(int) (2))));
 //BA.debugLineNum = 314;BA.debugLine="item3.Text=Round2(Y2(i), 2)";
_item3.setText(BA.ObjectToCharSequence(__c.Round2(_y2[_i],(int) (2))));
 //BA.debugLineNum = 316;BA.debugLine="clvTabel.Add(p,\"\")";
_clvtabel._add(_p,(Object)(""));
 }
};
 //BA.debugLineNum = 318;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 319;BA.debugLine="btnCalculate3.Visible=False";
_btncalculate3.setVisible(__c.False);
 //BA.debugLineNum = 320;BA.debugLine="pnlTabel.Visible=True";
_pnltabel.setVisible(__c.True);
 //BA.debugLineNum = 321;BA.debugLine="btnExitTabel.Visible=True";
_btnexittabel.setVisible(__c.True);
 //BA.debugLineNum = 322;BA.debugLine="Panel2a.Visible = False";
_panel2a.setVisible(__c.False);
 //BA.debugLineNum = 323;BA.debugLine="Panel2b.Visible = False";
_panel2b.setVisible(__c.False);
 //BA.debugLineNum = 324;BA.debugLine="End Sub";
return "";
}
public void  _calcul_desfasurata() throws Exception{
ResumableSub_Calcul_Desfasurata rsub = new ResumableSub_Calcul_Desfasurata(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Calcul_Desfasurata extends BA.ResumableSub {
public ResumableSub_Calcul_Desfasurata(b4a.example.Unfold_Sheets_Parts.pag3 parent) {
this.parent = parent;
}
b4a.example.Unfold_Sheets_Parts.pag3 parent;
float _diametru = 0f;
float _h1 = 0f;
float _h2 = 0f;
float _ld = 0f;
float _aria1 = 0f;
float _aria2 = 0f;
float _alfa1 = 0f;
float _beta1 = 0f;
float _alfa2 = 0f;
float _beta2 = 0f;
float _umax1 = 0f;
float _umax2 = 0f;
String _sir = "";
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _icon = null;
Object _msj = null;
int _result = 0;
float _h11 = 0f;
float _h12 = 0f;
float _h21 = 0f;
float _h22 = 0f;
float _minim = 0f;
float _teta = 0f;
int _i = 0;
float _lg = 0f;
float _xgmin1 = 0f;
float _xgmax1 = 0f;
float _ygmin1 = 0f;
float _ygmax1 = 0f;
float _xgmin2 = 0f;
float _xgmax2 = 0f;
float _ygmin2 = 0f;
float _ygmax2 = 0f;
anywheresoftware.b4a.objects.collections.List _listxy2a = null;
anywheresoftware.b4a.objects.collections.List _listxy2b = null;
anywheresoftware.b4a.objects.collections.List _lstxy2a = null;
anywheresoftware.b4a.objects.collections.List _lstxy2b = null;
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct1 = null;
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct2 = null;
String _mesaj = "";
b4a.example.Unfold_Sheets_Parts.b4xlongtexttemplate _s = null;
int step40;
int limit40;
int step68;
int limit68;
int step102;
int limit102;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 93;BA.debugLine="Dim Diametru, H1, H2 As Float";
_diametru = 0f;
_h1 = 0f;
_h2 = 0f;
 //BA.debugLineNum = 94;BA.debugLine="Dim NrPct = 8 As Int";
parent._nrpct = (int) (8);
 //BA.debugLineNum = 95;BA.debugLine="Private Ld, Aria1, Aria2, Alfa1, Beta1, Alfa2, Be";
_ld = 0f;
_aria1 = 0f;
_aria2 = 0f;
_alfa1 = 0f;
_beta1 = 0f;
_alfa2 = 0f;
_beta2 = 0f;
_umax1 = 0f;
_umax2 = 0f;
 //BA.debugLineNum = 96;BA.debugLine="Dim sir As String";
_sir = "";
 //BA.debugLineNum = 99;BA.debugLine="Diametru = txtDiameter.Text";
_diametru = (float)(Double.parseDouble(parent._txtdiameter.getText()));
 //BA.debugLineNum = 100;BA.debugLine="H1 = txtHeight1.Text";
_h1 = (float)(Double.parseDouble(parent._txtheight1.getText()));
 //BA.debugLineNum = 101;BA.debugLine="H2 = txtHeight2.Text";
_h2 = (float)(Double.parseDouble(parent._txtheight2.getText()));
 //BA.debugLineNum = 103;BA.debugLine="Ld = PI * Diametru' Lungime desfasurata";
_ld = (float) (parent._pi*_diametru);
 //BA.debugLineNum = 105;BA.debugLine="Alfa1 = 22.5 * PI / 180 ' Unghi \"Alfa\" element 1";
_alfa1 = (float) (22.5*parent._pi/(double)180);
 //BA.debugLineNum = 106;BA.debugLine="Beta1 = 45 * PI / 180 ' Unghi \"Beta\" element 1";
_beta1 = (float) (45*parent._pi/(double)180);
 //BA.debugLineNum = 107;BA.debugLine="Alfa2 = 22.5 * PI / 180 ' Unghi \"Alfa\" element 2";
_alfa2 = (float) (22.5*parent._pi/(double)180);
 //BA.debugLineNum = 108;BA.debugLine="Beta2 = 22.5 * PI / 180 ' Unghi \"Beta\" element 2";
_beta2 = (float) (22.5*parent._pi/(double)180);
 //BA.debugLineNum = 111;BA.debugLine="Umax1 = ATan(2 * H1 / Diametru)";
_umax1 = (float) (parent.__c.ATan(2*_h1/(double)_diametru));
 //BA.debugLineNum = 112;BA.debugLine="Umax2 = ATan(2 * H2 / Diametru)";
_umax2 = (float) (parent.__c.ATan(2*_h2/(double)_diametru));
 //BA.debugLineNum = 113;BA.debugLine="If Alfa1 > Umax1 Or Beta1 > Umax1 Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_alfa1>_umax1 || _beta1>_umax1) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 114;BA.debugLine="sir = \"For element no.  1 or 3 the angles 'Alpha";
_sir = "For element no.  1 or 3 the angles 'Alpha', 'Beta' must be smaller than ";
 //BA.debugLineNum = 115;BA.debugLine="sir = sir & Chr(10) & Umax1 & \" [deg]\"";
_sir = _sir+BA.ObjectToString(parent.__c.Chr((int) (10)))+BA.NumberToString(_umax1)+" [deg]";
 if (true) break;
;
 //BA.debugLineNum = 117;BA.debugLine="If Alfa2 > Umax2 Or Beta2 > Umax2 Then";

case 4:
//if
this.state = 7;
if (_alfa2>_umax2 || _beta2>_umax2) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 118;BA.debugLine="sir = \"For element no. 2 the angles 'Alpha', 'Be";
_sir = "For element no. 2 the angles 'Alpha', 'Beta' must be smaller than ";
 //BA.debugLineNum = 119;BA.debugLine="sir = sir & Chr(10) & Umax2 & \" [deg]\"";
_sir = _sir+BA.ObjectToString(parent.__c.Chr((int) (10)))+BA.NumberToString(_umax2)+" [deg]";
 if (true) break;
;
 //BA.debugLineNum = 122;BA.debugLine="If sir<>\"\" Then";

case 7:
//if
this.state = 10;
if ((_sir).equals("") == false) { 
this.state = 9;
}if (true) break;

case 9:
//C
this.state = 10;
 //BA.debugLineNum = 123;BA.debugLine="Dim icon As B4XBitmap = xui.LoadBitmap(File.DirA";
_icon = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_icon = parent._xui.LoadBitmap(parent.__c.File.getDirAssets(),"info.png");
 //BA.debugLineNum = 124;BA.debugLine="Dim msj As Object =xui.Msgbox2Async(sir, \"Wrong";
_msj = parent._xui.Msgbox2Async(ba,BA.ObjectToCharSequence(_sir),BA.ObjectToCharSequence("Wrong input data"),"OK","","",(anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.drawable.CanvasWrapper.BitmapWrapper(), (android.graphics.Bitmap)(_icon.getObject())));
 //BA.debugLineNum = 125;BA.debugLine="Wait For (msj) Msgbox_Result (Result As Int)";
parent.__c.WaitFor("msgbox_result", ba, this, _msj);
this.state = 47;
return;
case 47:
//C
this.state = 10;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 126;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 10:
//C
this.state = 11;
;
 //BA.debugLineNum = 130;BA.debugLine="Dim H11, H12, H21, H22, Minim, Teta As Float";
_h11 = 0f;
_h12 = 0f;
_h21 = 0f;
_h22 = 0f;
_minim = 0f;
_teta = 0f;
 //BA.debugLineNum = 131;BA.debugLine="H11 = H1 - Diametru * Tan(Alfa1) / 2";
_h11 = (float) (_h1-_diametru*parent.__c.Tan(_alfa1)/(double)2);
 //BA.debugLineNum = 132;BA.debugLine="H12 = H1 - Diametru * Tan(Beta1) / 2";
_h12 = (float) (_h1-_diametru*parent.__c.Tan(_beta1)/(double)2);
 //BA.debugLineNum = 133;BA.debugLine="H21 = H2 - Diametru * Tan(Alfa2) / 2";
_h21 = (float) (_h2-_diametru*parent.__c.Tan(_alfa2)/(double)2);
 //BA.debugLineNum = 134;BA.debugLine="H22 = H2 - Diametru * Tan(Beta2) / 2";
_h22 = (float) (_h2-_diametru*parent.__c.Tan(_beta2)/(double)2);
 //BA.debugLineNum = 135;BA.debugLine="Minim = H11";
_minim = _h11;
 //BA.debugLineNum = 136;BA.debugLine="If H12 < Minim Then Minim = H12";
if (true) break;

case 11:
//if
this.state = 16;
if (_h12<_minim) { 
this.state = 13;
;}if (true) break;

case 13:
//C
this.state = 16;
_minim = _h12;
if (true) break;

case 16:
//C
this.state = 17;
;
 //BA.debugLineNum = 137;BA.debugLine="If H21 < Minim Then Minim = H21";
if (true) break;

case 17:
//if
this.state = 22;
if (_h21<_minim) { 
this.state = 19;
;}if (true) break;

case 19:
//C
this.state = 22;
_minim = _h21;
if (true) break;

case 22:
//C
this.state = 23;
;
 //BA.debugLineNum = 138;BA.debugLine="If H22 < Minim Then Minim = H22";
if (true) break;

case 23:
//if
this.state = 28;
if (_h22<_minim) { 
this.state = 25;
;}if (true) break;

case 25:
//C
this.state = 28;
_minim = _h22;
if (true) break;

case 28:
//C
this.state = 29;
;
 //BA.debugLineNum = 139;BA.debugLine="Aria1 = Diametru * (H1 * PI - Diametru * (Tan(Alf";
_aria1 = (float) (_diametru*(_h1*parent._pi-_diametru*(parent.__c.Tan(_alfa1)+parent.__c.Tan(_beta1))/(double)2));
 //BA.debugLineNum = 140;BA.debugLine="Aria2 = Diametru * (H2 * PI - Diametru * (Tan(Alf";
_aria2 = (float) (_diametru*(_h2*parent._pi-_diametru*(parent.__c.Tan(_alfa2)+parent.__c.Tan(_beta2))/(double)2));
 //BA.debugLineNum = 141;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 29:
//for
this.state = 38;
step40 = 1;
limit40 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 48;
if (true) break;

case 48:
//C
this.state = 38;
if ((step40 > 0 && _i <= limit40) || (step40 < 0 && _i >= limit40)) this.state = 31;
if (true) break;

case 49:
//C
this.state = 48;
_i = ((int)(0 + _i + step40)) ;
if (true) break;

case 31:
//C
this.state = 32;
 //BA.debugLineNum = 142;BA.debugLine="Teta = (i - 1) * PI / 2 / NrPct";
_teta = (float) ((_i-1)*parent._pi/(double)2/(double)parent._nrpct);
 //BA.debugLineNum = 143;BA.debugLine="X(i) = Teta * Diametru / 2";
parent._x[_i] = (float) (_teta*_diametru/(double)2);
 //BA.debugLineNum = 144;BA.debugLine="If Teta < PI / 2 Or Teta > 3 * PI / 2 Then";
if (true) break;

case 32:
//if
this.state = 37;
if (_teta<parent._pi/(double)2 || _teta>3*parent._pi/(double)2) { 
this.state = 34;
}else {
this.state = 36;
}if (true) break;

case 34:
//C
this.state = 37;
 //BA.debugLineNum = 145;BA.debugLine="Y1(i) = H1 - Diametru / 2 * Cos(Teta) * Tan(Alf";
parent._y1[_i] = (float) (_h1-_diametru/(double)2*parent.__c.Cos(_teta)*parent.__c.Tan(_alfa1));
 //BA.debugLineNum = 146;BA.debugLine="Y2(i) = H2 - Diametru / 2 * Cos(Teta) * Tan(Alf";
parent._y2[_i] = (float) (_h2-_diametru/(double)2*parent.__c.Cos(_teta)*parent.__c.Tan(_alfa2));
 if (true) break;

case 36:
//C
this.state = 37;
 //BA.debugLineNum = 148;BA.debugLine="Y1(i) = H1 + Diametru / 2 * Cos(Teta) * Tan(Bet";
parent._y1[_i] = (float) (_h1+_diametru/(double)2*parent.__c.Cos(_teta)*parent.__c.Tan(_beta1));
 //BA.debugLineNum = 149;BA.debugLine="Y2(i) = H2 + Diametru / 2 * Cos(Teta) * Tan(Bet";
parent._y2[_i] = (float) (_h2+_diametru/(double)2*parent.__c.Cos(_teta)*parent.__c.Tan(_beta2));
 if (true) break;

case 37:
//C
this.state = 49;
;
 if (true) break;
if (true) break;

case 38:
//C
this.state = 39;
;
 //BA.debugLineNum = 153;BA.debugLine="Dim LG = 0.03 * PI * Diametru As Float";
_lg = (float) (0.03*parent._pi*_diametru);
 //BA.debugLineNum = 154;BA.debugLine="Private XGmin1, XGmax1, YGmin1, YGmax1 As Float";
_xgmin1 = 0f;
_xgmax1 = 0f;
_ygmin1 = 0f;
_ygmax1 = 0f;
 //BA.debugLineNum = 155;BA.debugLine="Private XGmin2, XGmax2, YGmin2, YGmax2 As Float";
_xgmin2 = 0f;
_xgmax2 = 0f;
_ygmin2 = 0f;
_ygmax2 = 0f;
 //BA.debugLineNum = 156;BA.debugLine="XGmin1=-LG : XGmax1 = Ld+LG : YGmin1=-LG : YGmax1";
_xgmin1 = (float) (-_lg);
 //BA.debugLineNum = 156;BA.debugLine="XGmin1=-LG : XGmax1 = Ld+LG : YGmin1=-LG : YGmax1";
_xgmax1 = (float) (_ld+_lg);
 //BA.debugLineNum = 156;BA.debugLine="XGmin1=-LG : XGmax1 = Ld+LG : YGmin1=-LG : YGmax1";
_ygmin1 = (float) (-_lg);
 //BA.debugLineNum = 156;BA.debugLine="XGmin1=-LG : XGmax1 = Ld+LG : YGmin1=-LG : YGmax1";
_ygmax1 = (float) (_h1+_lg);
 //BA.debugLineNum = 157;BA.debugLine="XGmin2=-LG : XGmax2 = Ld+LG : YGmin2=-LG : YGmax2";
_xgmin2 = (float) (-_lg);
 //BA.debugLineNum = 157;BA.debugLine="XGmin2=-LG : XGmax2 = Ld+LG : YGmin2=-LG : YGmax2";
_xgmax2 = (float) (_ld+_lg);
 //BA.debugLineNum = 157;BA.debugLine="XGmin2=-LG : XGmax2 = Ld+LG : YGmin2=-LG : YGmax2";
_ygmin2 = (float) (-_lg);
 //BA.debugLineNum = 157;BA.debugLine="XGmin2=-LG : XGmax2 = Ld+LG : YGmin2=-LG : YGmax2";
_ygmax2 = (float) (_h2+_lg);
 //BA.debugLineNum = 159;BA.debugLine="chrt1.Initialize(Panel2a, cvsDrawing1, XGmin1, YG";
parent._chrt1._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(parent._panel2a.getObject())),parent._cvsdrawing1,_xgmin1,_ygmin1,_xgmax1,_ygmax1);
 //BA.debugLineNum = 160;BA.debugLine="chrt2.Initialize(Panel2b, cvsDrawing2, XGmin2, YG";
parent._chrt2._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(parent._panel2b.getObject())),parent._cvsdrawing2,_xgmin2,_ygmin2,_xgmax2,_ygmax2);
 //BA.debugLineNum = 162;BA.debugLine="Dim ListXY2a, ListXY2b As List";
_listxy2a = new anywheresoftware.b4a.objects.collections.List();
_listxy2b = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 163;BA.debugLine="Dim lstXY2a, lstXY2b As List";
_lstxy2a = new anywheresoftware.b4a.objects.collections.List();
_lstxy2b = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 164;BA.debugLine="ListXY2a.Initialize : ListXY2b.Initialize";
_listxy2a.Initialize();
 //BA.debugLineNum = 164;BA.debugLine="ListXY2a.Initialize : ListXY2b.Initialize";
_listxy2b.Initialize();
 //BA.debugLineNum = 167;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 39:
//for
this.state = 42;
step68 = 1;
limit68 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 50;
if (true) break;

case 50:
//C
this.state = 42;
if ((step68 > 0 && _i <= limit68) || (step68 < 0 && _i >= limit68)) this.state = 41;
if (true) break;

case 51:
//C
this.state = 50;
_i = ((int)(0 + _i + step68)) ;
if (true) break;

case 41:
//C
this.state = 51;
 //BA.debugLineNum = 168;BA.debugLine="lstXY2a.Initialize : lstXY2a.Add(X(i)) : lstXY2a";
_lstxy2a.Initialize();
 //BA.debugLineNum = 168;BA.debugLine="lstXY2a.Initialize : lstXY2a.Add(X(i)) : lstXY2a";
_lstxy2a.Add((Object)(parent._x[_i]));
 //BA.debugLineNum = 168;BA.debugLine="lstXY2a.Initialize : lstXY2a.Add(X(i)) : lstXY2a";
_lstxy2a.Add((Object)(parent._y1[_i]));
 //BA.debugLineNum = 169;BA.debugLine="ListXY2a.Add(lstXY2a)";
_listxy2a.Add((Object)(_lstxy2a.getObject()));
 //BA.debugLineNum = 171;BA.debugLine="lstXY2b.Initialize : lstXY2b.Add(X(i)) : lstXY2b";
_lstxy2b.Initialize();
 //BA.debugLineNum = 171;BA.debugLine="lstXY2b.Initialize : lstXY2b.Add(X(i)) : lstXY2b";
_lstxy2b.Add((Object)(parent._x[_i]));
 //BA.debugLineNum = 171;BA.debugLine="lstXY2b.Initialize : lstXY2b.Add(X(i)) : lstXY2b";
_lstxy2b.Add((Object)(parent._y2[_i]));
 //BA.debugLineNum = 172;BA.debugLine="ListXY2b.Add(lstXY2b)";
_listxy2b.Add((Object)(_lstxy2b.getObject()));
 if (true) break;
if (true) break;

case 42:
//C
this.state = 43;
;
 //BA.debugLineNum = 175;BA.debugLine="chrt1.DrawCurve(ListXY2a, Colors.Blue, 3dip, Fals";
parent._chrt1._drawcurve /*String*/ (_listxy2a,(long) (parent.__c.Colors.Blue),parent.__c.DipToCurrent((int) (3)),parent.__c.False,parent.__c.True,(int) (0),(int) (0));
 //BA.debugLineNum = 176;BA.debugLine="chrt2.DrawCurve(ListXY2b, Colors.Blue, 3dip, Fals";
parent._chrt2._drawcurve /*String*/ (_listxy2b,(long) (parent.__c.Colors.Blue),parent.__c.DipToCurrent((int) (3)),parent.__c.False,parent.__c.True,(int) (0),(int) (0));
 //BA.debugLineNum = 177;BA.debugLine="cvsDrawing1.DrawCircle(chrt1.RealToPix(0, 0).X, c";
parent._cvsdrawing1.DrawCircle(parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).X /*float*/ ,parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).Y /*float*/ ,(float) (parent.__c.DipToCurrent((int) (5))),parent.__c.Colors.Red,parent.__c.True,(float) (0));
 //BA.debugLineNum = 178;BA.debugLine="cvsDrawing2.DrawCircle(chrt2.RealToPix(0, 0).X, c";
parent._cvsdrawing2.DrawCircle(parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).X /*float*/ ,parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).Y /*float*/ ,(float) (parent.__c.DipToCurrent((int) (5))),parent.__c.Colors.Red,parent.__c.True,(float) (0));
 //BA.debugLineNum = 181;BA.debugLine="Dim pct1, Pct2 As Point";
_pct1 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
_pct2 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
 //BA.debugLineNum = 182;BA.debugLine="pct1 = chrt1.RealToPix(0, 0)  :  Pct2 = chrt1.Rea";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0));
 //BA.debugLineNum = 182;BA.debugLine="pct1 = chrt1.RealToPix(0, 0)  :  Pct2 = chrt1.Rea";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),_h11);
 //BA.debugLineNum = 183;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 185;BA.debugLine="pct1 = chrt1.RealToPix(0, 0)  :  Pct2 = chrt1.Rea";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0));
 //BA.debugLineNum = 185;BA.debugLine="pct1 = chrt1.RealToPix(0, 0)  :  Pct2 = chrt1.Rea";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,(float) (0));
 //BA.debugLineNum = 186;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 188;BA.debugLine="pct1 = chrt1.RealToPix(Ld , 0)  :  Pct2 = chrt1.R";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,(float) (0));
 //BA.debugLineNum = 188;BA.debugLine="pct1 = chrt1.RealToPix(Ld , 0)  :  Pct2 = chrt1.R";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,_h11);
 //BA.debugLineNum = 189;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 192;BA.debugLine="Dim pct1, Pct2 As Point";
_pct1 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
_pct2 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
 //BA.debugLineNum = 193;BA.debugLine="pct1 = chrt2.RealToPix(0, 0)  :  Pct2 = chrt2.Rea";
_pct1 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0));
 //BA.debugLineNum = 193;BA.debugLine="pct1 = chrt2.RealToPix(0, 0)  :  Pct2 = chrt2.Rea";
_pct2 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),_h21);
 //BA.debugLineNum = 194;BA.debugLine="cvsDrawing2.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing2.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 196;BA.debugLine="pct1 = chrt2.RealToPix(0, 0)  :  Pct2 = chrt2.Rea";
_pct1 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0));
 //BA.debugLineNum = 196;BA.debugLine="pct1 = chrt2.RealToPix(0, 0)  :  Pct2 = chrt2.Rea";
_pct2 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,(float) (0));
 //BA.debugLineNum = 197;BA.debugLine="cvsDrawing2.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing2.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 199;BA.debugLine="pct1 = chrt2.RealToPix(Ld , 0)  :  Pct2 = chrt2.R";
_pct1 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,(float) (0));
 //BA.debugLineNum = 199;BA.debugLine="pct1 = chrt2.RealToPix(Ld , 0)  :  Pct2 = chrt2.R";
_pct2 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,_h21);
 //BA.debugLineNum = 200;BA.debugLine="cvsDrawing2.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing2.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 203;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 43:
//for
this.state = 46;
step102 = 1;
limit102 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 52;
if (true) break;

case 52:
//C
this.state = 46;
if ((step102 > 0 && _i <= limit102) || (step102 < 0 && _i >= limit102)) this.state = 45;
if (true) break;

case 53:
//C
this.state = 52;
_i = ((int)(0 + _i + step102)) ;
if (true) break;

case 45:
//C
this.state = 53;
 //BA.debugLineNum = 204;BA.debugLine="pct1 = chrt1.RealToPix(X(i), 0)  :  Pct2 = chrt1";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],(float) (0));
 //BA.debugLineNum = 204;BA.debugLine="pct1 = chrt1.RealToPix(X(i), 0)  :  Pct2 = chrt1";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],parent._y1[_i]);
 //BA.debugLineNum = 205;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Black,(float) (parent.__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 207;BA.debugLine="pct1 = chrt2.RealToPix(X(i), 0)  :  Pct2 = chrt2";
_pct1 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],(float) (0));
 //BA.debugLineNum = 207;BA.debugLine="pct1 = chrt2.RealToPix(X(i), 0)  :  Pct2 = chrt2";
_pct2 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],parent._y2[_i]);
 //BA.debugLineNum = 208;BA.debugLine="cvsDrawing2.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct";
parent._cvsdrawing2.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Black,(float) (parent.__c.DipToCurrent((int) (1))));
 if (true) break;
if (true) break;

case 46:
//C
this.state = -1;
;
 //BA.debugLineNum = 212;BA.debugLine="Dim mesaj=\"\" As String";
_mesaj = "";
 //BA.debugLineNum = 213;BA.debugLine="mesaj = mesaj & \"Diameter  = \" & Round2(Diametru,";
_mesaj = _mesaj+"Diameter  = "+BA.NumberToString(parent.__c.Round2(_diametru,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 214;BA.debugLine="mesaj = mesaj & \"Height H1 = \" & Round2(H1, 2)  &";
_mesaj = _mesaj+"Height H1 = "+BA.NumberToString(parent.__c.Round2(_h1,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 215;BA.debugLine="mesaj = mesaj & \"Height H2 = \" & Round2(H2, 2)  &";
_mesaj = _mesaj+"Height H2 = "+BA.NumberToString(parent.__c.Round2(_h2,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 216;BA.debugLine="mesaj = mesaj & \"=======================\" & Chr(1";
_mesaj = _mesaj+"======================="+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 217;BA.debugLine="mesaj = mesaj & \"Height H11 = \" & Round2(H11, 2)";
_mesaj = _mesaj+"Height H11 = "+BA.NumberToString(parent.__c.Round2(_h11,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 218;BA.debugLine="mesaj = mesaj & \"Height H12 = \" & Round2(H12, 2)";
_mesaj = _mesaj+"Height H12 = "+BA.NumberToString(parent.__c.Round2(_h12,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 219;BA.debugLine="mesaj = mesaj & \"Height H21 = \" & Round2(H21, 2)";
_mesaj = _mesaj+"Height H21 = "+BA.NumberToString(parent.__c.Round2(_h21,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 220;BA.debugLine="mesaj = mesaj & \"Height H22 = \" & Round2(H22, 2)";
_mesaj = _mesaj+"Height H22 = "+BA.NumberToString(parent.__c.Round2(_h22,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 221;BA.debugLine="mesaj = mesaj & \"Unfolded length Ld = \" & Round2(";
_mesaj = _mesaj+"Unfolded length Ld = "+BA.NumberToString(parent.__c.Round2(_ld,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 222;BA.debugLine="mesaj = mesaj & \"Surface area 1 = \" & Round2(Aria";
_mesaj = _mesaj+"Surface area 1 = "+BA.NumberToString(parent.__c.Round2(_aria1,(int) (2)))+" [mm2]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 223;BA.debugLine="mesaj = mesaj & \"Surface area 2 = \" & Round2(Aria";
_mesaj = _mesaj+"Surface area 2 = "+BA.NumberToString(parent.__c.Round2(_aria2,(int) (2)))+" [mm2]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 225;BA.debugLine="Dim s As B4XLongTextTemplate";
_s = new b4a.example.Unfold_Sheets_Parts.b4xlongtexttemplate();
 //BA.debugLineNum = 226;BA.debugLine="s.Initialize  :  s.Text = mesaj";
_s._initialize /*String*/ (ba);
 //BA.debugLineNum = 226;BA.debugLine="s.Initialize  :  s.Text = mesaj";
_s._text /*Object*/  = (Object)(_mesaj);
 //BA.debugLineNum = 227;BA.debugLine="s.CustomListView1.DefaultTextBackgroundColor=xui.";
_s._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextbackgroundcolor = parent._xui.Color_White;
 //BA.debugLineNum = 228;BA.debugLine="s.CustomListView1.DefaultTextColor = xui.Color_Bl";
_s._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextcolor = parent._xui.Color_Black;
 //BA.debugLineNum = 229;BA.debugLine="InputDialog.Title=\"Info results\"";
parent._inputdialog._title /*Object*/  = (Object)("Info results");
 //BA.debugLineNum = 230;BA.debugLine="InputDialog.TitleBarColor=Colors.Blue  :  InputDi";
parent._inputdialog._titlebarcolor /*int*/  = parent.__c.Colors.Blue;
 //BA.debugLineNum = 230;BA.debugLine="InputDialog.TitleBarColor=Colors.Blue  :  InputDi";
parent._inputdialog._buttonscolor /*int*/  = parent.__c.Colors.Blue;
 //BA.debugLineNum = 231;BA.debugLine="InputDialog.BorderWidth = 4  :  InputDialog.Borde";
parent._inputdialog._borderwidth /*int*/  = (int) (4);
 //BA.debugLineNum = 231;BA.debugLine="InputDialog.BorderWidth = 4  :  InputDialog.Borde";
parent._inputdialog._bordercornersradius /*int*/  = parent.__c.DipToCurrent((int) (10));
 //BA.debugLineNum = 232;BA.debugLine="InputDialog.BackgroundColor=Colors.White  :  Inpu";
parent._inputdialog._backgroundcolor /*int*/  = parent.__c.Colors.White;
 //BA.debugLineNum = 232;BA.debugLine="InputDialog.BackgroundColor=Colors.White  :  Inpu";
parent._inputdialog._buttonstextcolor /*int*/  = parent.__c.Colors.White;
 //BA.debugLineNum = 233;BA.debugLine="wait for (InputDialog.ShowTemplate(s,\"OK\",\"\",\"\"))";
parent.__c.WaitFor("complete", ba, this, parent._inputdialog._showtemplate /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((Object)(_s),(Object)("OK"),(Object)(""),(Object)("")));
this.state = 54;
return;
case 54:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 239;BA.debugLine="btnTabel.Visible=True";
parent._btntabel.setVisible(parent.__c.True);
 //BA.debugLineNum = 241;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _msgbox_result(int _result) throws Exception{
}
public void  _complete(int _result) throws Exception{
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private Root As B4XView 'ignore";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 3;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 5;BA.debugLine="Public PI=ATan(1)*4 As Float";
_pi = (float) (__c.ATan(1)*4);
 //BA.debugLineNum = 6;BA.debugLine="Public chrt1 As GRAFIC";
_chrt1 = new b4a.example.Unfold_Sheets_Parts.grafic();
 //BA.debugLineNum = 7;BA.debugLine="Public chrt2 As GRAFIC";
_chrt2 = new b4a.example.Unfold_Sheets_Parts.grafic();
 //BA.debugLineNum = 9;BA.debugLine="Private ImageView3 As B4XImageView";
_imageview3 = new b4a.example.Unfold_Sheets_Parts.b4ximageview();
 //BA.debugLineNum = 10;BA.debugLine="Private ImgFolded3 As B4XImageView";
_imgfolded3 = new b4a.example.Unfold_Sheets_Parts.b4ximageview();
 //BA.debugLineNum = 11;BA.debugLine="Private btnCalculate3 As B4XView";
_btncalculate3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private pnlInputData3 As B4XView";
_pnlinputdata3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Private Panel2a As B4XView";
_panel2a = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private Panel2b As B4XView";
_panel2b = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 16;BA.debugLine="Private lblXY2a As B4XView";
_lblxy2a = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Private lblXY2b As B4XView";
_lblxy2b = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Dim X (100), Y1(100), Y2(100) As Float";
_x = new float[(int) (100)];
;
_y1 = new float[(int) (100)];
;
_y2 = new float[(int) (100)];
;
 //BA.debugLineNum = 20;BA.debugLine="Public NrPct = 8 As Int";
_nrpct = (int) (8);
 //BA.debugLineNum = 22;BA.debugLine="Dim cvsDrawing1 As Canvas";
_cvsdrawing1 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 23;BA.debugLine="Dim cvsDrawing2 As Canvas";
_cvsdrawing2 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 25;BA.debugLine="Private txtDiameter As B4XView";
_txtdiameter = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Private txtHeight1 As B4XView";
_txtheight1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 27;BA.debugLine="Private txtHeight2 As B4XView";
_txtheight2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 29;BA.debugLine="Public InputDialog As B4XDialog";
_inputdialog = new b4a.example.Unfold_Sheets_Parts.b4xdialog();
 //BA.debugLineNum = 31;BA.debugLine="Private pnlTabel As B4XView";
_pnltabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private clvTabel As CustomListView";
_clvtabel = new b4a.example3.customlistview();
 //BA.debugLineNum = 33;BA.debugLine="Private item1 As B4XView";
_item1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private item2 As B4XView";
_item2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private item3 As B4XView";
_item3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 37;BA.debugLine="Private btnTabel As B4XView";
_btntabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 38;BA.debugLine="Private btnExitTabel As B4XView";
_btnexittabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 43;BA.debugLine="Public Sub Initialize As Object";
 //BA.debugLineNum = 44;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 45;BA.debugLine="End Sub";
return null;
}
public String  _loadimage3() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _b = null;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _c = null;
 //BA.debugLineNum = 68;BA.debugLine="Sub LoadImage3";
 //BA.debugLineNum = 69;BA.debugLine="Dim b = LoadBitmap(File.DirAssets,\"intersect3cili";
_b = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_b = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"intersect3cilindrii.jpg").getObject()));
 //BA.debugLineNum = 70;BA.debugLine="ImageView3.SetBitmap(b)  :  ImageView3.ResizeMode";
_imageview3._setbitmap /*String*/ (_b);
 //BA.debugLineNum = 70;BA.debugLine="ImageView3.SetBitmap(b)  :  ImageView3.ResizeMode";
_imageview3._setresizemode /*String*/ ("FILL");
 //BA.debugLineNum = 72;BA.debugLine="Dim c = LoadBitmap(File.DirAssets,\"unfolded3cilin";
_c = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_c = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"unfolded3cilindrii.jpg").getObject()));
 //BA.debugLineNum = 73;BA.debugLine="ImgFolded3.SetBitmap(c)  :  ImgFolded3.ResizeMode";
_imgfolded3._setbitmap /*String*/ (_c);
 //BA.debugLineNum = 73;BA.debugLine="ImgFolded3.SetBitmap(c)  :  ImgFolded3.ResizeMode";
_imgfolded3._setresizemode /*String*/ ("FILL");
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return "";
}
public boolean  _panel2a_touch(int _action,float _xmouse,float _ymouse) throws Exception{
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct = null;
 //BA.debugLineNum = 243;BA.debugLine="Sub Panel2a_Touch (Action As Int, XMouse As Float,";
 //BA.debugLineNum = 244;BA.debugLine="Dim pct = chrt1.PixToReal(XMouse, YMouse) As Poin";
_pct = _chrt1._pixtoreal /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_xmouse,_ymouse);
 //BA.debugLineNum = 245;BA.debugLine="lblXY2a.Visible = True";
_lblxy2a.setVisible(__c.True);
 //BA.debugLineNum = 246;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,_panel2a.TOUCH_ACTION_DOWN,_panel2a.TOUCH_ACTION_MOVE,_panel2a.TOUCH_ACTION_UP)) {
case 0: {
 //BA.debugLineNum = 248;BA.debugLine="lblXY2a.Text = Round2(pct.X, 1) & \", \" &  Round";
_lblxy2a.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 249;BA.debugLine="If XMouse <= Panel2a.Width/2 Then";
if (_xmouse<=_panel2a.getWidth()/(double)2) { 
 //BA.debugLineNum = 250;BA.debugLine="lblXY2a.Left = XMouse : lblXY2a.Top = YMouse";
_lblxy2a.setLeft((int) (_xmouse));
 //BA.debugLineNum = 250;BA.debugLine="lblXY2a.Left = XMouse : lblXY2a.Top = YMouse";
_lblxy2a.setTop((int) (_ymouse));
 }else {
 //BA.debugLineNum = 252;BA.debugLine="lblXY2a.Left = XMouse-lblXY2a.Width : lblXY2a.";
_lblxy2a.setLeft((int) (_xmouse-_lblxy2a.getWidth()));
 //BA.debugLineNum = 252;BA.debugLine="lblXY2a.Left = XMouse-lblXY2a.Width : lblXY2a.";
_lblxy2a.setTop((int) (_ymouse));
 };
 break; }
case 1: {
 //BA.debugLineNum = 255;BA.debugLine="lblXY2a.Text = Round2(pct.X, 1) & \", \" &  Round";
_lblxy2a.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 256;BA.debugLine="If XMouse <= Panel2a.Width/2 Then";
if (_xmouse<=_panel2a.getWidth()/(double)2) { 
 //BA.debugLineNum = 257;BA.debugLine="lblXY2a.Left = XMouse : lblXY2a.Top = YMouse";
_lblxy2a.setLeft((int) (_xmouse));
 //BA.debugLineNum = 257;BA.debugLine="lblXY2a.Left = XMouse : lblXY2a.Top = YMouse";
_lblxy2a.setTop((int) (_ymouse));
 }else {
 //BA.debugLineNum = 259;BA.debugLine="lblXY2a.Left = XMouse-lblXY2a.Width : lblXY2a.";
_lblxy2a.setLeft((int) (_xmouse-_lblxy2a.getWidth()));
 //BA.debugLineNum = 259;BA.debugLine="lblXY2a.Left = XMouse-lblXY2a.Width : lblXY2a.";
_lblxy2a.setTop((int) (_ymouse));
 };
 break; }
case 2: {
 //BA.debugLineNum = 262;BA.debugLine="lblXY2a.Text = \"\"  :  lblXY2a.Visible = False";
_lblxy2a.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 262;BA.debugLine="lblXY2a.Text = \"\"  :  lblXY2a.Visible = False";
_lblxy2a.setVisible(__c.False);
 break; }
}
;
 //BA.debugLineNum = 264;BA.debugLine="Return True";
if (true) return __c.True;
 //BA.debugLineNum = 265;BA.debugLine="End Sub";
return false;
}
public boolean  _panel2b_touch(int _action,float _xmouse,float _ymouse) throws Exception{
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct = null;
 //BA.debugLineNum = 267;BA.debugLine="Sub Panel2b_Touch (Action As Int, XMouse As Float,";
 //BA.debugLineNum = 268;BA.debugLine="Dim pct = chrt2.PixToReal(XMouse, YMouse) As Poin";
_pct = _chrt2._pixtoreal /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_xmouse,_ymouse);
 //BA.debugLineNum = 269;BA.debugLine="lblXY2b.Visible = True";
_lblxy2b.setVisible(__c.True);
 //BA.debugLineNum = 270;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,_panel2b.TOUCH_ACTION_DOWN,_panel2b.TOUCH_ACTION_MOVE,_panel2b.TOUCH_ACTION_UP)) {
case 0: {
 //BA.debugLineNum = 272;BA.debugLine="lblXY2b.Text = Round2(pct.X, 1) & \", \" &  Round";
_lblxy2b.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 273;BA.debugLine="If XMouse <= Panel2b.Width/2 Then";
if (_xmouse<=_panel2b.getWidth()/(double)2) { 
 //BA.debugLineNum = 274;BA.debugLine="lblXY2b.Left = XMouse : lblXY2b.Top = YMouse";
_lblxy2b.setLeft((int) (_xmouse));
 //BA.debugLineNum = 274;BA.debugLine="lblXY2b.Left = XMouse : lblXY2b.Top = YMouse";
_lblxy2b.setTop((int) (_ymouse));
 }else {
 //BA.debugLineNum = 276;BA.debugLine="lblXY2b.Left = XMouse-lblXY2b.Width : lblXY2b.";
_lblxy2b.setLeft((int) (_xmouse-_lblxy2b.getWidth()));
 //BA.debugLineNum = 276;BA.debugLine="lblXY2b.Left = XMouse-lblXY2b.Width : lblXY2b.";
_lblxy2b.setTop((int) (_ymouse));
 };
 break; }
case 1: {
 //BA.debugLineNum = 279;BA.debugLine="lblXY2b.Text = Round2(pct.X, 1) & \", \" &  Round";
_lblxy2b.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 280;BA.debugLine="If XMouse <= Panel2b.Width/2 Then";
if (_xmouse<=_panel2b.getWidth()/(double)2) { 
 //BA.debugLineNum = 281;BA.debugLine="lblXY2b.Left = XMouse : lblXY2b.Top = YMouse";
_lblxy2b.setLeft((int) (_xmouse));
 //BA.debugLineNum = 281;BA.debugLine="lblXY2b.Left = XMouse : lblXY2b.Top = YMouse";
_lblxy2b.setTop((int) (_ymouse));
 }else {
 //BA.debugLineNum = 283;BA.debugLine="lblXY2b.Left = XMouse-lblXY2b.Width : lblXY2b.";
_lblxy2b.setLeft((int) (_xmouse-_lblxy2b.getWidth()));
 //BA.debugLineNum = 283;BA.debugLine="lblXY2b.Left = XMouse-lblXY2b.Width : lblXY2b.";
_lblxy2b.setTop((int) (_ymouse));
 };
 break; }
case 2: {
 //BA.debugLineNum = 286;BA.debugLine="lblXY2b.Text = \"\"  :  lblXY2b.Visible = False";
_lblxy2b.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 286;BA.debugLine="lblXY2b.Text = \"\"  :  lblXY2b.Visible = False";
_lblxy2b.setVisible(__c.False);
 break; }
}
;
 //BA.debugLineNum = 288;BA.debugLine="Return True";
if (true) return __c.True;
 //BA.debugLineNum = 289;BA.debugLine="End Sub";
return false;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
