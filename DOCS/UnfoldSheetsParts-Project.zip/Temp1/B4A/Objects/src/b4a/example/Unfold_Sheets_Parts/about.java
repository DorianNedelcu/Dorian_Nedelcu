package b4a.example.Unfold_Sheets_Parts;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class about extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.Unfold_Sheets_Parts.about");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.Unfold_Sheets_Parts.about.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public b4a.example.Unfold_Sheets_Parts.b4ximageview _imgautor = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblinfo = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblemail = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lbl_web = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.Unfold_Sheets_Parts.main _main = null;
public b4a.example.Unfold_Sheets_Parts.starter _starter = null;
public b4a.example.Unfold_Sheets_Parts.b4xpages _b4xpages = null;
public b4a.example.Unfold_Sheets_Parts.b4xcollections _b4xcollections = null;
public b4a.example.Unfold_Sheets_Parts.xuiviewsutils _xuiviewsutils = null;
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _b = null;
 //BA.debugLineNum = 18;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 19;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 21;BA.debugLine="Root.LoadLayout(\"About\")";
_root.LoadLayout("About",ba);
 //BA.debugLineNum = 22;BA.debugLine="B4XPages.SetTitle(Me, \"About\")";
_b4xpages._settitle /*String*/ (ba,this,(Object)("About"));
 //BA.debugLineNum = 24;BA.debugLine="Dim b As B4XBitmap";
_b = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
 //BA.debugLineNum = 25;BA.debugLine="b=LoadBitmap(File.DirAssets,\"ND.jpg\")";
_b = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"ND.jpg").getObject()));
 //BA.debugLineNum = 26;BA.debugLine="imgAutor.SetBitmap(b)  :  imgAutor. ResizeMode =";
_imgautor._setbitmap /*String*/ (_b);
 //BA.debugLineNum = 26;BA.debugLine="imgAutor.SetBitmap(b)  :  imgAutor. ResizeMode =";
_imgautor._setresizemode /*String*/ ("FILL");
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private Root As B4XView 'ignore";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 3;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 5;BA.debugLine="Private imgAutor As B4XImageView";
_imgautor = new b4a.example.Unfold_Sheets_Parts.b4ximageview();
 //BA.debugLineNum = 6;BA.debugLine="Private lblInfo As B4XView";
_lblinfo = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 7;BA.debugLine="Private lblEmail As B4XView";
_lblemail = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 9;BA.debugLine="Private lbl_WEB As B4XView";
_lbl_web = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 10;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 13;BA.debugLine="Public Sub Initialize As Object";
 //BA.debugLineNum = 14;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 15;BA.debugLine="End Sub";
return null;
}
public String  _lbl_web_click() throws Exception{
 //BA.debugLineNum = 32;BA.debugLine="Private Sub lbl_WEB_Click";
 //BA.debugLineNum = 33;BA.debugLine="B4XPages.ShowPage(\"idPagWeb\")";
_b4xpages._showpage /*String*/ (ba,"idPagWeb");
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return "";
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
