package b4a.example.Unfold_Sheets_Parts;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class grafic extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.Unfold_Sheets_Parts.grafic");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.Unfold_Sheets_Parts.grafic.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnltarget = null;
public anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvstarget = null;
public float _xgmin = 0f;
public float _xgmax = 0f;
public float _ygmin = 0f;
public float _ygmax = 0f;
public int _nx = 0;
public int _ny = 0;
public b4a.example.dateutils _dateutils = null;
public b4a.example.Unfold_Sheets_Parts.main _main = null;
public b4a.example.Unfold_Sheets_Parts.starter _starter = null;
public b4a.example.Unfold_Sheets_Parts.b4xpages _b4xpages = null;
public b4a.example.Unfold_Sheets_Parts.b4xcollections _b4xcollections = null;
public b4a.example.Unfold_Sheets_Parts.xuiviewsutils _xuiviewsutils = null;
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private pnlTarget As Panel";
_pnltarget = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 3;BA.debugLine="Private cvsTarget As Canvas";
_cvstarget = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 4;BA.debugLine="Private XGmin, XGmax, YGmin, YGmax As Float";
_xgmin = 0f;
_xgmax = 0f;
_ygmin = 0f;
_ygmax = 0f;
 //BA.debugLineNum = 5;BA.debugLine="Private NX, NY As Int";
_nx = 0;
_ny = 0;
 //BA.debugLineNum = 6;BA.debugLine="End Sub";
return "";
}
public String  _drawcurve(anywheresoftware.b4a.objects.collections.List _ilistxy,long _iculoare,int _igrosime,boolean _imarcare,boolean _ierasescreen,int _inx,int _iny) throws Exception{
int _semafor = 0;
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct1 = null;
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct2 = null;
float _xant = 0f;
float _yant = 0f;
float _xcrt = 0f;
float _ycrt = 0f;
anywheresoftware.b4a.objects.collections.List _xx = null;
 //BA.debugLineNum = 51;BA.debugLine="Public Sub DrawCurve(iListXY As List, iCuloare As";
 //BA.debugLineNum = 53;BA.debugLine="Dim Semafor As Int";
_semafor = 0;
 //BA.debugLineNum = 54;BA.debugLine="Dim pct1, pct2 As Point";
_pct1 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
_pct2 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
 //BA.debugLineNum = 55;BA.debugLine="Dim Xant, Yant, Xcrt, Ycrt As Float";
_xant = 0f;
_yant = 0f;
_xcrt = 0f;
_ycrt = 0f;
 //BA.debugLineNum = 56;BA.debugLine="If iEraseScreen=True Then";
if (_ierasescreen==__c.True) { 
 //BA.debugLineNum = 57;BA.debugLine="cvsTarget.DrawColor(Colors.Gray)   '	Erase canva";
_cvstarget.DrawColor(__c.Colors.Gray);
 };
 //BA.debugLineNum = 60;BA.debugLine="Semafor = 0";
_semafor = (int) (0);
 //BA.debugLineNum = 61;BA.debugLine="For Each xx As List In iListXY";
_xx = new anywheresoftware.b4a.objects.collections.List();
{
final anywheresoftware.b4a.BA.IterableList group8 = _ilistxy;
final int groupLen8 = group8.getSize()
;int index8 = 0;
;
for (; index8 < groupLen8;index8++){
_xx = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(group8.Get(index8)));
 //BA.debugLineNum = 62;BA.debugLine="If Semafor = 0 Then";
if (_semafor==0) { 
 //BA.debugLineNum = 63;BA.debugLine="Xant=xx.Get(0)  :  Yant=xx.Get(1)  :  ' Log(Xan";
_xant = (float)(BA.ObjectToNumber(_xx.Get((int) (0))));
 //BA.debugLineNum = 63;BA.debugLine="Xant=xx.Get(0)  :  Yant=xx.Get(1)  :  ' Log(Xan";
_yant = (float)(BA.ObjectToNumber(_xx.Get((int) (1))));
 //BA.debugLineNum = 64;BA.debugLine="Semafor = 1";
_semafor = (int) (1);
 }else {
 //BA.debugLineNum = 66;BA.debugLine="Xcrt=xx.Get(0)  :  Ycrt=xx.Get(1)  :   ' Log(Xc";
_xcrt = (float)(BA.ObjectToNumber(_xx.Get((int) (0))));
 //BA.debugLineNum = 66;BA.debugLine="Xcrt=xx.Get(0)  :  Ycrt=xx.Get(1)  :   ' Log(Xc";
_ycrt = (float)(BA.ObjectToNumber(_xx.Get((int) (1))));
 //BA.debugLineNum = 68;BA.debugLine="pct1 = RealToPix(Xant, Yant)  :  pct2 = RealToP";
_pct1 = _realtopix(_xant,_yant);
 //BA.debugLineNum = 68;BA.debugLine="pct1 = RealToPix(Xant, Yant)  :  pct2 = RealToP";
_pct2 = _realtopix(_xcrt,_ycrt);
 //BA.debugLineNum = 69;BA.debugLine="cvsTarget.DrawLine(pct1.X, pct1.Y, pct2.X, pct2";
_cvstarget.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,(int) (_iculoare),(float) (_igrosime));
 //BA.debugLineNum = 70;BA.debugLine="Xant=Xcrt : Yant=Ycrt";
_xant = _xcrt;
 //BA.debugLineNum = 70;BA.debugLine="Xant=Xcrt : Yant=Ycrt";
_yant = _ycrt;
 };
 }
};
 //BA.debugLineNum = 74;BA.debugLine="If iMarcare=True Then  ' Marcare puncte curba";
if (_imarcare==__c.True) { 
 //BA.debugLineNum = 75;BA.debugLine="For Each xx As List In iListXY";
_xx = new anywheresoftware.b4a.objects.collections.List();
{
final anywheresoftware.b4a.BA.IterableList group24 = _ilistxy;
final int groupLen24 = group24.getSize()
;int index24 = 0;
;
for (; index24 < groupLen24;index24++){
_xx = (anywheresoftware.b4a.objects.collections.List) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.collections.List(), (java.util.List)(group24.Get(index24)));
 //BA.debugLineNum = 76;BA.debugLine="pct1 = RealToPix(xx.Get(0), xx.Get(1))";
_pct1 = _realtopix((float)(BA.ObjectToNumber(_xx.Get((int) (0)))),(float)(BA.ObjectToNumber(_xx.Get((int) (1)))));
 //BA.debugLineNum = 77;BA.debugLine="cvsTarget.DrawCircle( pct1.X, pct1.Y, 4dip, iCu";
_cvstarget.DrawCircle(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,(float) (__c.DipToCurrent((int) (4))),(int) (_iculoare),__c.False,(float) (__c.DipToCurrent((int) (1))));
 }
};
 };
 //BA.debugLineNum = 80;BA.debugLine="NX = iNX : NY = iNY";
_nx = _inx;
 //BA.debugLineNum = 80;BA.debugLine="NX = iNX : NY = iNY";
_ny = _iny;
 //BA.debugLineNum = 81;BA.debugLine="If (NX+NY)>0 Then";
if ((_nx+_ny)>0) { 
 //BA.debugLineNum = 82;BA.debugLine="DrawGrila";
_drawgrila();
 };
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return "";
}
public String  _drawgrila() throws Exception{
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct1 = null;
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct2 = null;
float _pasx = 0f;
float _pasy = 0f;
float _xgrila = 0f;
int _i = 0;
float _ygrila = 0f;
 //BA.debugLineNum = 87;BA.debugLine="Public Sub DrawGrila()";
 //BA.debugLineNum = 88;BA.debugLine="Dim pct1, pct2 As Point";
_pct1 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
_pct2 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
 //BA.debugLineNum = 89;BA.debugLine="Dim PasX, PasY As Float";
_pasx = 0f;
_pasy = 0f;
 //BA.debugLineNum = 90;BA.debugLine="If NX>0 Then";
if (_nx>0) { 
 //BA.debugLineNum = 91;BA.debugLine="PasX=(XGmax-XGmin)/NX";
_pasx = (float) ((_xgmax-_xgmin)/(double)_nx);
 //BA.debugLineNum = 92;BA.debugLine="Dim Xgrila=XGmin As Float";
_xgrila = _xgmin;
 //BA.debugLineNum = 93;BA.debugLine="For i=1 To NX";
{
final int step6 = 1;
final int limit6 = _nx;
_i = (int) (1) ;
for (;_i <= limit6 ;_i = _i + step6 ) {
 //BA.debugLineNum = 94;BA.debugLine="pct1 = RealToPix(Xgrila, YGmin)  :  pct2 = Real";
_pct1 = _realtopix(_xgrila,_ygmin);
 //BA.debugLineNum = 94;BA.debugLine="pct1 = RealToPix(Xgrila, YGmin)  :  pct2 = Real";
_pct2 = _realtopix(_xgrila,_ygmax);
 //BA.debugLineNum = 95;BA.debugLine="cvsTarget.DrawLine(pct1.X, pct1.Y, pct2.X, pct2";
_cvstarget.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,__c.Colors.DarkGray,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 96;BA.debugLine="Xgrila = Xgrila + PasX";
_xgrila = (float) (_xgrila+_pasx);
 }
};
 };
 //BA.debugLineNum = 99;BA.debugLine="If NY>0 Then";
if (_ny>0) { 
 //BA.debugLineNum = 100;BA.debugLine="PasY=(YGmax-YGmin)/NY";
_pasy = (float) ((_ygmax-_ygmin)/(double)_ny);
 //BA.debugLineNum = 101;BA.debugLine="Dim Ygrila=YGmin As Float";
_ygrila = _ygmin;
 //BA.debugLineNum = 102;BA.debugLine="For i=1 To NY";
{
final int step16 = 1;
final int limit16 = _ny;
_i = (int) (1) ;
for (;_i <= limit16 ;_i = _i + step16 ) {
 //BA.debugLineNum = 103;BA.debugLine="pct1 = RealToPix(XGmin, Ygrila)  :  pct2 = Real";
_pct1 = _realtopix(_xgmin,_ygrila);
 //BA.debugLineNum = 103;BA.debugLine="pct1 = RealToPix(XGmin, Ygrila)  :  pct2 = Real";
_pct2 = _realtopix(_xgmax,_ygrila);
 //BA.debugLineNum = 104;BA.debugLine="cvsTarget.DrawLine(pct1.X, pct1.Y, pct2.X, pct2";
_cvstarget.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,__c.Colors.DarkGray,(float) (__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 105;BA.debugLine="Ygrila = Ygrila + PasY";
_ygrila = (float) (_ygrila+_pasy);
 }
};
 };
 //BA.debugLineNum = 108;BA.debugLine="End Sub";
return "";
}
public String  _initialize(anywheresoftware.b4a.BA _ba,anywheresoftware.b4a.objects.PanelWrapper _itarget,anywheresoftware.b4a.objects.drawable.CanvasWrapper _icanvas,float _ixgmin,float _iygmin,float _ixgmax,float _iygmax) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 9;BA.debugLine="Public Sub Initialize( iTarget As Panel, iCanvas A";
 //BA.debugLineNum = 11;BA.debugLine="pnlTarget = iTarget";
_pnltarget = _itarget;
 //BA.debugLineNum = 12;BA.debugLine="cvsTarget = iCanvas";
_cvstarget = _icanvas;
 //BA.debugLineNum = 13;BA.debugLine="cvsTarget.Initialize(pnlTarget)";
_cvstarget.Initialize((android.view.View)(_pnltarget.getObject()));
 //BA.debugLineNum = 14;BA.debugLine="XGmin=iXGmin";
_xgmin = _ixgmin;
 //BA.debugLineNum = 15;BA.debugLine="YGmin=iYGmin";
_ygmin = _iygmin;
 //BA.debugLineNum = 16;BA.debugLine="XGmax=iXGmax";
_xgmax = _ixgmax;
 //BA.debugLineNum = 17;BA.debugLine="YGmax=iYGmax";
_ygmax = _iygmax;
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public b4a.example.Unfold_Sheets_Parts.b4xmainpage._point  _pixtoreal(float _xpix,float _ypix) throws Exception{
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _p = null;
float _xp1 = 0f;
float _yp1 = 0f;
float _xp2 = 0f;
float _yp2 = 0f;
float _kx = 0f;
float _ky = 0f;
 //BA.debugLineNum = 36;BA.debugLine="Sub PixToReal(Xpix As Float, Ypix As Float) As Poi";
 //BA.debugLineNum = 38;BA.debugLine="Dim p As Point";
_p = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
 //BA.debugLineNum = 39;BA.debugLine="Dim Xp1, Yp1, Xp2, Yp2, kx, ky As Float";
_xp1 = 0f;
_yp1 = 0f;
_xp2 = 0f;
_yp2 = 0f;
_kx = 0f;
_ky = 0f;
 //BA.debugLineNum = 41;BA.debugLine="Xp1=0   ' Coordonate in pixeli imagine (Origine [";
_xp1 = (float) (0);
 //BA.debugLineNum = 42;BA.debugLine="Yp1=pnlTarget.Height";
_yp1 = (float) (_pnltarget.getHeight());
 //BA.debugLineNum = 43;BA.debugLine="Xp2=pnlTarget.Width";
_xp2 = (float) (_pnltarget.getWidth());
 //BA.debugLineNum = 44;BA.debugLine="Yp2=0";
_yp2 = (float) (0);
 //BA.debugLineNum = 46;BA.debugLine="kx=(Xp2-Xp1)/(XGmax-XGmin)  :  ky=(Yp2-Yp1)/(YGma";
_kx = (float) ((_xp2-_xp1)/(double)(_xgmax-_xgmin));
 //BA.debugLineNum = 46;BA.debugLine="kx=(Xp2-Xp1)/(XGmax-XGmin)  :  ky=(Yp2-Yp1)/(YGma";
_ky = (float) ((_yp2-_yp1)/(double)(_ygmax-_ygmin));
 //BA.debugLineNum = 47;BA.debugLine="p.X = XGmin+(Xpix-Xp1)/kx  :  p.Y = YGmin+(Ypix-Y";
_p.X /*float*/  = (float) (_xgmin+(_xpix-_xp1)/(double)_kx);
 //BA.debugLineNum = 47;BA.debugLine="p.X = XGmin+(Xpix-Xp1)/kx  :  p.Y = YGmin+(Ypix-Y";
_p.Y /*float*/  = (float) (_ygmin+(_ypix-_yp1)/(double)_ky);
 //BA.debugLineNum = 48;BA.debugLine="Return p";
if (true) return _p;
 //BA.debugLineNum = 49;BA.debugLine="End Sub";
return null;
}
public b4a.example.Unfold_Sheets_Parts.b4xmainpage._point  _realtopix(float _xreal,float _yreal) throws Exception{
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _p = null;
float _xp1 = 0f;
float _yp1 = 0f;
float _xp2 = 0f;
float _yp2 = 0f;
float _kx = 0f;
float _ky = 0f;
 //BA.debugLineNum = 21;BA.debugLine="Sub RealToPix(Xreal As Float, Yreal As Float) As P";
 //BA.debugLineNum = 23;BA.debugLine="Dim p As Point";
_p = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
 //BA.debugLineNum = 24;BA.debugLine="Dim Xp1, Yp1, Xp2, Yp2, kx, ky As Float";
_xp1 = 0f;
_yp1 = 0f;
_xp2 = 0f;
_yp2 = 0f;
_kx = 0f;
_ky = 0f;
 //BA.debugLineNum = 26;BA.debugLine="Xp1=0   ' Coordonate in pixeli imagine (Origine [";
_xp1 = (float) (0);
 //BA.debugLineNum = 27;BA.debugLine="Yp1=pnlTarget.Height";
_yp1 = (float) (_pnltarget.getHeight());
 //BA.debugLineNum = 28;BA.debugLine="Xp2=pnlTarget.Width";
_xp2 = (float) (_pnltarget.getWidth());
 //BA.debugLineNum = 29;BA.debugLine="Yp2=0";
_yp2 = (float) (0);
 //BA.debugLineNum = 31;BA.debugLine="kx=(Xp2-Xp1)/(XGmax-XGmin)  :  ky=(Yp2-Yp1)/(YGma";
_kx = (float) ((_xp2-_xp1)/(double)(_xgmax-_xgmin));
 //BA.debugLineNum = 31;BA.debugLine="kx=(Xp2-Xp1)/(XGmax-XGmin)  :  ky=(Yp2-Yp1)/(YGma";
_ky = (float) ((_yp2-_yp1)/(double)(_ygmax-_ygmin));
 //BA.debugLineNum = 32;BA.debugLine="p.X = (Xreal-XGmin)*kx+Xp1  :  p.Y = (Yreal-YGmin";
_p.X /*float*/  = (float) ((_xreal-_xgmin)*_kx+_xp1);
 //BA.debugLineNum = 32;BA.debugLine="p.X = (Xreal-XGmin)*kx+Xp1  :  p.Y = (Yreal-YGmin";
_p.Y /*float*/  = (float) ((_yreal-_ygmin)*_ky+_yp1);
 //BA.debugLineNum = 33;BA.debugLine="Return p";
if (true) return _p;
 //BA.debugLineNum = 34;BA.debugLine="End Sub";
return null;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
return BA.SubDelegator.SubNotFound;
}
}
