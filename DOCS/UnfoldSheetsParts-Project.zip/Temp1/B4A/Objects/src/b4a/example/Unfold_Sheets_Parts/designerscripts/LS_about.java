package b4a.example.Unfold_Sheets_Parts.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_about{

public static void LS_general(anywheresoftware.b4a.BA ba, android.view.View parent, anywheresoftware.b4a.keywords.LayoutValues lv, java.util.Map props,
java.util.Map<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) throws Exception {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 2;BA.debugLine="AutoScaleAll"[About/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
//BA.debugLineNum = 4;BA.debugLine="imgAutor.Width = 50%X  :  imgAutor.Height = 30%Y  :  imgAutor.Top = 10dip  :  imgAutor.Left = (100%X-imgAutor.Width )/2"[About/General script]
views.get("imgautor").vw.setWidth((int)((50d / 100 * width)));
//BA.debugLineNum = 4;BA.debugLine="imgAutor.Width = 50%X  :  imgAutor.Height = 30%Y  :  imgAutor.Top = 10dip  :  imgAutor.Left = (100%X-imgAutor.Width )/2"[About/General script]
views.get("imgautor").vw.setHeight((int)((30d / 100 * height)));
//BA.debugLineNum = 4;BA.debugLine="imgAutor.Width = 50%X  :  imgAutor.Height = 30%Y  :  imgAutor.Top = 10dip  :  imgAutor.Left = (100%X-imgAutor.Width )/2"[About/General script]
views.get("imgautor").vw.setTop((int)((10d * scale)));
//BA.debugLineNum = 4;BA.debugLine="imgAutor.Width = 50%X  :  imgAutor.Height = 30%Y  :  imgAutor.Top = 10dip  :  imgAutor.Left = (100%X-imgAutor.Width )/2"[About/General script]
views.get("imgautor").vw.setLeft((int)(((100d / 100 * width)-(views.get("imgautor").vw.getWidth()))/2d));
//BA.debugLineNum = 5;BA.debugLine="lblEmail.Width = 95%X  :  lblEmail.Height = 10%Y  :  lblEmail.Top = imgAutor.Bottom+10dip  :  lblEmail.Left = (100%X-lblEmail.Width )/2"[About/General script]
views.get("lblemail").vw.setWidth((int)((95d / 100 * width)));
//BA.debugLineNum = 5;BA.debugLine="lblEmail.Width = 95%X  :  lblEmail.Height = 10%Y  :  lblEmail.Top = imgAutor.Bottom+10dip  :  lblEmail.Left = (100%X-lblEmail.Width )/2"[About/General script]
views.get("lblemail").vw.setHeight((int)((10d / 100 * height)));
//BA.debugLineNum = 5;BA.debugLine="lblEmail.Width = 95%X  :  lblEmail.Height = 10%Y  :  lblEmail.Top = imgAutor.Bottom+10dip  :  lblEmail.Left = (100%X-lblEmail.Width )/2"[About/General script]
views.get("lblemail").vw.setTop((int)((views.get("imgautor").vw.getTop() + views.get("imgautor").vw.getHeight())+(10d * scale)));
//BA.debugLineNum = 5;BA.debugLine="lblEmail.Width = 95%X  :  lblEmail.Height = 10%Y  :  lblEmail.Top = imgAutor.Bottom+10dip  :  lblEmail.Left = (100%X-lblEmail.Width )/2"[About/General script]
views.get("lblemail").vw.setLeft((int)(((100d / 100 * width)-(views.get("lblemail").vw.getWidth()))/2d));
//BA.debugLineNum = 6;BA.debugLine="lbl_WEB.Width=80%X   :  lbl_WEB.Height = 50dip :  lbl_WEB.Left=(100%X- lbl_WEB.Width)/2 : lbl_WEB.Top=lblEmail.Bottom+5dip"[About/General script]
views.get("lbl_web").vw.setWidth((int)((80d / 100 * width)));
//BA.debugLineNum = 6;BA.debugLine="lbl_WEB.Width=80%X   :  lbl_WEB.Height = 50dip :  lbl_WEB.Left=(100%X- lbl_WEB.Width)/2 : lbl_WEB.Top=lblEmail.Bottom+5dip"[About/General script]
views.get("lbl_web").vw.setHeight((int)((50d * scale)));
//BA.debugLineNum = 6;BA.debugLine="lbl_WEB.Width=80%X   :  lbl_WEB.Height = 50dip :  lbl_WEB.Left=(100%X- lbl_WEB.Width)/2 : lbl_WEB.Top=lblEmail.Bottom+5dip"[About/General script]
views.get("lbl_web").vw.setLeft((int)(((100d / 100 * width)-(views.get("lbl_web").vw.getWidth()))/2d));
//BA.debugLineNum = 6;BA.debugLine="lbl_WEB.Width=80%X   :  lbl_WEB.Height = 50dip :  lbl_WEB.Left=(100%X- lbl_WEB.Width)/2 : lbl_WEB.Top=lblEmail.Bottom+5dip"[About/General script]
views.get("lbl_web").vw.setTop((int)((views.get("lblemail").vw.getTop() + views.get("lblemail").vw.getHeight())+(5d * scale)));
//BA.debugLineNum = 7;BA.debugLine="lblInfo.Width = 95%X  :  lblInfo.Height = 25%Y  :  lblInfo.Top = lbl_WEB.Bottom+10dip  :  lblInfo.Left = (100%X-lblInfo.Width )/2"[About/General script]
views.get("lblinfo").vw.setWidth((int)((95d / 100 * width)));
//BA.debugLineNum = 7;BA.debugLine="lblInfo.Width = 95%X  :  lblInfo.Height = 25%Y  :  lblInfo.Top = lbl_WEB.Bottom+10dip  :  lblInfo.Left = (100%X-lblInfo.Width )/2"[About/General script]
views.get("lblinfo").vw.setHeight((int)((25d / 100 * height)));
//BA.debugLineNum = 7;BA.debugLine="lblInfo.Width = 95%X  :  lblInfo.Height = 25%Y  :  lblInfo.Top = lbl_WEB.Bottom+10dip  :  lblInfo.Left = (100%X-lblInfo.Width )/2"[About/General script]
views.get("lblinfo").vw.setTop((int)((views.get("lbl_web").vw.getTop() + views.get("lbl_web").vw.getHeight())+(10d * scale)));
//BA.debugLineNum = 7;BA.debugLine="lblInfo.Width = 95%X  :  lblInfo.Height = 25%Y  :  lblInfo.Top = lbl_WEB.Bottom+10dip  :  lblInfo.Left = (100%X-lblInfo.Width )/2"[About/General script]
views.get("lblinfo").vw.setLeft((int)(((100d / 100 * width)-(views.get("lblinfo").vw.getWidth()))/2d));

}
}