package b4a.example.Unfold_Sheets_Parts;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.B4AClass;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.debug.*;

public class pag2 extends B4AClass.ImplB4AClass implements BA.SubDelegator{
    private static java.util.HashMap<String, java.lang.reflect.Method> htSubs;
    private void innerInitialize(BA _ba) throws Exception {
        if (ba == null) {
            ba = new BA(_ba, this, htSubs, "b4a.example.Unfold_Sheets_Parts.pag2");
            if (htSubs == null) {
                ba.loadHtSubs(this.getClass());
                htSubs = ba.htSubs;
            }
            
        }
        if (BA.isShellModeRuntimeCheck(ba)) 
			   this.getClass().getMethod("_class_globals", b4a.example.Unfold_Sheets_Parts.pag2.class).invoke(this, new Object[] {null});
        else
            ba.raiseEvent2(null, true, "class_globals", false);
    }

 public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _root = null;
public anywheresoftware.b4a.objects.B4XViewWrapper.XUI _xui = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panel2a = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _panel2b = null;
public anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvsdrawing1 = null;
public anywheresoftware.b4a.objects.drawable.CanvasWrapper _cvsdrawing2 = null;
public float _xgmin1 = 0f;
public float _xgmax1 = 0f;
public float _ygmin1 = 0f;
public float _ygmax1 = 0f;
public float _xgmin2 = 0f;
public float _xgmax2 = 0f;
public float _ygmin2 = 0f;
public float _ygmax2 = 0f;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblxy2a = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _lblxy2b = null;
public b4a.example.Unfold_Sheets_Parts.b4ximageview _imageview2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btncalculate2 = null;
public anywheresoftware.b4a.objects.PanelWrapper _pnlinputdata2 = null;
public b4a.example.Unfold_Sheets_Parts.b4ximageview _imgfolded2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btncalculateid = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btncancelid = null;
public float _pi = 0f;
public b4a.example.Unfold_Sheets_Parts.grafic _chrt1 = null;
public b4a.example.Unfold_Sheets_Parts.grafic _chrt2 = null;
public float[] _x = null;
public float[] _y = null;
public float[] _y1 = null;
public float[] _y2 = null;
public float[] _ut = null;
public int _nrpct = 0;
public b4a.example.Unfold_Sheets_Parts.b4xdialog _inputdialog = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtdiameter = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtheight = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtgama = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txtl1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _txt_l = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnldemo = null;
public b4a.example.Unfold_Sheets_Parts.b4ximageview _imgdemo = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnexitdemo = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnloaddemo = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _pnltabel = null;
public b4a.example3.customlistview _clvtabel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _item1 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _item2 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _item3 = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btntabel = null;
public anywheresoftware.b4a.objects.B4XViewWrapper _btnexittabel = null;
public b4a.example.dateutils _dateutils = null;
public b4a.example.Unfold_Sheets_Parts.main _main = null;
public b4a.example.Unfold_Sheets_Parts.starter _starter = null;
public b4a.example.Unfold_Sheets_Parts.b4xpages _b4xpages = null;
public b4a.example.Unfold_Sheets_Parts.b4xcollections _b4xcollections = null;
public b4a.example.Unfold_Sheets_Parts.xuiviewsutils _xuiviewsutils = null;
public String  _b4xpage_created(anywheresoftware.b4a.objects.B4XViewWrapper _root1) throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Private Sub B4XPage_Created (Root1 As B4XView)";
 //BA.debugLineNum = 60;BA.debugLine="Root = Root1";
_root = _root1;
 //BA.debugLineNum = 62;BA.debugLine="Root.LoadLayout(\"lay2\")";
_root.LoadLayout("lay2",ba);
 //BA.debugLineNum = 63;BA.debugLine="B4XPages.SetTitle(Me, \"Two cylinders intersection";
_b4xpages._settitle /*String*/ (ba,this,(Object)("Two cylinders intersection"));
 //BA.debugLineNum = 65;BA.debugLine="InputDialog.Initialize(Root)";
_inputdialog._initialize /*String*/ (ba,_root);
 //BA.debugLineNum = 67;BA.debugLine="pnlTabel.Visible=False";
_pnltabel.setVisible(__c.False);
 //BA.debugLineNum = 68;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 70;BA.debugLine="LoadImage2";
_loadimage2();
 //BA.debugLineNum = 72;BA.debugLine="End Sub";
return "";
}
public String  _btncalculate2_click() throws Exception{
 //BA.debugLineNum = 76;BA.debugLine="Private Sub btnCalculate2_Click";
 //BA.debugLineNum = 77;BA.debugLine="pnlInputData2.Visible = True";
_pnlinputdata2.setVisible(__c.True);
 //BA.debugLineNum = 78;BA.debugLine="btnCalculate2.Visible = False";
_btncalculate2.setVisible(__c.False);
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return "";
}
public String  _btncalculateid_click() throws Exception{
 //BA.debugLineNum = 93;BA.debugLine="Private Sub btnCalculateID_Click";
 //BA.debugLineNum = 94;BA.debugLine="pnlInputData2.Visible = False";
_pnlinputdata2.setVisible(__c.False);
 //BA.debugLineNum = 95;BA.debugLine="Panel2a.Visible=True : Panel2b.Visible=True";
_panel2a.setVisible(__c.True);
 //BA.debugLineNum = 95;BA.debugLine="Panel2a.Visible=True : Panel2b.Visible=True";
_panel2b.setVisible(__c.True);
 //BA.debugLineNum = 96;BA.debugLine="ImgFolded2.mBase.Visible = False";
_imgfolded2._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.False);
 //BA.debugLineNum = 97;BA.debugLine="btnCalculate2.Visible = True";
_btncalculate2.setVisible(__c.True);
 //BA.debugLineNum = 98;BA.debugLine="Calcul_Desfasurata";
_calcul_desfasurata();
 //BA.debugLineNum = 99;BA.debugLine="End Sub";
return "";
}
public String  _btncancelid_click() throws Exception{
 //BA.debugLineNum = 101;BA.debugLine="Private Sub btnCancelID_Click";
 //BA.debugLineNum = 102;BA.debugLine="pnlInputData2.Visible = False";
_pnlinputdata2.setVisible(__c.False);
 //BA.debugLineNum = 103;BA.debugLine="Panel2a.Visible=False : Panel2b.Visible=False";
_panel2a.setVisible(__c.False);
 //BA.debugLineNum = 103;BA.debugLine="Panel2a.Visible=False : Panel2b.Visible=False";
_panel2b.setVisible(__c.False);
 //BA.debugLineNum = 104;BA.debugLine="ImgFolded2.mBase.Visible = True";
_imgfolded2._mbase /*anywheresoftware.b4a.objects.B4XViewWrapper*/ .setVisible(__c.True);
 //BA.debugLineNum = 105;BA.debugLine="btnCalculate2.Visible = True";
_btncalculate2.setVisible(__c.True);
 //BA.debugLineNum = 106;BA.debugLine="LoadImage2";
_loadimage2();
 //BA.debugLineNum = 107;BA.debugLine="End Sub";
return "";
}
public String  _btnexitdemo_click() throws Exception{
 //BA.debugLineNum = 274;BA.debugLine="Private Sub btnExitDemo_Click";
 //BA.debugLineNum = 275;BA.debugLine="pnlDemo.Visible=False";
_pnldemo.setVisible(__c.False);
 //BA.debugLineNum = 276;BA.debugLine="btnCalculate2.Visible=True";
_btncalculate2.setVisible(__c.True);
 //BA.debugLineNum = 277;BA.debugLine="End Sub";
return "";
}
public String  _btnexittabel_click() throws Exception{
 //BA.debugLineNum = 370;BA.debugLine="Private Sub btnExitTabel_Click";
 //BA.debugLineNum = 371;BA.debugLine="pnlTabel.Visible=False";
_pnltabel.setVisible(__c.False);
 //BA.debugLineNum = 372;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 373;BA.debugLine="btnCalculate2.Visible=True";
_btncalculate2.setVisible(__c.True);
 //BA.debugLineNum = 374;BA.debugLine="Panel2a.Visible = True";
_panel2a.setVisible(__c.True);
 //BA.debugLineNum = 375;BA.debugLine="Panel2b.Visible = True";
_panel2b.setVisible(__c.True);
 //BA.debugLineNum = 376;BA.debugLine="btnLoadDemo.Visible = True";
_btnloaddemo.setVisible(__c.True);
 //BA.debugLineNum = 377;BA.debugLine="End Sub";
return "";
}
public String  _btnloaddemo_click() throws Exception{
 //BA.debugLineNum = 279;BA.debugLine="Private Sub btnLoadDemo_Click";
 //BA.debugLineNum = 280;BA.debugLine="pnlDemo.Visible=True";
_pnldemo.setVisible(__c.True);
 //BA.debugLineNum = 281;BA.debugLine="btnCalculate2.Visible=False";
_btncalculate2.setVisible(__c.False);
 //BA.debugLineNum = 282;BA.debugLine="End Sub";
return "";
}
public String  _btntabel_click() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper _p = null;
float _pas = 0f;
int _i = 0;
 //BA.debugLineNum = 332;BA.debugLine="Private Sub btnTabel_Click";
 //BA.debugLineNum = 334;BA.debugLine="Dim xui As XUI";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 335;BA.debugLine="clvTabel.Clear";
_clvtabel._clear();
 //BA.debugLineNum = 337;BA.debugLine="Dim p As B4XView  = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 338;BA.debugLine="p.SetLayoutAnimated(0,0,0,100%X, 60dip)";
_p.SetLayoutAnimated((int) (0),(int) (0),(int) (0),__c.PerXToCurrent((float) (100),ba),__c.DipToCurrent((int) (60)));
 //BA.debugLineNum = 339;BA.debugLine="p.LoadLayout(\"item\")";
_p.LoadLayout("item",ba);
 //BA.debugLineNum = 341;BA.debugLine="item1.Text = \"Angle/X [mm]\"";
_item1.setText(BA.ObjectToCharSequence("Angle/X [mm]"));
 //BA.debugLineNum = 342;BA.debugLine="item2.Text=\"Y [mm]\"";
_item2.setText(BA.ObjectToCharSequence("Y [mm]"));
 //BA.debugLineNum = 343;BA.debugLine="item3.Text=\"Y1/Y2 [mm]\"";
_item3.setText(BA.ObjectToCharSequence("Y1/Y2 [mm]"));
 //BA.debugLineNum = 345;BA.debugLine="clvTabel.Add(p,\"\")";
_clvtabel._add(_p,(Object)(""));
 //BA.debugLineNum = 346;BA.debugLine="Dim pas=360/(4 * NrPct) As Float";
_pas = (float) (360/(double)(4*_nrpct));
 //BA.debugLineNum = 347;BA.debugLine="For i = 1 To 4 * NrPct + 1";
{
final int step11 = 1;
final int limit11 = (int) (4*_nrpct+1);
_i = (int) (1) ;
for (;_i <= limit11 ;_i = _i + step11 ) {
 //BA.debugLineNum = 348;BA.debugLine="Dim p As B4XView  = xui.CreatePanel(\"\")";
_p = new anywheresoftware.b4a.objects.B4XViewWrapper();
_p = _xui.CreatePanel(ba,"");
 //BA.debugLineNum = 349;BA.debugLine="p.SetLayoutAnimated(100,0,0,100%X, 60dip)";
_p.SetLayoutAnimated((int) (100),(int) (0),(int) (0),__c.PerXToCurrent((float) (100),ba),__c.DipToCurrent((int) (60)));
 //BA.debugLineNum = 350;BA.debugLine="p.LoadLayout(\"item\")";
_p.LoadLayout("item",ba);
 //BA.debugLineNum = 353;BA.debugLine="item1.Text = ((i-1) * pas) & \" / \" & Round2(X(i)";
_item1.setText(BA.ObjectToCharSequence(BA.NumberToString(((_i-1)*_pas))+" / "+BA.NumberToString(__c.Round2(_x[_i],(int) (2)))));
 //BA.debugLineNum = 354;BA.debugLine="item2.Text=Round2(Y(i), 2)";
_item2.setText(BA.ObjectToCharSequence(__c.Round2(_y[_i],(int) (2))));
 //BA.debugLineNum = 355;BA.debugLine="item3.Text=Round2(Y1(i), 2) & \" / \" & Round2(Y2(";
_item3.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_y1[_i],(int) (2)))+" / "+BA.NumberToString(__c.Round2(_y2[_i],(int) (2)))));
 //BA.debugLineNum = 357;BA.debugLine="clvTabel.Add(p,\"\")";
_clvtabel._add(_p,(Object)(""));
 }
};
 //BA.debugLineNum = 359;BA.debugLine="btnTabel.Visible=False";
_btntabel.setVisible(__c.False);
 //BA.debugLineNum = 360;BA.debugLine="btnCalculate2.Visible=False";
_btncalculate2.setVisible(__c.False);
 //BA.debugLineNum = 361;BA.debugLine="pnlTabel.Visible=True";
_pnltabel.setVisible(__c.True);
 //BA.debugLineNum = 362;BA.debugLine="btnExitTabel.Visible=True";
_btnexittabel.setVisible(__c.True);
 //BA.debugLineNum = 363;BA.debugLine="Panel2a.Visible = False";
_panel2a.setVisible(__c.False);
 //BA.debugLineNum = 364;BA.debugLine="Panel2b.Visible = False";
_panel2b.setVisible(__c.False);
 //BA.debugLineNum = 365;BA.debugLine="btnLoadDemo.Visible = False";
_btnloaddemo.setVisible(__c.False);
 //BA.debugLineNum = 366;BA.debugLine="End Sub";
return "";
}
public void  _calcul_desfasurata() throws Exception{
ResumableSub_Calcul_Desfasurata rsub = new ResumableSub_Calcul_Desfasurata(this);
rsub.resume(ba, null);
}
public static class ResumableSub_Calcul_Desfasurata extends BA.ResumableSub {
public ResumableSub_Calcul_Desfasurata(b4a.example.Unfold_Sheets_Parts.pag2 parent) {
this.parent = parent;
}
b4a.example.Unfold_Sheets_Parts.pag2 parent;
String _mesaj = "";
float _alfa = 0f;
float _beta = 0f;
float _umax = 0f;
float _h1 = 0f;
float _h2 = 0f;
float _ld = 0f;
float _aria1 = 0f;
float _aria2 = 0f;
float _diametru = 0f;
float _inaltime = 0f;
float _gama = 0f;
float _l1 = 0f;
float _l = 0f;
String _sir = "";
float _lg = 0f;
float _grad = 0f;
float _teta = 0f;
int _i = 0;
anywheresoftware.b4a.objects.collections.List _listxy1 = null;
anywheresoftware.b4a.objects.collections.List _listxy2a = null;
anywheresoftware.b4a.objects.collections.List _listxy2b = null;
anywheresoftware.b4a.objects.collections.List _lstxy1 = null;
anywheresoftware.b4a.objects.collections.List _lstxy2a = null;
anywheresoftware.b4a.objects.collections.List _lstxy2b = null;
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct1 = null;
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct2 = null;
b4a.example.Unfold_Sheets_Parts.b4xlongtexttemplate _s = null;
int _result = 0;
int step45;
int limit45;
int step66;
int limit66;
int step109;
int limit109;
int step123;
int limit123;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 111;BA.debugLine="Private NrPct = 8 As Int";
parent._nrpct = (int) (8);
 //BA.debugLineNum = 112;BA.debugLine="Private mesaj=\"\" As String";
_mesaj = "";
 //BA.debugLineNum = 113;BA.debugLine="Private Alfa, Beta, Umax, H1, H2 As Float";
_alfa = 0f;
_beta = 0f;
_umax = 0f;
_h1 = 0f;
_h2 = 0f;
 //BA.debugLineNum = 114;BA.debugLine="Private Ld, Aria1, Aria2 As Float";
_ld = 0f;
_aria1 = 0f;
_aria2 = 0f;
 //BA.debugLineNum = 115;BA.debugLine="Private Diametru, Inaltime, Gama, L1, L As Float";
_diametru = 0f;
_inaltime = 0f;
_gama = 0f;
_l1 = 0f;
_l = 0f;
 //BA.debugLineNum = 117;BA.debugLine="Diametru = txtDiameter.Text";
_diametru = (float)(Double.parseDouble(parent._txtdiameter.getText()));
 //BA.debugLineNum = 118;BA.debugLine="Inaltime =  txtHeight.Text";
_inaltime = (float)(Double.parseDouble(parent._txtheight.getText()));
 //BA.debugLineNum = 119;BA.debugLine="Gama = txtGama.Text";
_gama = (float)(Double.parseDouble(parent._txtgama.getText()));
 //BA.debugLineNum = 120;BA.debugLine="L1 = txtL1.Text";
_l1 = (float)(Double.parseDouble(parent._txtl1.getText()));
 //BA.debugLineNum = 121;BA.debugLine="L = txt_L.Text";
_l = (float)(Double.parseDouble(parent._txt_l.getText()));
 //BA.debugLineNum = 122;BA.debugLine="Ld = PI * Diametru ' Lungime desfasurata";
_ld = (float) (parent._pi*_diametru);
 //BA.debugLineNum = 125;BA.debugLine="Dim sir As String";
_sir = "";
 //BA.debugLineNum = 126;BA.debugLine="Alfa = Gama / 2 ' Unghi \"Alfa\"";
_alfa = (float) (_gama/(double)2);
 //BA.debugLineNum = 127;BA.debugLine="Beta = 90 - Gama / 2 ' Unghi \"Beta\"";
_beta = (float) (90-_gama/(double)2);
 //BA.debugLineNum = 128;BA.debugLine="Umax= ATan(2 * Inaltime / Diametru) * 180 / PI";
_umax = (float) (parent.__c.ATan(2*_inaltime/(double)_diametru)*180/(double)parent._pi);
 //BA.debugLineNum = 129;BA.debugLine="If Alfa > Umax Or Beta > Umax Then";
if (true) break;

case 1:
//if
this.state = 4;
if (_alfa>_umax || _beta>_umax) { 
this.state = 3;
}if (true) break;

case 3:
//C
this.state = 4;
 //BA.debugLineNum = 130;BA.debugLine="sir = \"The angles 'Alpha' , 'Beta' must be small";
_sir = "The angles 'Alpha' , 'Beta' must be smaller than "+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 131;BA.debugLine="sir = sir &  Umax & \" [degrees]\" & Chr(10) & \"Tr";
_sir = _sir+BA.NumberToString(_umax)+" [degrees]"+BA.ObjectToString(parent.__c.Chr((int) (10)))+"Try increasing the height of the cylinder !";
 //BA.debugLineNum = 132;BA.debugLine="xui.MsgboxAsync( sir, \"Error\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence(_sir),BA.ObjectToCharSequence("Error"));
 //BA.debugLineNum = 133;BA.debugLine="Return";
if (true) return ;
 if (true) break;
;
 //BA.debugLineNum = 135;BA.debugLine="If Tan(Gama / 2 * PI / 180) < Diametru / 2 / (L -";

case 4:
//if
this.state = 7;
if (parent.__c.Tan(_gama/(double)2*parent._pi/(double)180)<_diametru/(double)2/(double)(_l-_l1)) { 
this.state = 6;
}if (true) break;

case 6:
//C
this.state = 7;
 //BA.debugLineNum = 136;BA.debugLine="sir = \"The following condition: \" & Chr(10) & \"t";
_sir = "The following condition: "+BA.ObjectToString(parent.__c.Chr((int) (10)))+"tg(Gama/2) >= D/[2*(L-l1)]";
 //BA.debugLineNum = 137;BA.debugLine="sir=sir &  Chr(10) & \"is not respected !\"";
_sir = _sir+BA.ObjectToString(parent.__c.Chr((int) (10)))+"is not respected !";
 //BA.debugLineNum = 138;BA.debugLine="xui.MsgboxAsync( sir, \"Error\")";
parent._xui.MsgboxAsync(ba,BA.ObjectToCharSequence(_sir),BA.ObjectToCharSequence("Error"));
 //BA.debugLineNum = 139;BA.debugLine="Return";
if (true) return ;
 if (true) break;

case 7:
//C
this.state = 8;
;
 //BA.debugLineNum = 142;BA.debugLine="Dim LG = 0.03 * PI * Diametru As Float";
_lg = (float) (0.03*parent._pi*_diametru);
 //BA.debugLineNum = 143;BA.debugLine="XGmin1=-LG : XGmax1 = Ld+LG : YGmin1=-LG : YGmax1";
parent._xgmin1 = (float) (-_lg);
 //BA.debugLineNum = 143;BA.debugLine="XGmin1=-LG : XGmax1 = Ld+LG : YGmin1=-LG : YGmax1";
parent._xgmax1 = (float) (_ld+_lg);
 //BA.debugLineNum = 143;BA.debugLine="XGmin1=-LG : XGmax1 = Ld+LG : YGmin1=-LG : YGmax1";
parent._ygmin1 = (float) (-_lg);
 //BA.debugLineNum = 143;BA.debugLine="XGmin1=-LG : XGmax1 = Ld+LG : YGmin1=-LG : YGmax1";
parent._ygmax1 = (float) (_inaltime+_lg);
 //BA.debugLineNum = 144;BA.debugLine="XGmin2=-LG : XGmax2 = Ld+LG : YGmin2=-LG : YGmax2";
parent._xgmin2 = (float) (-_lg);
 //BA.debugLineNum = 144;BA.debugLine="XGmin2=-LG : XGmax2 = Ld+LG : YGmin2=-LG : YGmax2";
parent._xgmax2 = (float) (_ld+_lg);
 //BA.debugLineNum = 144;BA.debugLine="XGmin2=-LG : XGmax2 = Ld+LG : YGmin2=-LG : YGmax2";
parent._ygmin2 = (float) (-_lg);
 //BA.debugLineNum = 144;BA.debugLine="XGmin2=-LG : XGmax2 = Ld+LG : YGmin2=-LG : YGmax2";
parent._ygmax2 = (float) (_l+_lg);
 //BA.debugLineNum = 145;BA.debugLine="chrt1.Initialize(Panel2a, cvsDrawing1, XGmin2, YG";
parent._chrt1._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(parent._panel2a.getObject())),parent._cvsdrawing1,parent._xgmin2,parent._ygmin2,parent._xgmax2,parent._ygmax2);
 //BA.debugLineNum = 146;BA.debugLine="chrt2.Initialize(Panel2b, cvsDrawing2, XGmin1, YG";
parent._chrt2._initialize /*String*/ (ba,(anywheresoftware.b4a.objects.PanelWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.PanelWrapper(), (android.view.ViewGroup)(parent._panel2b.getObject())),parent._cvsdrawing2,parent._xgmin1,parent._ygmin1,parent._xgmax1,parent._ygmax1);
 //BA.debugLineNum = 149;BA.debugLine="H1 = Inaltime - Diametru * Tan(Alfa * PI / 180) /";
_h1 = (float) (_inaltime-_diametru*parent.__c.Tan(_alfa*parent._pi/(double)180)/(double)2);
 //BA.debugLineNum = 150;BA.debugLine="H2 = Inaltime - Diametru * Tan(Beta * PI / 180) /";
_h2 = (float) (_inaltime-_diametru*parent.__c.Tan(_beta*parent._pi/(double)180)/(double)2);
 //BA.debugLineNum = 152;BA.debugLine="Dim Grad = Gama * PI / 180 As Float";
_grad = (float) (_gama*parent._pi/(double)180);
 //BA.debugLineNum = 153;BA.debugLine="Aria1 = PI * Diametru * L - Diametru * Diametru /";
_aria1 = (float) (parent._pi*_diametru*_l-_diametru*_diametru/(double)2*(1+parent.__c.Tan(_grad/(double)2)*parent.__c.Tan(_grad/(double)2))/(double)(parent.__c.Tan(_grad/(double)2)));
 //BA.debugLineNum = 154;BA.debugLine="Aria2 = Diametru * (Inaltime * PI - Diametru * (T";
_aria2 = (float) (_diametru*(_inaltime*parent._pi-_diametru*(parent.__c.Tan(_alfa*parent._pi/(double)180)+parent.__c.Tan(_beta*parent._pi/(double)180))/(double)2));
 //BA.debugLineNum = 155;BA.debugLine="Dim Teta As Float";
_teta = 0f;
 //BA.debugLineNum = 156;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 8:
//for
this.state = 21;
step45 = 1;
limit45 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 43;
if (true) break;

case 43:
//C
this.state = 21;
if ((step45 > 0 && _i <= limit45) || (step45 < 0 && _i >= limit45)) this.state = 10;
if (true) break;

case 44:
//C
this.state = 43;
_i = ((int)(0 + _i + step45)) ;
if (true) break;

case 10:
//C
this.state = 11;
 //BA.debugLineNum = 157;BA.debugLine="Teta = (i - 1) * PI / 2 / NrPct  :  UT(i)=Teta";
_teta = (float) ((_i-1)*parent._pi/(double)2/(double)parent._nrpct);
 //BA.debugLineNum = 157;BA.debugLine="Teta = (i - 1) * PI / 2 / NrPct  :  UT(i)=Teta";
parent._ut[_i] = _teta;
 //BA.debugLineNum = 158;BA.debugLine="X(i) = Teta * Diametru / 2";
parent._x[_i] = (float) (_teta*_diametru/(double)2);
 //BA.debugLineNum = 159;BA.debugLine="If Teta < PI / 2 Or Teta > 3 * PI / 2 Then";
if (true) break;

case 11:
//if
this.state = 16;
if (_teta<parent._pi/(double)2 || _teta>3*parent._pi/(double)2) { 
this.state = 13;
}else {
this.state = 15;
}if (true) break;

case 13:
//C
this.state = 16;
 //BA.debugLineNum = 160;BA.debugLine="Y(i) = Inaltime - Diametru / 2 * Cos(Teta) * Ta";
parent._y[_i] = (float) (_inaltime-_diametru/(double)2*parent.__c.Cos(_teta)*parent.__c.Tan(_alfa*parent._pi/(double)180));
 if (true) break;

case 15:
//C
this.state = 16;
 //BA.debugLineNum = 162;BA.debugLine="Y(i) = Inaltime + Diametru / 2 * Cos(Teta) * Ta";
parent._y[_i] = (float) (_inaltime+_diametru/(double)2*parent.__c.Cos(_teta)*parent.__c.Tan(_beta*parent._pi/(double)180));
 if (true) break;

case 16:
//C
this.state = 17;
;
 //BA.debugLineNum = 164;BA.debugLine="Y1(i) = L1: Y2(i) = L1";
parent._y1[_i] = _l1;
 //BA.debugLineNum = 164;BA.debugLine="Y1(i) = L1: Y2(i) = L1";
parent._y2[_i] = _l1;
 //BA.debugLineNum = 165;BA.debugLine="If Teta >= PI / 2 And Teta <= 3 * PI / 2 Then";
if (true) break;

case 17:
//if
this.state = 20;
if (_teta>=parent._pi/(double)2 && _teta<=3*parent._pi/(double)2) { 
this.state = 19;
}if (true) break;

case 19:
//C
this.state = 20;
 //BA.debugLineNum = 166;BA.debugLine="Y1(i) = L1 - Sin(Teta - PI / 2) * (Diametru / 2";
parent._y1[_i] = (float) (_l1-parent.__c.Sin(_teta-parent._pi/(double)2)*(_diametru/(double)2*parent.__c.Tan(_grad/(double)2)));
 //BA.debugLineNum = 167;BA.debugLine="Y2(i) = L1 + Sin(Teta - PI / 2) * (Diametru / 2";
parent._y2[_i] = (float) (_l1+parent.__c.Sin(_teta-parent._pi/(double)2)*(_diametru/(double)2/(double)(parent.__c.Tan(_grad/(double)2))));
 if (true) break;

case 20:
//C
this.state = 44;
;
 if (true) break;
if (true) break;

case 21:
//C
this.state = 22;
;
 //BA.debugLineNum = 171;BA.debugLine="Dim ListXY1, ListXY2a, ListXY2b As List";
_listxy1 = new anywheresoftware.b4a.objects.collections.List();
_listxy2a = new anywheresoftware.b4a.objects.collections.List();
_listxy2b = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 172;BA.debugLine="Dim lstXY1, lstXY2a, lstXY2b As List";
_lstxy1 = new anywheresoftware.b4a.objects.collections.List();
_lstxy2a = new anywheresoftware.b4a.objects.collections.List();
_lstxy2b = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 173;BA.debugLine="ListXY1.Initialize : ListXY2a.Initialize : ListXY";
_listxy1.Initialize();
 //BA.debugLineNum = 173;BA.debugLine="ListXY1.Initialize : ListXY2a.Initialize : ListXY";
_listxy2a.Initialize();
 //BA.debugLineNum = 173;BA.debugLine="ListXY1.Initialize : ListXY2a.Initialize : ListXY";
_listxy2b.Initialize();
 //BA.debugLineNum = 176;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 22:
//for
this.state = 29;
step66 = 1;
limit66 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 45;
if (true) break;

case 45:
//C
this.state = 29;
if ((step66 > 0 && _i <= limit66) || (step66 < 0 && _i >= limit66)) this.state = 24;
if (true) break;

case 46:
//C
this.state = 45;
_i = ((int)(0 + _i + step66)) ;
if (true) break;

case 24:
//C
this.state = 25;
 //BA.debugLineNum = 177;BA.debugLine="lstXY1.Initialize : lstXY1.Add(X(i)) : lstXY1.Ad";
_lstxy1.Initialize();
 //BA.debugLineNum = 177;BA.debugLine="lstXY1.Initialize : lstXY1.Add(X(i)) : lstXY1.Ad";
_lstxy1.Add((Object)(parent._x[_i]));
 //BA.debugLineNum = 177;BA.debugLine="lstXY1.Initialize : lstXY1.Add(X(i)) : lstXY1.Ad";
_lstxy1.Add((Object)(parent._y[_i]));
 //BA.debugLineNum = 178;BA.debugLine="ListXY1.Add(lstXY1)";
_listxy1.Add((Object)(_lstxy1.getObject()));
 //BA.debugLineNum = 180;BA.debugLine="If UT(i) >= PI / 2 And UT(i) <= 3 * PI / 2 Then";
if (true) break;

case 25:
//if
this.state = 28;
if (parent._ut[_i]>=parent._pi/(double)2 && parent._ut[_i]<=3*parent._pi/(double)2) { 
this.state = 27;
}if (true) break;

case 27:
//C
this.state = 28;
 //BA.debugLineNum = 181;BA.debugLine="lstXY2a.Initialize : lstXY2a.Add(X(i)) : lstXY2";
_lstxy2a.Initialize();
 //BA.debugLineNum = 181;BA.debugLine="lstXY2a.Initialize : lstXY2a.Add(X(i)) : lstXY2";
_lstxy2a.Add((Object)(parent._x[_i]));
 //BA.debugLineNum = 181;BA.debugLine="lstXY2a.Initialize : lstXY2a.Add(X(i)) : lstXY2";
_lstxy2a.Add((Object)(parent._y1[_i]));
 //BA.debugLineNum = 182;BA.debugLine="ListXY2a.Add(lstXY2a)";
_listxy2a.Add((Object)(_lstxy2a.getObject()));
 //BA.debugLineNum = 184;BA.debugLine="lstXY2b.Initialize : lstXY2b.Add(X(i)) : lstXY2";
_lstxy2b.Initialize();
 //BA.debugLineNum = 184;BA.debugLine="lstXY2b.Initialize : lstXY2b.Add(X(i)) : lstXY2";
_lstxy2b.Add((Object)(parent._x[_i]));
 //BA.debugLineNum = 184;BA.debugLine="lstXY2b.Initialize : lstXY2b.Add(X(i)) : lstXY2";
_lstxy2b.Add((Object)(parent._y2[_i]));
 //BA.debugLineNum = 185;BA.debugLine="ListXY2b.Add(lstXY2b)";
_listxy2b.Add((Object)(_lstxy2b.getObject()));
 if (true) break;

case 28:
//C
this.state = 46;
;
 if (true) break;
if (true) break;

case 29:
//C
this.state = 30;
;
 //BA.debugLineNum = 189;BA.debugLine="chrt1.DrawCurve(ListXY2a, Colors.Blue, 3dip, Fals";
parent._chrt1._drawcurve /*String*/ (_listxy2a,(long) (parent.__c.Colors.Blue),parent.__c.DipToCurrent((int) (3)),parent.__c.False,parent.__c.True,(int) (0),(int) (0));
 //BA.debugLineNum = 190;BA.debugLine="chrt1.DrawCurve(ListXY2b, Colors.Blue, 3dip, Fals";
parent._chrt1._drawcurve /*String*/ (_listxy2b,(long) (parent.__c.Colors.Blue),parent.__c.DipToCurrent((int) (3)),parent.__c.False,parent.__c.False,(int) (0),(int) (0));
 //BA.debugLineNum = 191;BA.debugLine="chrt2.DrawCurve(ListXY1, Colors.Blue, 3dip, False";
parent._chrt2._drawcurve /*String*/ (_listxy1,(long) (parent.__c.Colors.Blue),parent.__c.DipToCurrent((int) (3)),parent.__c.False,parent.__c.True,(int) (0),(int) (0));
 //BA.debugLineNum = 193;BA.debugLine="cvsDrawing1.DrawCircle(chrt1.RealToPix(0, 0).X, c";
parent._cvsdrawing1.DrawCircle(parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).X /*float*/ ,parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).Y /*float*/ ,(float) (parent.__c.DipToCurrent((int) (5))),parent.__c.Colors.Red,parent.__c.True,(float) (0));
 //BA.debugLineNum = 194;BA.debugLine="cvsDrawing2.DrawCircle(chrt2.RealToPix(0, 0).X, c";
parent._cvsdrawing2.DrawCircle(parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).X /*float*/ ,parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0)).Y /*float*/ ,(float) (parent.__c.DipToCurrent((int) (5))),parent.__c.Colors.Red,parent.__c.True,(float) (0));
 //BA.debugLineNum = 197;BA.debugLine="Dim pct1, Pct2 As Point";
_pct1 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
_pct2 = new b4a.example.Unfold_Sheets_Parts.b4xmainpage._point();
 //BA.debugLineNum = 198;BA.debugLine="pct1 = chrt1.RealToPix(0, 0)  :  Pct2 = chrt1.Rea";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0));
 //BA.debugLineNum = 198;BA.debugLine="pct1 = chrt1.RealToPix(0, 0)  :  Pct2 = chrt1.Rea";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,(float) (0));
 //BA.debugLineNum = 199;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 201;BA.debugLine="pct1 = chrt1.RealToPix(Ld , 0)  :  Pct2 = chrt1.R";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,(float) (0));
 //BA.debugLineNum = 201;BA.debugLine="pct1 = chrt1.RealToPix(Ld , 0)  :  Pct2 = chrt1.R";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,_l);
 //BA.debugLineNum = 202;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 204;BA.debugLine="pct1 = chrt1.RealToPix(Ld , L)  :  Pct2 = chrt1.R";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,_l);
 //BA.debugLineNum = 204;BA.debugLine="pct1 = chrt1.RealToPix(Ld , L)  :  Pct2 = chrt1.R";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),_l);
 //BA.debugLineNum = 205;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 207;BA.debugLine="pct1 = chrt1.RealToPix(0 , L)  :  Pct2 = chrt1.Re";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),_l);
 //BA.debugLineNum = 207;BA.debugLine="pct1 = chrt1.RealToPix(0 , L)  :  Pct2 = chrt1.Re";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0));
 //BA.debugLineNum = 208;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 211;BA.debugLine="pct1 = chrt2.RealToPix(0, 0)  :  Pct2 = chrt2.Rea";
_pct1 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0));
 //BA.debugLineNum = 211;BA.debugLine="pct1 = chrt2.RealToPix(0, 0)  :  Pct2 = chrt2.Rea";
_pct2 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),_h1);
 //BA.debugLineNum = 212;BA.debugLine="cvsDrawing2.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing2.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 214;BA.debugLine="pct1 = chrt2.RealToPix(0, 0)  :  Pct2 = chrt2.Rea";
_pct1 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ ((float) (0),(float) (0));
 //BA.debugLineNum = 214;BA.debugLine="pct1 = chrt2.RealToPix(0, 0)  :  Pct2 = chrt2.Rea";
_pct2 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,(float) (0));
 //BA.debugLineNum = 215;BA.debugLine="cvsDrawing2.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing2.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 217;BA.debugLine="pct1 = chrt2.RealToPix(Ld , 0)  :  Pct2 = chrt2.R";
_pct1 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,(float) (0));
 //BA.debugLineNum = 217;BA.debugLine="pct1 = chrt2.RealToPix(Ld , 0)  :  Pct2 = chrt2.R";
_pct2 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_ld,_h1);
 //BA.debugLineNum = 218;BA.debugLine="cvsDrawing2.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct2";
parent._cvsdrawing2.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Blue,(float) (parent.__c.DipToCurrent((int) (3))));
 //BA.debugLineNum = 221;BA.debugLine="For i = 1 To 4 * NrPct + 1";
if (true) break;

case 30:
//for
this.state = 39;
step109 = 1;
limit109 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 47;
if (true) break;

case 47:
//C
this.state = 39;
if ((step109 > 0 && _i <= limit109) || (step109 < 0 && _i >= limit109)) this.state = 32;
if (true) break;

case 48:
//C
this.state = 47;
_i = ((int)(0 + _i + step109)) ;
if (true) break;

case 32:
//C
this.state = 33;
 //BA.debugLineNum = 222;BA.debugLine="If UT(i) > PI / 2 And UT(i) < 3 * PI / 2 Then";
if (true) break;

case 33:
//if
this.state = 38;
if (parent._ut[_i]>parent._pi/(double)2 && parent._ut[_i]<3*parent._pi/(double)2) { 
this.state = 35;
}else {
this.state = 37;
}if (true) break;

case 35:
//C
this.state = 38;
 //BA.debugLineNum = 223;BA.debugLine="pct1 = chrt1.RealToPix(X(i), 0)  :  Pct2 = chrt";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],(float) (0));
 //BA.debugLineNum = 223;BA.debugLine="pct1 = chrt1.RealToPix(X(i), 0)  :  Pct2 = chrt";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],parent._y1[_i]);
 //BA.debugLineNum = 224;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pc";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Black,(float) (parent.__c.DipToCurrent((int) (1))));
 //BA.debugLineNum = 226;BA.debugLine="pct1 = chrt1.RealToPix(X(i), Y2(i))  :  Pct2 =";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],parent._y2[_i]);
 //BA.debugLineNum = 226;BA.debugLine="pct1 = chrt1.RealToPix(X(i), Y2(i))  :  Pct2 =";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],_l);
 //BA.debugLineNum = 227;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pc";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Black,(float) (parent.__c.DipToCurrent((int) (1))));
 if (true) break;

case 37:
//C
this.state = 38;
 //BA.debugLineNum = 229;BA.debugLine="pct1 = chrt1.RealToPix(X(i), 0)  :  Pct2 = chrt";
_pct1 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],(float) (0));
 //BA.debugLineNum = 229;BA.debugLine="pct1 = chrt1.RealToPix(X(i), 0)  :  Pct2 = chrt";
_pct2 = parent._chrt1._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],_l);
 //BA.debugLineNum = 230;BA.debugLine="cvsDrawing1.DrawLine(pct1.X, pct1.Y, Pct2.X, Pc";
parent._cvsdrawing1.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Black,(float) (parent.__c.DipToCurrent((int) (1))));
 if (true) break;

case 38:
//C
this.state = 48;
;
 if (true) break;
if (true) break;
;
 //BA.debugLineNum = 235;BA.debugLine="For i = 1 To 4 * NrPct + 1";

case 39:
//for
this.state = 42;
step123 = 1;
limit123 = (int) (4*parent._nrpct+1);
_i = (int) (1) ;
this.state = 49;
if (true) break;

case 49:
//C
this.state = 42;
if ((step123 > 0 && _i <= limit123) || (step123 < 0 && _i >= limit123)) this.state = 41;
if (true) break;

case 50:
//C
this.state = 49;
_i = ((int)(0 + _i + step123)) ;
if (true) break;

case 41:
//C
this.state = 50;
 //BA.debugLineNum = 236;BA.debugLine="pct1 = chrt2.RealToPix(X(i), 0)  :  Pct2 = chrt2";
_pct1 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],(float) (0));
 //BA.debugLineNum = 236;BA.debugLine="pct1 = chrt2.RealToPix(X(i), 0)  :  Pct2 = chrt2";
_pct2 = parent._chrt2._realtopix /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (parent._x[_i],parent._y[_i]);
 //BA.debugLineNum = 237;BA.debugLine="cvsDrawing2.DrawLine(pct1.X, pct1.Y, Pct2.X, Pct";
parent._cvsdrawing2.DrawLine(_pct1.X /*float*/ ,_pct1.Y /*float*/ ,_pct2.X /*float*/ ,_pct2.Y /*float*/ ,parent.__c.Colors.Black,(float) (parent.__c.DipToCurrent((int) (1))));
 if (true) break;
if (true) break;

case 42:
//C
this.state = -1;
;
 //BA.debugLineNum = 241;BA.debugLine="mesaj=\"\"";
_mesaj = "";
 //BA.debugLineNum = 242;BA.debugLine="mesaj = mesaj & \"Gama angle= \" & Round2(Gama, 2)";
_mesaj = _mesaj+"Gama angle= "+BA.NumberToString(parent.__c.Round2(_gama,(int) (2)))+" [deg]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 243;BA.debugLine="mesaj = mesaj & \"Diameter  = \" & Round2(Diametru,";
_mesaj = _mesaj+"Diameter  = "+BA.NumberToString(parent.__c.Round2(_diametru,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 244;BA.debugLine="mesaj = mesaj & \"Height  = \" & Round2(Inaltime, 2";
_mesaj = _mesaj+"Height  = "+BA.NumberToString(parent.__c.Round2(_inaltime,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 245;BA.debugLine="mesaj = mesaj & \"L1  = \" & Round2(L1, 2)  & \" [mm";
_mesaj = _mesaj+"L1  = "+BA.NumberToString(parent.__c.Round2(_l1,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 246;BA.debugLine="mesaj = mesaj & \"Length L  = \" & Round2(L, 2)  &";
_mesaj = _mesaj+"Length L  = "+BA.NumberToString(parent.__c.Round2(_l,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 247;BA.debugLine="mesaj = mesaj & \"=======================\" & Chr(1";
_mesaj = _mesaj+"======================="+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 248;BA.debugLine="mesaj = mesaj & \"Alfa  angle= \" & Round2(Alfa, 2)";
_mesaj = _mesaj+"Alfa  angle= "+BA.NumberToString(parent.__c.Round2(_alfa,(int) (2)))+" [deg]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 249;BA.debugLine="mesaj = mesaj & \"Beta  angle= \" & Round2(Beta, 2)";
_mesaj = _mesaj+"Beta  angle= "+BA.NumberToString(parent.__c.Round2(_beta,(int) (2)))+" [deg]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 250;BA.debugLine="mesaj = mesaj & \"Height H1 = \" & Round2(H1, 2)  &";
_mesaj = _mesaj+"Height H1 = "+BA.NumberToString(parent.__c.Round2(_h1,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 251;BA.debugLine="mesaj = mesaj & \"Height H2 = \" & Round2(H2, 2)  &";
_mesaj = _mesaj+"Height H2 = "+BA.NumberToString(parent.__c.Round2(_h2,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 252;BA.debugLine="mesaj = mesaj & \"Unfolded length Ld = \" & Round2(";
_mesaj = _mesaj+"Unfolded length Ld = "+BA.NumberToString(parent.__c.Round2(_ld,(int) (2)))+" [mm]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 253;BA.debugLine="mesaj = mesaj & \"Surface area 1 = \" & Round2(Aria";
_mesaj = _mesaj+"Surface area 1 = "+BA.NumberToString(parent.__c.Round2(_aria1,(int) (2)))+" [mm2]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 254;BA.debugLine="mesaj = mesaj & \"Surface area 2 = \" & Round2(Aria";
_mesaj = _mesaj+"Surface area 2 = "+BA.NumberToString(parent.__c.Round2(_aria2,(int) (2)))+" [mm2]"+BA.ObjectToString(parent.__c.Chr((int) (10)));
 //BA.debugLineNum = 256;BA.debugLine="Dim s As B4XLongTextTemplate";
_s = new b4a.example.Unfold_Sheets_Parts.b4xlongtexttemplate();
 //BA.debugLineNum = 257;BA.debugLine="s.Initialize  :  s.Text = mesaj";
_s._initialize /*String*/ (ba);
 //BA.debugLineNum = 257;BA.debugLine="s.Initialize  :  s.Text = mesaj";
_s._text /*Object*/  = (Object)(_mesaj);
 //BA.debugLineNum = 258;BA.debugLine="s.CustomListView1.DefaultTextBackgroundColor=xui.";
_s._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextbackgroundcolor = parent._xui.Color_White;
 //BA.debugLineNum = 259;BA.debugLine="s.CustomListView1.DefaultTextColor = xui.Color_Bl";
_s._customlistview1 /*b4a.example3.customlistview*/ ._defaulttextcolor = parent._xui.Color_Black;
 //BA.debugLineNum = 260;BA.debugLine="InputDialog.Title=\"Info results\"";
parent._inputdialog._title /*Object*/  = (Object)("Info results");
 //BA.debugLineNum = 261;BA.debugLine="InputDialog.TitleBarColor=Colors.Blue  :  InputDi";
parent._inputdialog._titlebarcolor /*int*/  = parent.__c.Colors.Blue;
 //BA.debugLineNum = 261;BA.debugLine="InputDialog.TitleBarColor=Colors.Blue  :  InputDi";
parent._inputdialog._buttonscolor /*int*/  = parent.__c.Colors.Blue;
 //BA.debugLineNum = 262;BA.debugLine="InputDialog.BorderWidth = 4  :  InputDialog.Borde";
parent._inputdialog._borderwidth /*int*/  = (int) (4);
 //BA.debugLineNum = 262;BA.debugLine="InputDialog.BorderWidth = 4  :  InputDialog.Borde";
parent._inputdialog._bordercornersradius /*int*/  = parent.__c.DipToCurrent((int) (10));
 //BA.debugLineNum = 263;BA.debugLine="InputDialog.BackgroundColor=Colors.White  :  Inpu";
parent._inputdialog._backgroundcolor /*int*/  = parent.__c.Colors.White;
 //BA.debugLineNum = 263;BA.debugLine="InputDialog.BackgroundColor=Colors.White  :  Inpu";
parent._inputdialog._buttonstextcolor /*int*/  = parent.__c.Colors.White;
 //BA.debugLineNum = 264;BA.debugLine="wait for (InputDialog.ShowTemplate(s,\"OK\",\"\",\"\"))";
parent.__c.WaitFor("complete", ba, this, parent._inputdialog._showtemplate /*anywheresoftware.b4a.keywords.Common.ResumableSubWrapper*/ ((Object)(_s),(Object)("OK"),(Object)(""),(Object)("")));
this.state = 51;
return;
case 51:
//C
this.state = -1;
_result = (Integer) result[0];
;
 //BA.debugLineNum = 271;BA.debugLine="btnTabel.Visible=True";
parent._btntabel.setVisible(parent.__c.True);
 //BA.debugLineNum = 272;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public void  _complete(int _result) throws Exception{
}
public String  _class_globals() throws Exception{
 //BA.debugLineNum = 1;BA.debugLine="Sub Class_Globals";
 //BA.debugLineNum = 2;BA.debugLine="Private Root As B4XView 'ignore";
_root = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 3;BA.debugLine="Private xui As XUI 'ignore";
_xui = new anywheresoftware.b4a.objects.B4XViewWrapper.XUI();
 //BA.debugLineNum = 5;BA.debugLine="Public Panel2a As B4XView";
_panel2a = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 6;BA.debugLine="Public Panel2b As B4XView";
_panel2b = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 7;BA.debugLine="Dim cvsDrawing1 As Canvas";
_cvsdrawing1 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 8;BA.debugLine="Dim cvsDrawing2 As Canvas";
_cvsdrawing2 = new anywheresoftware.b4a.objects.drawable.CanvasWrapper();
 //BA.debugLineNum = 9;BA.debugLine="Private XGmin1, XGmax1, YGmin1, YGmax1 As Float";
_xgmin1 = 0f;
_xgmax1 = 0f;
_ygmin1 = 0f;
_ygmax1 = 0f;
 //BA.debugLineNum = 10;BA.debugLine="Private XGmin2, XGmax2, YGmin2, YGmax2 As Float";
_xgmin2 = 0f;
_xgmax2 = 0f;
_ygmin2 = 0f;
_ygmax2 = 0f;
 //BA.debugLineNum = 12;BA.debugLine="Private lblXY2a As B4XView";
_lblxy2a = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 13;BA.debugLine="Private lblXY2b As B4XView";
_lblxy2b = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 15;BA.debugLine="Private ImageView2 As B4XImageView";
_imageview2 = new b4a.example.Unfold_Sheets_Parts.b4ximageview();
 //BA.debugLineNum = 16;BA.debugLine="Private btnCalculate2 As B4XView";
_btncalculate2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 17;BA.debugLine="Public pnlInputData2 As Panel";
_pnlinputdata2 = new anywheresoftware.b4a.objects.PanelWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Private ImgFolded2 As B4XImageView";
_imgfolded2 = new b4a.example.Unfold_Sheets_Parts.b4ximageview();
 //BA.debugLineNum = 19;BA.debugLine="Private btnCalculateID As B4XView";
_btncalculateid = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Private btnCancelID As B4XView";
_btncancelid = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Public PI=ATan(1)*4 As Float";
_pi = (float) (__c.ATan(1)*4);
 //BA.debugLineNum = 23;BA.debugLine="Public chrt1 As GRAFIC";
_chrt1 = new b4a.example.Unfold_Sheets_Parts.grafic();
 //BA.debugLineNum = 24;BA.debugLine="Public chrt2 As GRAFIC";
_chrt2 = new b4a.example.Unfold_Sheets_Parts.grafic();
 //BA.debugLineNum = 26;BA.debugLine="Private X (100), Y(100), Y1(100), Y2(100), UT(100";
_x = new float[(int) (100)];
;
_y = new float[(int) (100)];
;
_y1 = new float[(int) (100)];
;
_y2 = new float[(int) (100)];
;
_ut = new float[(int) (100)];
;
 //BA.debugLineNum = 27;BA.debugLine="Public NrPct = 8 As Int";
_nrpct = (int) (8);
 //BA.debugLineNum = 29;BA.debugLine="Public InputDialog As B4XDialog";
_inputdialog = new b4a.example.Unfold_Sheets_Parts.b4xdialog();
 //BA.debugLineNum = 31;BA.debugLine="Private txtDiameter As B4XView";
_txtdiameter = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 32;BA.debugLine="Private txtHeight As B4XView";
_txtheight = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 33;BA.debugLine="Private txtGama As B4XView";
_txtgama = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 34;BA.debugLine="Private txtL1 As B4XView";
_txtl1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 35;BA.debugLine="Private txt_L As B4XView";
_txt_l = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 37;BA.debugLine="Private pnlDemo As B4XView";
_pnldemo = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 38;BA.debugLine="Private ImgDemo As B4XImageView";
_imgdemo = new b4a.example.Unfold_Sheets_Parts.b4ximageview();
 //BA.debugLineNum = 39;BA.debugLine="Private btnExitDemo As B4XView";
_btnexitdemo = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 40;BA.debugLine="Private btnLoadDemo As B4XView";
_btnloaddemo = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 42;BA.debugLine="Private pnlTabel As B4XView";
_pnltabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 43;BA.debugLine="Private clvTabel As CustomListView";
_clvtabel = new b4a.example3.customlistview();
 //BA.debugLineNum = 44;BA.debugLine="Private item1 As B4XView";
_item1 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 45;BA.debugLine="Private item2 As B4XView";
_item2 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 46;BA.debugLine="Private item3 As B4XView";
_item3 = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 48;BA.debugLine="Private btnTabel As B4XView";
_btntabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 49;BA.debugLine="Private btnExitTabel As B4XView";
_btnexittabel = new anywheresoftware.b4a.objects.B4XViewWrapper();
 //BA.debugLineNum = 51;BA.debugLine="End Sub";
return "";
}
public Object  _initialize(anywheresoftware.b4a.BA _ba) throws Exception{
innerInitialize(_ba);
 //BA.debugLineNum = 54;BA.debugLine="Public Sub Initialize As Object";
 //BA.debugLineNum = 55;BA.debugLine="Return Me";
if (true) return this;
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return null;
}
public String  _loadimage2() throws Exception{
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _b = null;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _c = null;
anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper _d = null;
 //BA.debugLineNum = 81;BA.debugLine="Sub LoadImage2";
 //BA.debugLineNum = 82;BA.debugLine="Dim b = LoadBitmap(File.DirAssets,\"intersect2cili";
_b = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_b = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"intersect2cilindrii.jpg").getObject()));
 //BA.debugLineNum = 83;BA.debugLine="ImageView2.SetBitmap(b)  :  ImageView2. ResizeMod";
_imageview2._setbitmap /*String*/ (_b);
 //BA.debugLineNum = 83;BA.debugLine="ImageView2.SetBitmap(b)  :  ImageView2. ResizeMod";
_imageview2._setresizemode /*String*/ ("FILL");
 //BA.debugLineNum = 85;BA.debugLine="Dim c = LoadBitmap(File.DirAssets,\"unfolded2cilin";
_c = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_c = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"unfolded2cilindrii.jpg").getObject()));
 //BA.debugLineNum = 86;BA.debugLine="ImgFolded2.SetBitmap(c)  :  ImgFolded2.ResizeMode";
_imgfolded2._setbitmap /*String*/ (_c);
 //BA.debugLineNum = 86;BA.debugLine="ImgFolded2.SetBitmap(c)  :  ImgFolded2.ResizeMode";
_imgfolded2._setresizemode /*String*/ ("FILL");
 //BA.debugLineNum = 88;BA.debugLine="Dim d = LoadBitmap(File.DirAssets,\"intersect2cili";
_d = new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper();
_d = (anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper) anywheresoftware.b4a.AbsObjectWrapper.ConvertToWrapper(new anywheresoftware.b4a.objects.B4XViewWrapper.B4XBitmapWrapper(), (android.graphics.Bitmap)(__c.LoadBitmap(__c.File.getDirAssets(),"intersect2cilindrii demo.jpg").getObject()));
 //BA.debugLineNum = 89;BA.debugLine="ImgDemo.SetBitmap(d)  :  ImgDemo.ResizeMode = \"FI";
_imgdemo._setbitmap /*String*/ (_d);
 //BA.debugLineNum = 89;BA.debugLine="ImgDemo.SetBitmap(d)  :  ImgDemo.ResizeMode = \"FI";
_imgdemo._setresizemode /*String*/ ("FILL");
 //BA.debugLineNum = 91;BA.debugLine="End Sub";
return "";
}
public boolean  _panel2a_touch(int _action,float _xmouse,float _ymouse) throws Exception{
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct = null;
 //BA.debugLineNum = 284;BA.debugLine="Sub Panel2a_Touch (Action As Int, XMouse As Float,";
 //BA.debugLineNum = 285;BA.debugLine="Dim pct = chrt1.PixToReal(XMouse, YMouse) As Poin";
_pct = _chrt1._pixtoreal /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_xmouse,_ymouse);
 //BA.debugLineNum = 286;BA.debugLine="lblXY2a.Visible = True";
_lblxy2a.setVisible(__c.True);
 //BA.debugLineNum = 287;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,_panel2a.TOUCH_ACTION_DOWN,_panel2a.TOUCH_ACTION_MOVE,_panel2a.TOUCH_ACTION_UP)) {
case 0: {
 //BA.debugLineNum = 289;BA.debugLine="lblXY2a.Text = Round2(pct.X, 1) & \", \" &  Round";
_lblxy2a.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 290;BA.debugLine="If XMouse <= Panel2a.Width/2 Then";
if (_xmouse<=_panel2a.getWidth()/(double)2) { 
 //BA.debugLineNum = 291;BA.debugLine="lblXY2a.Left = XMouse : lblXY2a.Top = YMouse";
_lblxy2a.setLeft((int) (_xmouse));
 //BA.debugLineNum = 291;BA.debugLine="lblXY2a.Left = XMouse : lblXY2a.Top = YMouse";
_lblxy2a.setTop((int) (_ymouse));
 }else {
 //BA.debugLineNum = 293;BA.debugLine="lblXY2a.Left = XMouse-lblXY2a.Width : lblXY2a.";
_lblxy2a.setLeft((int) (_xmouse-_lblxy2a.getWidth()));
 //BA.debugLineNum = 293;BA.debugLine="lblXY2a.Left = XMouse-lblXY2a.Width : lblXY2a.";
_lblxy2a.setTop((int) (_ymouse));
 };
 break; }
case 1: {
 //BA.debugLineNum = 296;BA.debugLine="lblXY2a.Text = Round2(pct.X, 1) & \", \" &  Round";
_lblxy2a.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 297;BA.debugLine="If XMouse <= Panel2a.Width/2 Then";
if (_xmouse<=_panel2a.getWidth()/(double)2) { 
 //BA.debugLineNum = 298;BA.debugLine="lblXY2a.Left = XMouse : lblXY2a.Top = YMouse";
_lblxy2a.setLeft((int) (_xmouse));
 //BA.debugLineNum = 298;BA.debugLine="lblXY2a.Left = XMouse : lblXY2a.Top = YMouse";
_lblxy2a.setTop((int) (_ymouse));
 }else {
 //BA.debugLineNum = 300;BA.debugLine="lblXY2a.Left = XMouse-lblXY2a.Width : lblXY2a.";
_lblxy2a.setLeft((int) (_xmouse-_lblxy2a.getWidth()));
 //BA.debugLineNum = 300;BA.debugLine="lblXY2a.Left = XMouse-lblXY2a.Width : lblXY2a.";
_lblxy2a.setTop((int) (_ymouse));
 };
 break; }
case 2: {
 //BA.debugLineNum = 303;BA.debugLine="lblXY2a.Text = \"\"  :  lblXY2a.Visible = False";
_lblxy2a.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 303;BA.debugLine="lblXY2a.Text = \"\"  :  lblXY2a.Visible = False";
_lblxy2a.setVisible(__c.False);
 break; }
}
;
 //BA.debugLineNum = 305;BA.debugLine="Return True";
if (true) return __c.True;
 //BA.debugLineNum = 306;BA.debugLine="End Sub";
return false;
}
public boolean  _panel2b_touch(int _action,float _xmouse,float _ymouse) throws Exception{
b4a.example.Unfold_Sheets_Parts.b4xmainpage._point _pct = null;
 //BA.debugLineNum = 308;BA.debugLine="Sub Panel2b_Touch (Action As Int, XMouse As Float,";
 //BA.debugLineNum = 309;BA.debugLine="Dim pct = chrt2.PixToReal(XMouse, YMouse) As Poin";
_pct = _chrt2._pixtoreal /*b4a.example.Unfold_Sheets_Parts.b4xmainpage._point*/ (_xmouse,_ymouse);
 //BA.debugLineNum = 310;BA.debugLine="lblXY2b.Visible = True";
_lblxy2b.setVisible(__c.True);
 //BA.debugLineNum = 311;BA.debugLine="Select Action";
switch (BA.switchObjectToInt(_action,_panel2b.TOUCH_ACTION_DOWN,_panel2b.TOUCH_ACTION_MOVE,_panel2b.TOUCH_ACTION_UP)) {
case 0: {
 //BA.debugLineNum = 313;BA.debugLine="lblXY2b.Text = Round2(pct.X, 1) & \", \" &  Round";
_lblxy2b.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 314;BA.debugLine="If XMouse <= Panel2b.Width/2 Then";
if (_xmouse<=_panel2b.getWidth()/(double)2) { 
 //BA.debugLineNum = 315;BA.debugLine="lblXY2b.Left = XMouse : lblXY2b.Top = YMouse";
_lblxy2b.setLeft((int) (_xmouse));
 //BA.debugLineNum = 315;BA.debugLine="lblXY2b.Left = XMouse : lblXY2b.Top = YMouse";
_lblxy2b.setTop((int) (_ymouse));
 }else {
 //BA.debugLineNum = 317;BA.debugLine="lblXY2b.Left = XMouse-lblXY2b.Width : lblXY2b.";
_lblxy2b.setLeft((int) (_xmouse-_lblxy2b.getWidth()));
 //BA.debugLineNum = 317;BA.debugLine="lblXY2b.Left = XMouse-lblXY2b.Width : lblXY2b.";
_lblxy2b.setTop((int) (_ymouse));
 };
 break; }
case 1: {
 //BA.debugLineNum = 320;BA.debugLine="lblXY2b.Text = Round2(pct.X, 1) & \", \" &  Round";
_lblxy2b.setText(BA.ObjectToCharSequence(BA.NumberToString(__c.Round2(_pct.X /*float*/ ,(int) (1)))+", "+BA.NumberToString(__c.Round2(_pct.Y /*float*/ ,(int) (1)))));
 //BA.debugLineNum = 321;BA.debugLine="If XMouse <= Panel2b.Width/2 Then";
if (_xmouse<=_panel2b.getWidth()/(double)2) { 
 //BA.debugLineNum = 322;BA.debugLine="lblXY2b.Left = XMouse : lblXY2b.Top = YMouse";
_lblxy2b.setLeft((int) (_xmouse));
 //BA.debugLineNum = 322;BA.debugLine="lblXY2b.Left = XMouse : lblXY2b.Top = YMouse";
_lblxy2b.setTop((int) (_ymouse));
 }else {
 //BA.debugLineNum = 324;BA.debugLine="lblXY2b.Left = XMouse-lblXY2b.Width : lblXY2b.";
_lblxy2b.setLeft((int) (_xmouse-_lblxy2b.getWidth()));
 //BA.debugLineNum = 324;BA.debugLine="lblXY2b.Left = XMouse-lblXY2b.Width : lblXY2b.";
_lblxy2b.setTop((int) (_ymouse));
 };
 break; }
case 2: {
 //BA.debugLineNum = 327;BA.debugLine="lblXY2b.Text = \"\"  :  lblXY2b.Visible = False";
_lblxy2b.setText(BA.ObjectToCharSequence(""));
 //BA.debugLineNum = 327;BA.debugLine="lblXY2b.Text = \"\"  :  lblXY2b.Visible = False";
_lblxy2b.setVisible(__c.False);
 break; }
}
;
 //BA.debugLineNum = 329;BA.debugLine="Return True";
if (true) return __c.True;
 //BA.debugLineNum = 330;BA.debugLine="End Sub";
return false;
}
public Object callSub(String sub, Object sender, Object[] args) throws Exception {
BA.senderHolder.set(sender);
if (BA.fastSubCompare(sub, "B4XPAGE_CREATED"))
	return _b4xpage_created((anywheresoftware.b4a.objects.B4XViewWrapper) args[0]);
return BA.SubDelegator.SubNotFound;
}
}
